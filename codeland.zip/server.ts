import express from 'express';
import type { Request, Response } from 'express';
import { createServer } from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import path from 'path';
import { fileURLToPath } from 'url';
import {
  createApiApp,
  db,
  findRoomByCode,
  sanitizeDisplayText,
  sanitizeId,
  serializeRoomForClient,
  sweepExpiredEntities,
  upsertPlayerDirectory,
} from './server/app.ts';
import type { ServerGameRoom } from './server/app.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PORT = Number(process.env.PORT) || 3000;

interface ConnectedClient {
  ws: WebSocket;
  userId: string;
  username: string;
  displayName: string;
  avatarId: string;
  watchedRoomCode: string | null;
}

const clients = new Set<ConnectedClient>();

function isWsUserOnline(userId: string): boolean {
  for (const c of clients) {
    if (c.userId === userId && c.ws.readyState === WebSocket.OPEN) {
      return true;
    }
  }
  return false;
}

function sendJson(ws: WebSocket, payload: unknown) {
  if (ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(payload));
  }
}

function broadcastToUser(userId: string, payload: unknown) {
  for (const c of clients) {
    if (c.userId === userId) {
      sendJson(c.ws, payload);
    }
  }
}

function broadcastRoomUpdate(room: ServerGameRoom) {
  const serialized = serializeRoomForClient(room);
  const memberIds = new Set(serialized.members.map((m) => m.userId));
  for (const c of clients) {
    if (c.watchedRoomCode === room.roomCode || (c.userId && memberIds.has(c.userId))) {
      sendJson(c.ws, {
        type: 'room:updated',
        room: serialized,
      });
    }
  }
}

function broadcastPresenceUpdate() {
  const onlineIds: string[] = [];
  for (const c of clients) {
    if (c.userId && c.ws.readyState === WebSocket.OPEN && !onlineIds.includes(c.userId)) {
      onlineIds.push(c.userId);
    }
  }
  for (const c of clients) {
    sendJson(c.ws, {
      type: 'presence:updated',
      onlineUserIds: onlineIds,
    });
  }
}

async function startServer() {
  const app = createApiApp({
    isWsUserOnline,
    broadcastRoomUpdate,
    broadcastToUser,
    broadcastPresenceUpdate,
  });

  // Periodic room & invitation lifecycle sweep for persistent Node server
  setInterval(() => {
    sweepExpiredEntities();
  }, 1500);

  const httpServer = createServer(app);
  const wss = new WebSocketServer({ noServer: true });

  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    let viteMiddlewares: express.RequestHandler | null = null;
    const hmrEnabled = process.env.DISABLE_HMR !== 'true';

    const viteReady = import('vite')
      .then(({ createServer: createViteServer }) =>
        createViteServer({
          server: {
            middlewareMode: true,
            hmr: hmrEnabled ? { server: httpServer } : false,
            watch: hmrEnabled ? {} : null,
          },
          appType: 'spa',
        })
      )
      .then((vite) => {
        viteMiddlewares = vite.middlewares;
      })
      .catch((err) => {
        console.error('Vite middleware initialization failed:', err);
      });

    app.use(async (req: Request, res: Response, next) => {
      if (!viteMiddlewares) {
        await viteReady;
      }
      if (viteMiddlewares) {
        viteMiddlewares(req, res, next);
        return;
      }
      next();
    });
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.use((req: Request, res: Response, next) => {
      if (req.method !== 'GET' || req.path.startsWith('/api/')) {
        next();
        return;
      }
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  httpServer.on('upgrade', (request, socket, head) => {
    try {
      const host = request.headers.host || 'localhost:3000';
      const parsedUrl = new URL(request.url || '/', `http://${host}`);
      if (parsedUrl.pathname === '/api/ws') {
        wss.handleUpgrade(request, socket, head, (ws) => {
          wss.emit('connection', ws, request);
        });
      }
    } catch {
      socket.destroy();
    }
  });

  wss.on('connection', (ws: WebSocket) => {
    const client: ConnectedClient = {
      ws,
      userId: '',
      username: '',
      displayName: '',
      avatarId: 'character-a',
      watchedRoomCode: null,
    };
    clients.add(client);

    ws.on('message', (raw) => {
      try {
        const msg = JSON.parse(String(raw));
        if (!msg || typeof msg.type !== 'string') return;

        if (msg.type === 'ping') {
          sendJson(ws, { type: 'pong' });
          return;
        }

        if (msg.type === 'auth:identify') {
          const uid = sanitizeId(msg.userId);
          if (!uid) return;
          client.userId = uid;
          client.username = sanitizeId(msg.username, 24) || 'explorer';
          client.displayName = sanitizeDisplayText(msg.displayName, 40) || 'Explorer';
          client.avatarId = sanitizeId(msg.avatarId, 24) || 'character-a';

          upsertPlayerDirectory({
            userId: client.userId,
            username: client.username,
            displayName: client.displayName,
            avatarId: client.avatarId,
            totalXp: msg.totalXp,
            currentStreak: msg.currentStreak,
          });

          broadcastPresenceUpdate();

          const now = Date.now();
          const pendingInvites = Object.values(db.roomInvitations).filter(
            (inv) =>
              inv.recipientUserId === uid &&
              inv.invitationStatus === 'pending' &&
              new Date(inv.expiresAt).getTime() > now
          );
          if (pendingInvites.length > 0) {
            sendJson(ws, {
              type: 'invite:init',
              invitations: pendingInvites,
            });
          }

          for (const m of Object.values(db.roomMembers)) {
            if (m.userId === uid) {
              const r = db.gameRooms[m.roomId];
              if (r && (r.roomStatus === 'waiting' || r.roomStatus === 'in_progress')) {
                broadcastRoomUpdate(r);
              }
            }
          }
          return;
        }

        if (msg.type === 'room:watch') {
          const code = String(msg.roomCode || '')
            .trim()
            .toUpperCase()
            .replace(/[^A-Z0-9]/g, '');
          client.watchedRoomCode = code || null;
          if (code) {
            const room = findRoomByCode(code);
            if (room) {
              sendJson(ws, {
                type: 'room:updated',
                room: serializeRoomForClient(room),
              });
            }
          }
          return;
        }

        if (msg.type === 'player:pose' && client.userId) {
          const code = String(msg.roomCode || '')
            .trim()
            .toUpperCase()
            .replace(/[^A-Z0-9]/g, '');
          const room = findRoomByCode(code);
          if (!room) return;
          const member = db.roomMembers[`${room.id}__${client.userId}`];
          if (!member) return;

          const yawDeg = Number(msg.yawDeg);
          const pitchDeg = Number(msg.pitchDeg);
          if (Number.isFinite(yawDeg)) member.yawDeg = ((yawDeg % 360) + 360) % 360;
          if (Number.isFinite(pitchDeg)) member.pitchDeg = Math.max(-75, Math.min(75, pitchDeg));

          for (const peer of clients) {
            if (
              peer !== client &&
              (peer.watchedRoomCode === room.roomCode ||
                Boolean(db.roomMembers[`${room.id}__${peer.userId}`]))
            ) {
              sendJson(peer.ws, {
                type: 'player:pose',
                roomCode: room.roomCode,
                userId: client.userId,
                yawDeg: member.yawDeg,
                pitchDeg: member.pitchDeg,
              });
            }
          }
        }
      } catch {
        // Ignore malformed WS frames
      }
    });

    ws.on('close', () => {
      const uid = client.userId;
      clients.delete(client);
      if (uid) {
        broadcastPresenceUpdate();
        for (const m of Object.values(db.roomMembers)) {
          if (m.userId === uid) {
            const r = db.gameRooms[m.roomId];
            if (r && (r.roomStatus === 'waiting' || r.roomStatus === 'in_progress')) {
              broadcastRoomUpdate(r);
            }
          }
        }
      }
    });
  });

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`CODELAND server + WebSocket hub listening on http://0.0.0.0:${PORT}`);
  });
}

void startServer();
