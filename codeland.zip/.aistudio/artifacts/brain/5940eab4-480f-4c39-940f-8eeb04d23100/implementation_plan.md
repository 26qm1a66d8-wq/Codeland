# CODELAND — Exact Reference Homepage Alignment & 6 Wall Portals Integration

Re-architect the CODELAND dashboard homepage to achieve pixel-level fidelity with the latest uploaded reference design (`image_64e94192.png`), featuring the 6 arched magical realm portals integrated directly onto the center stone wall under the hero, a papyrus parchment Today's Quests board, a ranked Weekly Leaderboard with player highlighting, a cobblestone 5-pedestal dock, and glowing stats summary.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> The following decisions were confirmed during clarification:
> 1. **Center Wall Realm Portals**: The 6 glowing arched portals mounted directly into the center stone wall beneath Alex and the fox (`Starter Forest 1-16`, `Variable Avenue 17-33`, `Logic Kingdom 34-50`, `Looping Mountains 51-66`, `Method Metro 67-83`, `Object Kingdom 84-100`) open the respective world map and level selector on click.
> 2. **Bottom Stone Dock Pedestals**: The 5 carved cobblestone pedestals function as:
>    - **Skills**: Navigates to the Java Academy curriculum (`AppSection.ACADEMY`).
>    - **Quests**: Opens the interactive Daily Quests modal / highlights quest objectives.
>    - **Achievements**: Opens Explorer Badges & World Seals (`AppSection.ACHIEVEMENTS`).
>    - **Shop**: Opens the Byte Bazaar & Wardrobe Marketplace (`AppSection.SHOP`).
>    - **My Base**: Transports the player directly into the 3D World 1 restoration site base (`openWorld('world-1', nextWorld1Level)`).
> 3. **Right Stack Weekly Leaderboard**: Renders the 4-player ranking widget with top 3 learners (DragonCoder, CodeNinja, PixelLearner) and a highlighted golden-brown "You" row showing current player rank and XP, connected to live weekly XP telemetry.

---

## 1. Overview & Core Concept

CODELAND is a voxel fantasy educational RPG that teaches real Java programming. This design update aligns the home dashboard with the updated master layout:
- **Central Rampart Stage**: An elevated stone fortress ledge with floating islands, hot air balloons drifting across a sunset twilight skybox, the purple crystal citadel emitting an energy beam, full moon, cascading waterfalls, and hero Alex Explorer holding a glowing cyan sword alongside the friendly voxel companion fox.
- **Center Stone Wall Realm Portals**: 6 glowing neon arched gateway portals carved directly into the central fortress wall, each displaying its unique realm theme, neon rune arch, title, and level range (1–100 total progression).
- **Right Column Triad**:
  1. *Today's Quests*: Stylized papyrus/parchment scroll with target bullseye icon, 3 active quest rows with progress counters and purple action arrows, plus "View All →".
  2. *Daily Reward*: Enchanted glowing chest card with purple aura, floating gems, and golden "Claim" button.
  3. *Weekly Leaderboard*: Competitive leaderboard showing top 3 ranked coders plus the player's personal rank row with gold badge styling and "See All →".
- **Bottom Terrace**: 5 carved stone pedestals (Skills, Quests, Achievements, Shop, My Base) resting on cobblestone pavement, alongside the purple *Join the Winter Event!* banner with snowman art and "Explore →" CTA.
- **Left Sidebar**: 10 clean navigation links with right chevrons (`>`), active golden gradient pill, unread notification badges, and the glowing "Your Progress" card at the bottom displaying the circular completion gauge and 3 green-check metrics.

---

## 2. User Experience & Visual Design

### A. Viewport Composition & Hierarchy

```
┌──────────────────┬────────────────────────────────────────────────────────────────────────┐
│ [CODELAND Cube]  │  🔥 12 Days Streak   💎 2,450 XP   🪙 175   🔔(2)  ⚙️ Settings         │
│ Learn·Code·Expl. ├──────────────────────────────────────────────┬─────────────────────────┤
│                  │ [🧙‍♂️ Welcome back, Alex! Your Java...]        │ 🎯 Today's Quests   All→│
│ [👑 Alex Explor] │                                              │ 📖 Java Lesson 0/1  [➜] │
│ Lv.3 Var. Ranger │             3D VOXEL HERO STAGE              │ ⚔️ Coding Mission 0/1[➜]│
│ ════════ 88%     │ (Alex with cyan sword + Voxel Fox companion; │ ⭐ Earn 50 XP 20/50 [➜] │
│                  │  Floating Castle, Waterfalls, Balloons, Moon)├─────────────────────────┤
│ 🏠 Home        > │                                              │ 🎁 Daily Reward         │
│ 🔯 Adventure   > ├──────────────────────────────────────────────┤ Claim your reward![Claim│
│ 💻 CodeLab     > │          6 ARCHED WORLD PORTALS ON WALL      ├─────────────────────────┤
│ 🎓 Academy New > │ 🌲Forest  🏰Var.  🏛️Logic  🏔️Loop  🏙️Metro  🔮Object│ 👑 Weekly Board   All→│
│ 🏆 Leaderboard > │  1-16     17-33    34-50    51-66   67-83   84-100 │ 1 👤 DragonCoder 12.5K  │
│ 🏅 Achievements> ├──────────────────────────────────────────────┴─┤ 2 👤 CodeNinja   11.8K  │
│ 📅 Events    ! > │ 📖 Skills  📜 Quests  🏆 Achievements  🎁 Shop  🏡 Base│ 3 👤 PixelLearner 10.7K  │
│ 👥 Friends     > │                                     [⛄ Winter Event! Explore➜]│ 4 🟨 You (Rank #4)9.3K  │
│ 👤 Profile     > ├────────────────────────────────────────────────────────────────────────┤
│ 📖 Glossary    > │ (Below Scroll: Deep World Map, Multiplayer Guild, Quest Log Details)   │
│ [Your Progress]  │                                                                        │
│ ⭕24% ✓Lv 24/100 │                                                                        │
│       ✓W 1/6     │                                                                        │
│       ✓Acc 92%   │                                                                        │
└──────────────────┴────────────────────────────────────────────────────────────────────────┘
```

### B. Visual Tokens & Aesthetic Rules
- **Canvas Base**: `#080D21` (deep twilight obsidian) and `#0B1026` (slate navy sidebar).
- **Glow Accents**:
  - Forest Portal: `#10B981` (emerald green neon arch)
  - Variable Avenue Portal: `#38BDF8` (electric cyan neon arch)
  - Logic Kingdom Portal: `#F59E0B` (warm royal gold neon arch)
  - Looping Mountains Portal: `#67E8F9` (glacial ice-blue neon arch)
  - Method Metro Portal: `#818CF8` (cyber violet neon arch)
  - Object Kingdom Portal: `#C084FC` (mystic royal purple neon arch)
- **Parchment Styling (Quests)**: Warm weathered papyrus `#EFE3C3` with curled edge accents and deep bronze header `#3E2713`.
- **Stone Pedestals**: Dark basalt carved slabs `#1E2538` with beveled edges, gold/blue iconography, and cobblestone ground plane.
- **Your Progress Card**: Amber-orange border glow with dark navy interior, circular 24% ring, and crisp emerald checkmarks for `Levels 24 / 100`, `Worlds 1 / 6`, and `Accuracy 92%`.

---

## 3. Key Product Decisions & Trade-Offs

- **Integrated Wall Portals vs. Below-Fold Grid**:
  - *Chosen*: Embed the 6 glowing arched portals directly into the hero terrace stone wall. This precisely matches `image_64e94192.png` and provides instant one-click access to all six realms directly from the primary landing view.
  - *Fallback / Scroll*: Keep the extended campaign map, full level breakdown, and private multiplayer guild accessible below the fold so no depth is lost.
- **Parchment Quests Card**:
  - *Chosen*: Custom styled SVG/CSS rolled parchment card with target bullseye, warm ink typography, and purple circle buttons matching the reference artwork.
- **Cobblestone Pedestal Dock**:
  - *Chosen*: 5 stone blocks (Skills, Quests, Achievements, Shop, My Base) with the Winter Event banner on the right, matching the reference image layout.

---

## 4. Technical Architecture & Data Strategy

```
┌───────────────────────────────────────────────────────────────────────┐
│                          PlayerContext.tsx                            │
│  - profile (XP, Coins, Streak, Level, Rank, Completed Missions)       │
│  - world1State & campaignLevelProgress                                │
│  - cloudLeaderboard & demoChallengers                                 │
│  - buyMarketplaceItem, equipMarketplaceItem, completeWinterChallenge  │
└───────────────────────────────────┬───────────────────────────────────┘
                                    │
                                    ▼
┌───────────────────────────────────────────────────────────────────────┐
│                           DashboardView.tsx                           │
│  ├── AppShell (Top HUD + 10-Item Sidebar with Chevron + Progress Card)│
│  ├── CentralRampartHeroSection (Three.js 3D Hero + Companion Fox +    │
│  │   Floating Castle + Balloons + Waterfalls + Wizard Speech Bubble)  │
│  ├── WallEmbeddedRealmPortals (6 Neon Arched Portals 1-16 to 84-100)  │
│  ├── RightColumnStack:                                                │
│  │   ├── ParchmentQuestsBoard (Today's Quests parchment card)         │
│  │   ├── DailyRewardChestCard (Enchanted chest + Claim button)        │
│  │   └── WeeklyLeaderboardCard (Top 3 coders + Highlighted You row)   │
│  └── CobblestonePedestalsDock:                                        │
│      ├── 5 Carved Pedestals (Skills, Quests, Achievements, Shop, Base)│
│      └── WinterEventBanner (Snowman artwork + Explore CTA)            │
└───────────────────────────────────────────────────────────────────────┘
```

### Component State Mapping:
- **6 Wall Portals**: Click calls `openWorld(worldId, 1)` or `setSection(AppSection.WORLDS)`.
- **Skills Pedestal**: Calls `setSection(AppSection.ACADEMY)`.
- **Quests Pedestal**: Opens the Quests detail view or scrolls to Quests board.
- **Achievements Pedestal**: Calls `setSection(AppSection.ACHIEVEMENTS)`.
- **Shop Pedestal**: Calls `setSection(AppSection.SHOP)`.
- **My Base Pedestal**: Calls `openWorld('world-1', nextWorld1Level)`.
- **Winter Event Banner**: Calls `setSection(AppSection.EVENTS)`.

---

## 5. Verification Plan & Status: COMPLETED

1. **Build & Type Checking**:
   - [x] Run `lint_applet` (`tsc --noEmit`): Passed with 0 errors.
   - [x] Run `compile_applet` (`vite build`): Clean production bundle compiled successfully.
2. **Visual & Functional Inspection**:
   - [x] Dev server verified responding on `http://localhost:3000` (HTTP 200).
   - [x] **Stone Rampart Hero Stage**: Alex Explorer holding glowing cyan sword with the cute Voxel Companion Fox sitting beside him on the stone ledge, hot air balloons drifting in the sunset twilight skybox, floating crystal citadel with beam, waterfalls, moon, and Wizard Sprout speech bubble.
   - [x] **6 Arched World Portals on Wall (Color Synced & Professional 3D Voxel Art)**:
     - Replaced primitive 2D vector shapes with realistic 3D isometric voxel diorama symbols for all 6 worlds (Starter Forest island with ancient rune arch, Variable Avenue cyber memory spires, Logic Kingdom golden citadel, Looping Mountains glacial peaks, Method Metro cyber grid, Object Kingdom royal amethyst palace).
     - Harmonized frames and backgrounds with the cosmic twilight masonry palette (`#0F1635` / `#0B1028` with glowing neon rune crowns and thresholds).
   - [x] **Today's Quests Board (Harmonized Twilight Theme)**:
     - Replaced clashy yellowish/reddish papyrus gradients and red target with an enchanted dark twilight slate card (`#131A3A` to `#0A0E23`), gold scroll codex icon 📜, cyan/amber progress indicators, and glowing purple action buttons.
   - [x] **Cobblestone Pedestals Dock (Integrated Cosmic Palette)**:
     - 5 carved dark stone pedestals (`Skills`, `Quests`, `Achievements`, `Shop`, `My Base`) featuring circular neon halo rings (cyan, electric violet, warm gold, imperial amber, royal indigo) and detailed 3D isometric voxel micro-dioramas.
     - Removed clashing green-on-purple and muddy boxes to deliver a unified, high-polish fantasy adventure game interface.
   - [x] **Left Sidebar & Right Column Triad**:
     - 10 clean navigation items with right chevrons, golden active pill on Home, purple "New" badge on Academy, red "!" badge on Events, gold crown by player name, and the glowing amber "Your Progress" card.
     - Daily Reward chest card and 4-player Weekly Leaderboard card with highlighted personal rank row.
   - [x] **Zero Feature Regressions**: 100 campaign levels, 3D worlds, Academy lessons, Practice Arena, Private Multiplayer rooms, and Marketplace shop remain fully functional.

