import { WinterEventChallenge } from '../types/codeland';

export interface WinterEventMeta {
  eventId: string;
  eventName: string;
  seasonLabel: string;
  storyHeadline: string;
  storyParagraph: string;
  daysRemaining: number;
  featuredBadgeTitle: string;
  featuredBadgeId: string;
}

export const WINTER_EVENT_META: WinterEventMeta = {
  eventId: 'winter-event-frozen-kingdom',
  eventName: 'The Frozen Kingdom',
  seasonLabel: 'Winter Coding Festival 2026',
  storyHeadline: 'The Ice Warden has frozen the North Gateway of CODELAND!',
  storyParagraph:
    'Temperatures have dropped below freezing and ancient Java logic mechanisms in the glacial peaks have frozen solid. Master Java Strings, conditional warming loops, array traversal, and syntax debugging to melt the frost and unlock the mythical Snowman Companion and Frozen Crown!',
  daysRemaining: 18,
  featuredBadgeTitle: 'Frost Sovereign',
  featuredBadgeId: 'badge-frost-sovereign',
};

export const WINTER_CHALLENGES: WinterEventChallenge[] = [
  {
    id: 'winter-c1',
    title: 'Mission 1: Ignite the Hearth Flame',
    concept: 'Java Output & String Greetings',
    xpReward: 60,
    coinReward: 40,
    description:
      'Kindle the campfire in the snowy lodge by printing the warming activation phrase: "Ignite Hearth Flame!"',
    codeTaskPrompt:
      'Write a Java program that outputs: Ignite Hearth Flame!',
    starterCode: `public class Main {
    public static void main(String[] args) {
        // Output the warming phrase below
        
    }
}`,
    solutionCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("Ignite Hearth Flame!");
    }
}`,
    expectedOutput: 'Ignite Hearth Flame!',
  },
  {
    id: 'winter-c2',
    title: 'Mission 2: Calibrate Frost Thermometer',
    concept: 'Variables & Integer Math',
    xpReward: 75,
    coinReward: 50,
    description:
      'Calculate the glacial temperature offset by initializing currentTemp = -12 and warmingDegrees = 20, then print the resulting temperature.',
    codeTaskPrompt:
      'Calculate and print the sum of -12 and 20.',
    starterCode: `public class Main {
    public static void main(String[] args) {
        int currentTemp = -12;
        int warmingDegrees = 20;
        int finalTemp = currentTemp + warmingDegrees;
        System.out.println("Final Temp: " + finalTemp);
    }
}`,
    solutionCode: `public class Main {
    public static void main(String[] args) {
        int currentTemp = -12;
        int warmingDegrees = 20;
        int finalTemp = currentTemp + warmingDegrees;
        System.out.println("Final Temp: " + finalTemp);
    }
}`,
    expectedOutput: 'Final Temp: 8',
  },
  {
    id: 'winter-c3',
    title: 'Mission 3: Melt the 5 Frozen Locks',
    concept: 'Java for-loop iteration',
    xpReward: 90,
    coinReward: 60,
    description:
      'Loop from lock index 1 through 5 and print "Melted Lock #" followed by the index.',
    codeTaskPrompt:
      'Use a for-loop from 1 to 5 to print: Melted Lock #1 through Melted Lock #5.',
    starterCode: `public class Main {
    public static void main(String[] args) {
        for (int i = 1; i <= 5; i++) {
            System.out.println("Melted Lock #" + i);
        }
    }
}`,
    solutionCode: `public class Main {
    public static void main(String[] args) {
        for (int i = 1; i <= 5; i++) {
            System.out.println("Melted Lock #" + i);
        }
    }
}`,
    expectedOutput: 'Melted Lock #1\nMelted Lock #2\nMelted Lock #3\nMelted Lock #4\nMelted Lock #5',
  },
  {
    id: 'winter-c4',
    title: 'Mission 4: Defeat the Blizzard Core',
    concept: 'Conditional Logic & Strings',
    xpReward: 120,
    coinReward: 80,
    description:
      'Check if the blizzard intensity is greater than 80. If so, cast "AURORA_BLAST" and print "Core Thawed!".',
    codeTaskPrompt:
      'Write the conditional check to print "Core Thawed!".',
    starterCode: `public class Main {
    public static void main(String[] args) {
        int blizzardPower = 95;
        if (blizzardPower > 80) {
            System.out.println("Core Thawed!");
        }
    }
}`,
    solutionCode: `public class Main {
    public static void main(String[] args) {
        int blizzardPower = 95;
        if (blizzardPower > 80) {
            System.out.println("Core Thawed!");
        }
    }
}`,
    expectedOutput: 'Core Thawed!',
  },
];
