import { JavaLevel } from '../types/codeland';

export const JAVA_CURRICULUM: JavaLevel[] = [
  {
    levelNumber: 1,
    id: 'level-1',
    worldId: 'world-1',
    title: "The Beginner's Forest",
    subtitle: 'Level 1 · Java Structure & Output',
    themeName: 'Ancient Voxel Woodland',
    accentColor: '#22D3EE',
    npcName: 'Byte',
    npcRole: 'Ancient Forest Guide',
    npcAvatarId: 'character-g',
    storyIntro:
      'You step into an overgrown voxel forest where the ancient communication beacons have fallen silent. A hovering blocky guide named Byte greets you: "Every machine in CODELAND runs on precise instructions written in Java. Learn how a Java program is structured and send our first signal!"',
    learningObjective:
      'Understand what Java is, identify the structure of a Java class and main method, print messages with System.out.println(), and write clean comments.',
    adventureUnlockText: 'Activate the Forest Communication Tower in 3D.',
    topics: [
      'What is programming & Java?',
      'Basic Java program structure',
      'The main method entry point',
      'System.out.println() & print()',
      'Comments & semicolons',
      'Compilation & execution',
    ],
    lessons: [
      {
        id: '1-1',
        levelNumber: 1,
        orderInLevel: 1,
        title: 'Your First Java Program & Structure',
        estimatedMinutes: 6,
        xpReward: 50,
        coinReward: 15,
        introduction:
          'Computers are extraordinarily fast, yet they cannot guess what you mean. Programming is the craft of writing clear, step-by-step instructions. Java is one of the world’s most trusted languages—powering Android apps, global banking systems, cloud servers, and legendary block-building games.',
        conceptExplanation: [
          'Every Java program lives inside a container called a `class`. Think of a class as the outer housing of a voxel machine.',
          'Inside that class sits a special starter block named `public static void main(String[] args)`. When you press Run, Java always looks for `main` first and executes the instructions inside its curly braces `{ }` from top to bottom.',
          'Each individual instruction is called a statement and ends with a semicolon `;`—just like a period at the end of an English sentence.',
        ],
        visualDemo: {
          kind: 'output_flow',
          title: 'Source Code -> Compiler -> Output Signal',
          caption: 'Toggle steps to see how Java checks your class structure before sending text to the console.',
        },
        syntaxExample: `public class Main {
    public static void main(String[] args) {
        System.out.println("Hello CODELAND!");
    }
}`,
        lineByLine: [
          {
            line: 'public class Main {',
            explanation: 'Declares a class container named `Main`. The opening brace `{` begins the class body.',
          },
          {
            line: 'public static void main(String[] args) {',
            explanation: 'The starting point of the program. Java begins running instructions right inside this block.',
          },
          {
            line: 'System.out.println("Hello CODELAND!");',
            explanation: 'Prints the text inside double quotes to the screen, then moves to a new line. Ends with `;`.',
          },
          {
            line: '} }',
            explanation: 'Every opening curly brace `{` must have a matching closing curly brace `}`.',
          },
        ],
        guidedPrompt:
          'Complete the statement inside `main` so your program prints the exact greeting `Hello CODELAND!` to wake up Byte’s scanner.',
        independentPrompt:
          'Double-check that `System` begins with a capital `S`, your message is inside double quotes `"..."`, and the line ends with `;`.',
        starterCode: `public class Main {
    public static void main(String[] args) {
        // Complete the print instruction below:
        System.out.println("Hello CODELAND!");
    }
}`,
        hints: [
          'Keep the text inside double quotes exact: `"Hello CODELAND!"`.',
          'Make sure there is a semicolon `;` right after the closing parenthesis `)`.',
        ],
        solutionCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("Hello CODELAND!");
    }
}`,
        validation: {
          expectedOutputLines: ['Hello CODELAND!'],
          requiredPatterns: [
            {
              regex: /System\.out\.println\s*\(/,
              message: 'Use `System.out.println(...)` inside `main` to display the greeting.',
            },
          ],
        },
      },
      {
        id: '1-2',
        levelNumber: 1,
        orderInLevel: 2,
        title: 'Printing Multiple Lines & Numbers',
        estimatedMinutes: 7,
        xpReward: 50,
        coinReward: 15,
        introduction:
          'The forest beacons need multi-line status broadcasts! In Java, `System.out.println()` prints a value and jumps to the next line, while `System.out.print()` stays on the same line.',
        conceptExplanation: [
          'Text messages (called Strings) must always be wrapped in double quotes, like `"Tower Ready"`.',
          'Numbers do NOT need quotes! Writing `System.out.println(100);` prints the number `100`, and `System.out.println(20 + 5);` calculates and prints `25`.',
          'Java runs statements inside `main` sequentially—line 1 finishes before line 2 begins.',
        ],
        visualDemo: {
          kind: 'output_flow',
          title: 'Sequential Execution Queue',
          caption: 'Watch how Java runs each `println` instruction in top-to-bottom order.',
        },
        syntaxExample: `public class Main {
    public static void main(String[] args) {
        System.out.println("Signal Active");
        System.out.println(100);
    }
}`,
        lineByLine: [
          {
            line: 'System.out.println("Signal Active");',
            explanation: 'Prints the text `Signal Active` on the first console line.',
          },
          {
            line: 'System.out.println(100);',
            explanation: 'Prints the whole number `100` on the second console line without quotes.',
          },
        ],
        guidedPrompt:
          'Write two `System.out.println` statements inside `main`: print `Forest Beacon` on the first line, and the number `42` on the second line.',
        independentPrompt:
          'Try printing `42` as an actual number (no quotes) or calculation like `40 + 2`!',
        starterCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("Forest Beacon");
        // Add a second println below to output 42:
        
    }
}`,
        hints: [
          'Add `System.out.println(42);` right underneath the first print statement.',
          'Check that both lines end with a semicolon `;`.',
        ],
        solutionCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("Forest Beacon");
        System.out.println(42);
    }
}`,
        validation: {
          expectedOutputLines: ['Forest Beacon', '42'],
        },
      },
      {
        id: '1-3',
        levelNumber: 1,
        orderInLevel: 3,
        title: 'Comments, Syntax Rules & Fixing Bugs',
        estimatedMinutes: 8,
        xpReward: 50,
        coinReward: 15,
        introduction:
          'Before your Java program runs, a Compiler inspects every character for grammar rules (syntax). Even one missing semicolon or typo stops compilation—which is actually helpful because Java catches mistakes early!',
        conceptExplanation: [
          'Use `//` to write a single-line comment, or `/* ... */` for multi-line notes. The Java compiler ignores comments completely, so use them to explain your thinking.',
          'Java is strictly case-sensitive: `System` is not the same as `system`, and `main` is not the same as `Main`.',
          'Fixing errors in code is called debugging. Read the compiler message, check the line number, and repair one issue at a time.',
        ],
        visualDemo: {
          kind: 'output_flow',
          title: 'Compiler Syntax Inspector',
          caption: 'Comments are skipped cleanly while syntax errors highlight the exact broken line.',
        },
        syntaxExample: `public class Main {
    public static void main(String[] args) {
        // Send activation code to Forest Tower
        /* Multi-line note:
           Tower channel #1 */
        System.out.println("TOWER ONLINE");
    }
}`,
        lineByLine: [
          {
            line: '// Send activation code to Forest Tower',
            explanation: 'Single-line comment for human readers; ignored during compilation.',
          },
          {
            line: '/* Multi-line note ... */',
            explanation: 'Block comment spanning multiple lines between `/*` and `*/`.',
          },
          {
            line: 'System.out.println("TOWER ONLINE");',
            explanation: 'Valid, case-accurate statement ending with `;`.',
          },
        ],
        guidedPrompt:
          'The starter program below has two syntax bugs (`system` is lowercase and the semicolon `;` is missing). Add a `//` comment and fix both bugs so it prints `TOWER ONLINE`.',
        independentPrompt:
          'Keep at least one `//` comment in your code while outputting `TOWER ONLINE`.',
        starterCode: `public class Main {
    public static void main(String[] args) {
        // Repair the broken Java line below
        system.out.println("TOWER ONLINE")
    }
}`,
        hints: [
          'Change lowercase `system` to `System` with a capital `S`.',
          'Add a semicolon `;` at the end of `System.out.println("TOWER ONLINE");`.',
        ],
        solutionCode: `public class Main {
    public static void main(String[] args) {
        // Repair the broken Java line below
        System.out.println("TOWER ONLINE");
    }
}`,
        validation: {
          expectedOutputLines: ['TOWER ONLINE'],
        },
      },
    ],
    assessment: [
      {
        id: 'q1-1',
        question: 'Which method acts as the starting entry point of every runnable Java application?',
        options: [
          'public static void start()',
          'public static void main(String[] args)',
          'System.out.begin()',
          'class runProgram()',
        ],
        correctIndex: 1,
        explanation: 'Java always begins execution inside `public static void main(String[] args)`.',
      },
      {
        id: 'q1-2',
        question: 'Which of the following prints `Hello Java` without a syntax error?',
        options: [
          'system.out.println("Hello Java");',
          'System.out.println(Hello Java);',
          'System.out.println("Hello Java");',
          'System.out.println("Hello Java")',
        ],
        correctIndex: 2,
        explanation: '`System` requires a capital `S`, text needs double quotes `"..."`, and the statement must end with `;`.',
      },
      {
        id: 'q1-3',
        question: 'What happens to `// Activate bridge` when Java compiles and runs your code?',
        options: [
          'It prints `Activate bridge` on the screen.',
          'It causes a syntax error because it has no semicolon.',
          'Java ignores it completely because `//` marks a comment for humans.',
          'It slows down the 3D engine.',
        ],
        correctIndex: 2,
        explanation: 'Comments starting with `//` are notes for programmers and are ignored by the compiler.',
      },
    ],
  },
  {
    levelNumber: 2,
    id: 'level-2',
    worldId: 'world-2',
    title: 'The Variable Village',
    subtitle: 'Level 2 · Data Types & Variables',
    themeName: 'Timber & Cobblestone Settlement',
    accentColor: '#F5C451',
    npcName: 'Tinker',
    npcRole: 'Village Inventor',
    npcAvatarId: 'character-h',
    storyIntro:
      'Beyond the forest lies a bustling voxel village of timber workshops and stone granaries. Village inventor Tinker waves frantically: "Our storage ledger wiped! Nobody knows how many coins, timber crates, or vault keys remain. Teach our machines how to store data in Java variables!"',
    learningObjective:
      'Declare, initialize, and update strongly-typed Java variables (`int`, `double`, `char`, `boolean`, `String`) using camelCase naming and type casting.',
    adventureUnlockText: 'Repair the Village Storage System & Open the Resource Vault.',
    topics: [
      'Declaring & initializing variables',
      'Whole numbers (`int`) & decimals (`double`, `float`)',
      'Text (`String`) & single characters (`char`)',
      'True/False switches (`boolean`)',
      'camelCase naming conventions',
      'Type conversion & casting',
    ],
    lessons: [
      {
        id: '2-1',
        levelNumber: 2,
        orderInLevel: 1,
        title: 'Storing Numbers with `int` and `double`',
        estimatedMinutes: 7,
        xpReward: 50,
        coinReward: 15,
        introduction:
          'Imagine labeling wooden crates in a warehouse: one crate holds whole gold coins, another holds measured liters of water. In Java, a variable is a named storage box, and its data type tells Java what fits inside.',
        conceptExplanation: [
          'Use `int` for whole numbers (integers) without decimals: `int coins = 100;`.',
          'Use `double` for numbers with decimal points: `double weight = 14.5;`.',
          'Creating a variable is called declaring it (`int coins`), and giving it its starting value with `=` is called initializing it (`= 100;`). You can update its value later without repeating the type (`coins = 150;`).',
        ],
        visualDemo: {
          kind: 'variable_boxes',
          title: 'Typed Memory Crates',
          caption: 'Inspect how `int`, `double`, `String`, and `boolean` boxes store values in memory.',
        },
        syntaxExample: `public class Main {
    public static void main(String[] args) {
        int coins = 100;
        double weight = 4.5;
        coins = coins + 25;
        System.out.println(coins);
        System.out.println(weight);
    }
}`,
        lineByLine: [
          {
            line: 'int coins = 100;',
            explanation: 'Creates an integer box named `coins` and puts `100` inside.',
          },
          {
            line: 'double weight = 4.5;',
            explanation: 'Creates a decimal number box named `weight` initialized to `4.5`.',
          },
          {
            line: 'coins = coins + 25;',
            explanation: 'Updates `coins` to `125`. Notice we do NOT write `int` a second time!',
          },
        ],
        guidedPrompt:
          'Declare an `int` variable named `woodBlocks` set to `80` and a `double` variable named `plankPrice` set to `2.5`. Print `woodBlocks` on line 1 and `plankPrice` on line 2.',
        independentPrompt:
          'Make sure `woodBlocks` uses `int` and `plankPrice` uses `double`.',
        starterCode: `public class Main {
    public static void main(String[] args) {
        int woodBlocks = 80;
        // Declare double plankPrice = 2.5 below and print both:
        
    }
}`,
        hints: [
          'Write `double plankPrice = 2.5;` below `woodBlocks`.',
          'Print both variables with `System.out.println(woodBlocks);` and `System.out.println(plankPrice);`.',
        ],
        solutionCode: `public class Main {
    public static void main(String[] args) {
        int woodBlocks = 80;
        double plankPrice = 2.5;
        System.out.println(woodBlocks);
        System.out.println(plankPrice);
    }
}`,
        validation: {
          expectedOutputLines: ['80', '2.5'],
          requiredPatterns: [
            { regex: /\bint\s+woodBlocks\b/, message: 'Declare `int woodBlocks = 80;`.' },
            { regex: /\bdouble\s+plankPrice\b/, message: 'Declare `double plankPrice = 2.5;`.' },
          ],
        },
      },
      {
        id: '2-2',
        levelNumber: 2,
        orderInLevel: 2,
        title: 'Text & Switches: `String`, `char`, and `boolean`',
        estimatedMinutes: 8,
        xpReward: 50,
        coinReward: 15,
        introduction:
          'Village records need more than numbers—they also store explorer names, single rank letters, and whether a vault door has a key!',
        conceptExplanation: [
          '`String` stores text in double quotes: `String playerName = "Alex";`. Combining text and variables with `+` is called concatenation: `"Hero: " + playerName`.',
          '`char` stores a single character in single quotes: `char tier = \'A\';`.',
          '`boolean` stores only `true` or `false` (no quotes!): `boolean hasKey = true;`.',
        ],
        visualDemo: {
          kind: 'variable_boxes',
          title: 'Strings, Chars & Booleans',
          caption: 'Compare double quotes for `String`, single quotes for `char`, and bare keywords for `boolean`.',
        },
        syntaxExample: `public class Main {
    public static void main(String[] args) {
        String playerName = "Alex";
        char badge = 'S';
        boolean hasKey = true;
        System.out.println(playerName + " [" + badge + "] Key:" + hasKey);
    }
}`,
        lineByLine: [
          {
            line: 'String playerName = "Alex";',
            explanation: 'Stores text `"Alex"`. Note capital `S` on `String` and double quotes.',
          },
          {
            line: "char badge = 'S';",
            explanation: 'Stores a single letter using single quotes `\'\'`.',
          },
          {
            line: 'boolean hasKey = true;',
            explanation: 'Stores logical `true` without quotes.',
          },
        ],
        guidedPrompt:
          'Create `String villager = "Tinker";` and `boolean vaultReady = true;`. Then print `"Villager: " + villager` on line 1 and `vaultReady` on line 2.',
        independentPrompt:
          'Ensure `vaultReady` is declared as a real `boolean`, not a String in quotes.',
        starterCode: `public class Main {
    public static void main(String[] args) {
        String villager = "Tinker";
        boolean vaultReady = true;
        // Print "Villager: " + villager, then print vaultReady:
        
    }
}`,
        hints: [
          'Line 1 print: `System.out.println("Villager: " + villager);`',
          'Line 2 print: `System.out.println(vaultReady);`',
        ],
        solutionCode: `public class Main {
    public static void main(String[] args) {
        String villager = "Tinker";
        boolean vaultReady = true;
        System.out.println("Villager: " + villager);
        System.out.println(vaultReady);
    }
}`,
        validation: {
          expectedOutputLines: ['Villager: Tinker', 'true'],
          requiredPatterns: [
            { regex: /\bString\s+villager\b/, message: 'Keep `String villager = "Tinker";`.' },
            { regex: /\bboolean\s+vaultReady\b/, message: 'Declare `boolean vaultReady = true;`.' },
          ],
        },
      },
      {
        id: '2-3',
        levelNumber: 2,
        orderInLevel: 3,
        title: 'Naming Conventions & Type Casting',
        estimatedMinutes: 8,
        xpReward: 50,
        coinReward: 15,
        introduction:
          'Professional Java developers follow clean naming rules so anyone can read their code, and use type casting when converting decimal measurements into whole block counts.',
        conceptExplanation: [
          'Java variable names use `camelCase`: start with a lowercase letter and capitalize each new word (`playerScore`, `maxHealth`, `hasGoldenKey`). Spaces and starting digits (`1stScore`) are not allowed.',
          'Java converts an `int` to a `double` automatically (`double d = 10;` becomes `10.0`).',
          'To convert a `double` into an `int`, write `(int)` in front of it: `int blocks = (int) 9.8;`. This chops off (truncates) the decimal part, leaving `9`.',
        ],
        visualDemo: {
          kind: 'variable_boxes',
          title: 'Explicit `(int)` Type Casting',
          caption: 'See how `(int) 15.9` truncates `.9` to fit cleanly inside an `int` crate.',
        },
        syntaxExample: `public class Main {
    public static void main(String[] args) {
        double rawOre = 15.8;
        int wholeIngots = (int) rawOre;
        System.out.println(wholeIngots);
    }
}`,
        lineByLine: [
          {
            line: 'double rawOre = 15.8;',
            explanation: 'Stores decimal `15.8` in a `double` variable using camelCase.',
          },
          {
            line: 'int wholeIngots = (int) rawOre;',
            explanation: 'Casts `rawOre` to `int`, dropping `.8` so `wholeIngots` becomes `15`.',
          },
        ],
        guidedPrompt:
          'Given `double measuredLength = 19.75;`, cast it into an `int` variable named `bridgeBlocks` using `(int)` and print `bridgeBlocks`.',
        independentPrompt:
          'Use camelCase `bridgeBlocks` and explicit `(int)` casting rather than typing `19` directly.',
        starterCode: `public class Main {
    public static void main(String[] args) {
        double measuredLength = 19.75;
        // Cast measuredLength to an int named bridgeBlocks and print it:
        
    }
}`,
        hints: [
          'Write `int bridgeBlocks = (int) measuredLength;`.',
          'Then call `System.out.println(bridgeBlocks);`.',
        ],
        solutionCode: `public class Main {
    public static void main(String[] args) {
        double measuredLength = 19.75;
        int bridgeBlocks = (int) measuredLength;
        System.out.println(bridgeBlocks);
    }
}`,
        validation: {
          expectedOutputLines: ['19'],
          requiredPatterns: [
            {
              regex: /\(\s*int\s*\)\s*measuredLength/,
              message: 'Use explicit type casting `(int) measuredLength` to convert the double into an int.',
            },
          ],
        },
      },
    ],
    assessment: [
      {
        id: 'q2-1',
        question: 'Which Java declaration accurately stores whether a player owns a castle key?',
        options: [
          'boolean hasKey = "true";',
          'bool hasKey = true;',
          'boolean hasKey = true;',
          'int hasKey = true;',
        ],
        correctIndex: 2,
        explanation: 'Java uses the full keyword `boolean` and bare literal `true` or `false` without quotes.',
      },
      {
        id: 'q2-2',
        question: 'What does this code print?\nint a = 10;\na = a + 5;\nSystem.out.println((int) 3.9 + a);',
        options: ['18.9', '19', '18', '3.915'],
        correctIndex: 2,
        explanation: '`a` becomes `15`, and `(int) 3.9` truncates to `3`. `3 + 15` equals `18`.',
      },
      {
        id: 'q2-3',
        question: 'Which variable name follows standard Java camelCase conventions?',
        options: ['1stPlayerCoins', 'totalGoldCoins', 'total gold coins', 'Total-Gold'],
        correctIndex: 1,
        explanation: 'Java variables cannot start with digits or contain spaces/hyphens; `totalGoldCoins` is clean camelCase.',
      },
    ],
  },
  {
    levelNumber: 3,
    id: 'level-3',
    worldId: 'world-3',
    title: 'The Logic Castle',
    subtitle: 'Level 3 · Operators & Conditionals',
    themeName: 'Medieval Fortress & Gatehouse',
    accentColor: '#F28C45',
    npcName: 'Sir Gareth',
    npcRole: 'Castle Guardian',
    npcAvatarId: 'character-i',
    storyIntro:
      'High stone battlements rise above a moat. Castle Guardian Sir Gareth points to the iron portcullis: "Every gate in Logic Castle checks a condition before opening. Master comparison operators, `if-else` branches, and logical combinations to free the trapped villagers!"',
    learningObjective:
      'Write decision-making Java programs using comparison operators, logical operators (`&&`, `||`, `!`), `if / else if / else` chains, and `switch` statements.',
    adventureUnlockText: 'Open the Castle Gates & Rescue the Trapped Villagers.',
    topics: [
      'Arithmetic (`+ - * / %`) & comparison (`== != > < >= <=`)',
      '`if` & `if-else` statements',
      '`else if` chains & nested conditions',
      'Logical operators (`&&`, `||`, `!`)',
      '`switch` statements',
    ],
    lessons: [
      {
        id: '3-1',
        levelNumber: 3,
        orderInLevel: 1,
        title: 'Comparisons & `if-else` Gateways',
        estimatedMinutes: 8,
        xpReward: 50,
        coinReward: 15,
        introduction:
          'Programs become smart when they can react to changing situations. An `if-else` statement acts like a railroad switch: if a condition is `true`, Java takes Track A; otherwise, it takes Track B.',
        conceptExplanation: [
          'Comparison operators test values and produce `true` or `false`: `==` (equal to), `!=` (not equal), `>=` (greater or equal), `<=` (less or equal), `>`, `<`.',
          'Watch out: `=` assigns a value (`int keys = 2;`), while `==` compares two values (`if (keys == 2)`).',
          'The remainder operator `%` (modulo) gives what is left over after division: `10 % 3` is `1`, and `8 % 2` is `0` (even!).',
        ],
        visualDemo: {
          kind: 'condition_gate',
          title: 'Castle Portcullis Decision Gate',
          caption: 'Adjust `keys` to watch the `if (keys >= 2)` condition route execution in real time.',
        },
        syntaxExample: `public class Main {
    public static void main(String[] args) {
        int keys = 2;
        if (keys >= 2) {
            System.out.println("Gate Open");
        } else {
            System.out.println("Gate Locked");
        }
    }
}`,
        lineByLine: [
          {
            line: 'if (keys >= 2) {',
            explanation: 'Checks whether `keys` is at least `2`. Since `2 >= 2` is `true`, this block runs.',
          },
          {
            line: '} else {',
            explanation: 'Runs ONLY when the `if` condition above evaluated to `false`.',
          },
        ],
        guidedPrompt:
          'Write an `if-else` check for `int power = 75;`: if `power >= 50`, print `"Drawbridge Lowered"`, otherwise print `"Need More Power"`.',
        independentPrompt:
          'Test your understanding by making sure both `if` and `else` branches exist in your code.',
        starterCode: `public class Main {
    public static void main(String[] args) {
        int power = 75;
        // Write your if-else decision below:
        
    }
}`,
        hints: [
          'Start with `if (power >= 50) { System.out.println("Drawbridge Lowered"); }`',
          'Follow immediately with `else { System.out.println("Need More Power"); }`',
        ],
        solutionCode: `public class Main {
    public static void main(String[] args) {
        int power = 75;
        if (power >= 50) {
            System.out.println("Drawbridge Lowered");
        } else {
            System.out.println("Need More Power");
        }
    }
}`,
        validation: {
          expectedOutputLines: ['Drawbridge Lowered'],
          requiredPatterns: [
            { regex: /\bif\s*\(/, message: 'Use an `if (...)` condition.' },
            { regex: /\belse\b/, message: 'Include an `else` branch for when power is below 50.' },
          ],
        },
      },
      {
        id: '3-2',
        levelNumber: 3,
        orderInLevel: 2,
        title: '`else if` Chains & Logical Operators (`&&`, `||`, `!`)',
        estimatedMinutes: 8,
        xpReward: 50,
        coinReward: 15,
        introduction:
          'What if a castle vault requires TWO conditions at once—such as having a royal seal AND at least 3 keys? Logical operators combine conditions cleanly without deeply tangled code.',
        conceptExplanation: [
          '`&&` (AND): `true` only when BOTH sides are true (`hasSeal && keys >= 3`).',
          '`||` (OR): `true` when AT LEAST ONE side is true (`isKing || hasPass`).',
          '`!` (NOT): flips `true` to `false` and `false` to `true` (`!isAlarmActive`).',
          'Use `else if (...)` when choosing between 3 or more mutually exclusive outcomes (e.g., Gold, Silver, or Bronze rank).',
        ],
        visualDemo: {
          kind: 'condition_gate',
          title: 'Dual-Lock `&&` Truth Evaluator',
          caption: 'Toggle inputs to see how `&&`, `||`, and `!` evaluate compound castle locks.',
        },
        syntaxExample: `public class Main {
    public static void main(String[] args) {
        boolean hasSeal = true;
        int keys = 3;
        if (hasSeal && keys >= 3) {
            System.out.println("Sanctuary Unlocked");
        } else if (hasSeal) {
            System.out.println("Find More Keys");
        } else {
            System.out.println("Access Denied");
        }
    }
}`,
        lineByLine: [
          {
            line: 'if (hasSeal && keys >= 3) {',
            explanation: 'Requires BOTH `hasSeal` to be `true` AND `keys` to be 3 or higher.',
          },
          {
            line: '} else if (hasSeal) {',
            explanation: 'Checked only if the first `if` was false; tests whether the player at least has the seal.',
          },
        ],
        guidedPrompt:
          'Given `boolean hasTorch = true;` and `int stamina = 80;`, write an `if` condition using `&&` that checks if `hasTorch` is true AND `stamina >= 60`, printing `"Secret Passage Open"`.',
        independentPrompt:
          'Add an `else` block printing `"Stay Back"` for safety.',
        starterCode: `public class Main {
    public static void main(String[] args) {
        boolean hasTorch = true;
        int stamina = 80;
        // Check both conditions using &&:
        
    }
}`,
        hints: [
          'Combine both checks inside one `if`: `if (hasTorch && stamina >= 60) { ... }`',
          'Inside the `if` block, print `"Secret Passage Open"`.',
        ],
        solutionCode: `public class Main {
    public static void main(String[] args) {
        boolean hasTorch = true;
        int stamina = 80;
        if (hasTorch && stamina >= 60) {
            System.out.println("Secret Passage Open");
        } else {
            System.out.println("Stay Back");
        }
    }
}`,
        validation: {
          expectedOutputLines: ['Secret Passage Open'],
          requiredPatterns: [
            { regex: /&&/, message: 'Use the logical AND operator `&&` to combine both conditions.' },
          ],
        },
      },
      {
        id: '3-3',
        levelNumber: 3,
        orderInLevel: 3,
        title: 'Multi-Way Routing with `switch`',
        estimatedMinutes: 8,
        xpReward: 50,
        coinReward: 15,
        introduction:
          'When a lever has numbered positions (1, 2, 3), a `switch` statement lets you match exact values cleanly instead of writing repetitive `else if` checks.',
        conceptExplanation: [
          '`switch (lever)` compares `lever` against each `case` label.',
          'Always end each `case` with `break;` so execution stops instead of "falling through" into the next case below!',
          'The `default:` section runs when none of the `case` values match.',
        ],
        visualDemo: {
          kind: 'condition_gate',
          title: 'Castle Lever `switch` Selector',
          caption: 'See how `switch` jumps directly to the matching `case` and stops at `break;`.',
        },
        syntaxExample: `public class Main {
    public static void main(String[] args) {
        int lever = 2;
        switch (lever) {
            case 1:
                System.out.println("North Gate");
                break;
            case 2:
                System.out.println("East Bridge");
                break;
            default:
                System.out.println("Standby");
        }
    }
}`,
        lineByLine: [
          {
            line: 'switch (lever) {',
            explanation: 'Evaluates `lever` (`2`) and looks for `case 2:`.',
          },
          {
            line: 'break;',
            explanation: 'Exits the `switch` block immediately so `default:` does not also run.',
          },
        ],
        guidedPrompt:
          'Complete the `switch (channel)` statement for `int channel = 3;` so `case 1` prints `"Tower"`, `case 2` prints `" Courtyard"`, `case 3` prints `"Main Keep"`, and `default` prints `"Unknown"`. Don’t forget `break;`!',
        independentPrompt:
          'Verify that only `"Main Keep"` is printed when `channel` is `3`.',
        starterCode: `public class Main {
    public static void main(String[] args) {
        int channel = 3;
        switch (channel) {
            case 1:
                System.out.println("Tower");
                break;
            case 2:
                System.out.println("Courtyard");
                break;
            // Add case 3 and default below:
            
        }
    }
}`,
        hints: [
          'Add `case 3: System.out.println("Main Keep"); break;`',
          'Add `default: System.out.println("Unknown");` right after.',
        ],
        solutionCode: `public class Main {
    public static void main(String[] args) {
        int channel = 3;
        switch (channel) {
            case 1:
                System.out.println("Tower");
                break;
            case 2:
                System.out.println("Courtyard");
                break;
            case 3:
                System.out.println("Main Keep");
                break;
            default:
                System.out.println("Unknown");
        }
    }
}`,
        validation: {
          expectedOutputLines: ['Main Keep'],
          requiredPatterns: [
            { regex: /\bswitch\s*\(/, message: 'Use a `switch` statement.' },
            { regex: /\bcase\s+3\s*:/, message: 'Include `case 3:` inside your `switch`.' },
          ],
        },
      },
    ],
    assessment: [
      {
        id: 'q3-1',
        question: 'Which operator tests whether two `int` values are equal inside an `if` condition?',
        options: ['=', '==', '!=', '&&'],
        correctIndex: 1,
        explanation: '`==` compares two values for equality, whereas a single `=` assigns a value.',
      },
      {
        id: 'q3-2',
        question: 'What does `if (true && !true)` evaluate to?',
        options: ['true', 'false', 'Syntax error', 'null'],
        correctIndex: 1,
        explanation: '`!true` is `false`, and `true && false` evaluates to `false` because `&&` requires both sides to be true.',
      },
      {
        id: 'q3-3',
        question: 'Why do we place `break;` at the end of a `case` inside a `switch` statement?',
        options: [
          'To restart the program from `main`',
          'To prevent execution from falling through into the next `case` below',
          'To delete the variable',
          'Java will not compile without `break;`',
        ],
        correctIndex: 1,
        explanation: 'Without `break;`, Java continues executing statements in subsequent `case` blocks (fall-through).',
      },
    ],
  },
  {
    levelNumber: 4,
    id: 'level-4',
    worldId: 'world-4',
    title: 'The Looping Mountains',
    subtitle: 'Level 4 · Repetition & Loops',
    themeName: 'Alpine Peaks & Sky Railway',
    accentColor: '#69B9E7',
    npcName: 'Kael',
    npcRole: 'Mountain Engineer',
    npcAvatarId: 'character-j',
    storyIntro:
      'High in the snow-dusted voxel peaks, the Mountain Sky Railway has stalled above a deep chasm. Engineer Kael taps his wrench: "Typing the same command fifty times by hand would take all day! With Java loops, three lines of code can power an entire chain of railway platforms."',
    learningObjective:
      'Automate repeated tasks safely using `for`, `while`, and `do-while` loops, understand loop counters, avoid infinite loops, and control flow with `break` and `continue`.',
    adventureUnlockText: 'Restart the Mountain Railway & Extend the 5-Platform Sky Bridge.',
    topics: [
      'Why loops beat manual copy-paste',
      '`for` loop (initialization, condition, update)',
      '`while` & `do-while` loops',
      'Increment (`i++`) & decrement (`i--`)',
      'Infinite loops & how to prevent them',
      '`break`, `continue`, & nested loops',
    ],
    lessons: [
      {
        id: '4-1',
        levelNumber: 4,
        orderInLevel: 1,
        title: 'Counting Precisely with `for` Loops',
        estimatedMinutes: 8,
        xpReward: 50,
        coinReward: 15,
        introduction:
          'When you know how many times an action should repeat—like raising 5 sky-bridge platforms—a `for` loop packs your starting point, stopping rule, and step size into one clean header!',
        conceptExplanation: [
          'A `for` header has 3 parts separated by semicolons: `for (int i = 1; i <= 5; i++)`.',
          '1. Initialization (`int i = 1`): runs once before the loop starts.',
          '2. Condition (`i <= 5`): checked before every turn (iteration). While `true`, the loop body runs.',
          '3. Update (`i++`): runs at the end of each turn, adding `1` to `i` until `i` reaches `6` and the loop stops cleanly.',
        ],
        visualDemo: {
          kind: 'loop_stepper',
          title: 'Interactive `for` Loop Stepper',
          caption: 'Step through `i = 1` to `5` and watch each iteration raise a mountain platform.',
        },
        syntaxExample: `public class Main {
    public static void main(String[] args) {
        for (int i = 1; i <= 5; i++) {
            System.out.println("Platform " + i);
        }
    }
}`,
        lineByLine: [
          {
            line: 'for (int i = 1; i <= 5; i++) {',
            explanation: 'Starts `i` at 1, repeats while `i <= 5`, and increments `i` by 1 each round.',
          },
          {
            line: 'System.out.println("Platform " + i);',
            explanation: 'Executes 5 times, printing `Platform 1` through `Platform 5` using only one `println`!',
          },
        ],
        guidedPrompt:
          'Use a single `for` loop to print the numbers `1`, `2`, `3`, `4`, `5` (each on its own line) to test Kael’s five bridge pistons.',
        independentPrompt:
          'Use only ONE `System.out.println` inside your `for` loop—no manual copy-pasting!',
        starterCode: `public class Main {
    public static void main(String[] args) {
        // Write a for loop that prints 1 through 5:
        
    }
}`,
        hints: [
          'Write `for (int i = 1; i <= 5; i++) { System.out.println(i); }`',
          'Make sure the condition is `i <= 5` so `5` is included.',
        ],
        solutionCode: `public class Main {
    public static void main(String[] args) {
        for (int i = 1; i <= 5; i++) {
            System.out.println(i);
        }
    }
}`,
        validation: {
          expectedOutputLines: ['1', '2', '3', '4', '5'],
          requiredPatterns: [{ regex: /\bfor\s*\(/, message: 'Use a `for` loop to repeat the print statement.' }],
          requireExactPrintCount: 1,
        },
      },
      {
        id: '4-2',
        levelNumber: 4,
        orderInLevel: 2,
        title: '`while` Loops, `do-while` & Avoiding Infinite Loops',
        estimatedMinutes: 8,
        xpReward: 50,
        coinReward: 15,
        introduction:
          'Sometimes you repeat an action while a condition holds—like venting steam pressure while `pressure > 0`. That is where `while` and `do-while` shine.',
        conceptExplanation: [
          '`while (condition) { ... }` checks the condition FIRST. If it starts `false`, the body runs zero times.',
          '`do { ... } while (condition);` runs the body ONCE first, then checks the condition.',
          'Crucial safety rule: something inside the loop MUST move the variable toward stopping (like `fuel--` or `charge += 25`). Forgetting to update the variable creates an infinite loop!',
        ],
        visualDemo: {
          kind: 'loop_stepper',
          title: 'Turbine Countdown & Infinite Loop Guard',
          caption: 'See why updating the loop variable each turn prevents runaway infinite loops.',
        },
        syntaxExample: `public class Main {
    public static void main(String[] args) {
        int countdown = 3;
        while (countdown > 0) {
            System.out.println("T-" + countdown);
            countdown--;
        }
        System.out.println("Launch!");
    }
}`,
        lineByLine: [
          {
            line: 'while (countdown > 0) {',
            explanation: 'Keeps looping as long as `countdown` remains greater than `0`.',
          },
          {
            line: 'countdown--;',
            explanation: 'Subtracts 1 each turn (`3 -> 2 -> 1 -> 0`) so the loop finishes after 3 turns.',
          },
        ],
        guidedPrompt:
          'Complete the `while` loop starting from `int charge = 25;` so while `charge <= 100`, it prints `charge` and then adds `25` (`charge += 25;`). Expected lines: `25`, `50`, `75`, `100`.',
        independentPrompt:
          'Remember to update `charge` inside the `while` braces so you don’t trigger an infinite loop!',
        starterCode: `public class Main {
    public static void main(String[] args) {
        int charge = 25;
        while (charge <= 100) {
            System.out.println(charge);
            // Increase charge by 25 each turn:
            
        }
    }
}`,
        hints: [
          'Add `charge += 25;` (or `charge = charge + 25;`) right below `System.out.println(charge);`.',
        ],
        solutionCode: `public class Main {
    public static void main(String[] args) {
        int charge = 25;
        while (charge <= 100) {
            System.out.println(charge);
            charge += 25;
        }
    }
}`,
        validation: {
          expectedOutputLines: ['25', '50', '75', '100'],
          requiredPatterns: [{ regex: /\bwhile\s*\(/, message: 'Keep the `while` loop structure.' }],
          requireExactPrintCount: 1,
        },
      },
      {
        id: '4-3',
        levelNumber: 4,
        orderInLevel: 3,
        title: 'Loop Control (`break`, `continue`) & Accumulating Totals',
        estimatedMinutes: 8,
        xpReward: 50,
        coinReward: 15,
        introduction:
          'Inside any loop, `continue` skips the rest of the current turn and jumps to the next turn, while `break` exits the loop early. Loops are also great for summing up totals!',
        conceptExplanation: [
          'To skip a damaged railway track #3, write `if (i == 3) { continue; }` before printing.',
          'To emergency-stop a loop as soon as a target is found, write `break;`.',
          'You can also place a loop inside another loop (a nested loop) to scan rows and columns of a 2D voxel grid.',
        ],
        visualDemo: {
          kind: 'loop_stepper',
          title: '`continue` Skip vs `break` Exit',
          caption: 'Watch `continue` hop over track #3 while keeping the rest of the railway sequence moving.',
        },
        syntaxExample: `public class Main {
    public static void main(String[] args) {
        for (int track = 1; track <= 4; track++) {
            if (track == 2) {
                continue;
            }
            System.out.println("Track " + track);
        }
    }
}`,
        lineByLine: [
          {
            line: 'if (track == 2) { continue; }',
            explanation: 'Skips printing when `track` is `2` and jumps straight to `track++` (`3`).',
          },
        ],
        guidedPrompt:
          'Loop `i` from `1` to `5`. Use `continue` to skip `i == 3`, and print the remaining numbers (`1`, `2`, `4`, `5`).',
        independentPrompt:
          'Use both `for` and `continue` in your solution.',
        starterCode: `public class Main {
    public static void main(String[] args) {
        for (int i = 1; i <= 5; i++) {
            // Skip 3 using continue, otherwise print i:
            
        }
    }
}`,
        hints: [
          'Inside the loop write: `if (i == 3) { continue; }`',
          'Below that `if`, write `System.out.println(i);`.',
        ],
        solutionCode: `public class Main {
    public static void main(String[] args) {
        for (int i = 1; i <= 5; i++) {
            if (i == 3) {
                continue;
            }
            System.out.println(i);
        }
    }
}`,
        validation: {
          expectedOutputLines: ['1', '2', '4', '5'],
          requiredPatterns: [
            { regex: /\bfor\s*\(/, message: 'Use a `for` loop.' },
            { regex: /\bcontinue\b/, message: 'Use `continue;` to skip `i == 3`.' },
          ],
          requireExactPrintCount: 1,
        },
      },
    ],
    assessment: [
      {
        id: 'q4-1',
        question: 'How many times does `for (int i = 0; i < 4; i++)` execute its body?',
        options: ['3 times', '4 times', '5 times', 'Infinite times'],
        correctIndex: 1,
        explanation: 'It runs for `i = 0, 1, 2, 3`—which is 4 iterations—and stops when `i` becomes `4`.',
      },
      {
        id: 'q4-2',
        question: 'What causes an infinite `while` loop?',
        options: [
          'Using curly braces `{}`',
          'The loop condition starts out `true` and nothing inside the loop ever makes it `false`',
          'Declaring an `int` before the loop',
          'Using `break;` inside the loop',
        ],
        correctIndex: 1,
        explanation: 'If the loop condition stays `true` forever because the counter never updates toward stopping, the loop never ends.',
      },
      {
        id: 'q4-3',
        question: 'Inside a loop, what is the difference between `continue` and `break`?',
        options: [
          '`continue` skips to the next iteration; `break` exits the loop completely',
          '`continue` stops the whole program; `break` pauses for 1 second',
          'They do the exact same thing',
          '`continue` only works in `switch` statements',
        ],
        correctIndex: 0,
        explanation: '`continue` skips the rest of the current iteration, whereas `break` terminates the loop immediately.',
      },
    ],
  },
  {
    levelNumber: 5,
    id: 'level-5',
    worldId: 'world-5',
    title: 'The Method Kingdom',
    subtitle: 'Level 5 · Modular Reusable Methods',
    themeName: 'Automated Voxel Metropolis',
    accentColor: '#8B5CF6',
    npcName: 'Nova',
    npcRole: 'City Architect',
    npcAvatarId: 'character-k',
    storyIntro:
      'Gleaming brass conduits and robotic towers fill the Method Kingdom, yet the automated grid is overloaded with duplicated wiring. City Architect Nova explains: "Instead of rewriting identical machine logic everywhere, wrap reusable instructions inside Java methods and call them whenever needed!"',
    learningObjective:
      'Define and call static methods, pass parameters and arguments, return computed values, use `void` methods, and understand method overloading and variable scope.',
    adventureUnlockText: 'Restore the Automated Factory Power Grid in 3D.',
    topics: [
      'What are methods & why modularize?',
      'Creating & calling `void` methods',
      'Parameters vs arguments',
      'Returning values with `return`',
      'Method overloading',
      'Local variable scope',
    ],
    lessons: [
      {
        id: '5-1',
        levelNumber: 5,
        orderInLevel: 1,
        title: 'Creating & Calling `void` Methods',
        estimatedMinutes: 8,
        xpReward: 50,
        coinReward: 15,
        introduction:
          'A method is a named mini-program inside your class. Once you define a method like `activateTurbine()`, you can trigger all of its instructions anywhere in `main` just by calling its name!',
        conceptExplanation: [
          'Define a helper method inside `class Main` (outside of `main`): `public static void greetUnit(String unit) { ... }`.',
          '`void` means the method performs an action (like printing) without sending a value back.',
          '`String unit` inside the parentheses is a parameter—it receives whatever argument you pass when calling `greetUnit("ALPHA");`.',
        ],
        visualDemo: {
          kind: 'method_machine',
          title: 'Reusable Factory Method Blueprint',
          caption: 'Call the same method with different arguments (`"ALPHA"`, `"BETA"`) without duplicating code.',
        },
        syntaxExample: `public class Main {
    public static void bootUnit(String name) {
        System.out.println("Unit " + name + " Online");
    }

    public static void main(String[] args) {
        bootUnit("ALPHA");
        bootUnit("BETA");
    }
}`,
        lineByLine: [
          {
            line: 'public static void bootUnit(String name) {',
            explanation: 'Defines a reusable method named `bootUnit` accepting one `String` parameter.',
          },
          {
            line: 'bootUnit("ALPHA");',
            explanation: 'Calls `bootUnit` with argument `"ALPHA"`, printing `Unit ALPHA Online`.',
          },
        ],
        guidedPrompt:
          'Define `public static void pingSector(String sector)` that prints `"Sector " + sector + " Ready"`, then call it twice in `main` for `"NORTH"` and `"SOUTH"`.',
        independentPrompt:
          'Keep only ONE `System.out.println` inside `pingSector` and call it twice from `main`!',
        starterCode: `public class Main {
    public static void pingSector(String sector) {
        System.out.println("Sector " + sector + " Ready");
    }

    public static void main(String[] args) {
        // Call pingSector for "NORTH" and "SOUTH":
        
    }
}`,
        hints: [
          'Inside `main`, write `pingSector("NORTH");` on one line and `pingSector("SOUTH");` on the next.',
        ],
        solutionCode: `public class Main {
    public static void pingSector(String sector) {
        System.out.println("Sector " + sector + " Ready");
    }

    public static void main(String[] args) {
        pingSector("NORTH");
        pingSector("SOUTH");
    }
}`,
        validation: {
          expectedOutputLines: ['Sector NORTH Ready', 'Sector SOUTH Ready'],
          requiredPatterns: [
            { regex: /pingSector\s*\(\s*"NORTH"\s*\)/, message: 'Call `pingSector("NORTH");` in `main`.' },
            { regex: /pingSector\s*\(\s*"SOUTH"\s*\)/, message: 'Call `pingSector("SOUTH");` in `main`.' },
          ],
          requireExactPrintCount: 1,
        },
      },
      {
        id: '5-2',
        levelNumber: 5,
        orderInLevel: 2,
        title: 'Parameters, Arguments & `return` Values',
        estimatedMinutes: 8,
        xpReward: 50,
        coinReward: 15,
        introduction:
          'Factory sensors often calculate a number and hand that answer back to `main`. Replacing `void` with a return type like `int` lets your method compute and `return` a result!',
        conceptExplanation: [
          '`public static int add(int a, int b)` promises to return an `int`.',
          'Inside the method, `return a + b;` sends the sum back to wherever `add(...)` was called.',
          'You can store the returned value in a variable (`int total = add(40, 60);`) or print it directly (`System.out.println(add(40, 60));`).',
        ],
        visualDemo: {
          kind: 'method_machine',
          title: 'Input Parameters -> Compute -> `return` Output',
          caption: 'Feed two `int` arguments into `add(a, b)` and watch the computed value return to `main`.',
        },
        syntaxExample: `public class Main {
    public static int add(int a, int b) {
        return a + b;
    }

    public static void main(String[] args) {
        int power = add(45, 55);
        System.out.println(power);
    }
}`,
        lineByLine: [
          {
            line: 'public static int add(int a, int b) {',
            explanation: 'Declares a method returning `int` that takes two integer parameters `a` and `b`.',
          },
          {
            line: 'return a + b;',
            explanation: 'Computes the sum and returns it immediately to the caller.',
          },
        ],
        guidedPrompt:
          'Create a method `public static int multiplyEnergy(int cells, int rate)` that returns `cells * rate`. Call `multiplyEnergy(6, 15)` in `main` and print the returned result (`90`).',
        independentPrompt:
          'Make sure `multiplyEnergy` uses `return` rather than printing directly inside the helper method.',
        starterCode: `public class Main {
    // Write public static int multiplyEnergy(int cells, int rate) here:
    

    public static void main(String[] args) {
        int output = multiplyEnergy(6, 15);
        System.out.println(output);
    }
}`,
        hints: [
          'Define `public static int multiplyEnergy(int cells, int rate) { return cells * rate; }` above `main`.',
        ],
        solutionCode: `public class Main {
    public static int multiplyEnergy(int cells, int rate) {
        return cells * rate;
    }

    public static void main(String[] args) {
        int output = multiplyEnergy(6, 15);
        System.out.println(output);
    }
}`,
        validation: {
          expectedOutputLines: ['90'],
          requiredPatterns: [
            { regex: /\bint\s+multiplyEnergy\s*\(/, message: 'Define `public static int multiplyEnergy(int cells, int rate)`.' },
            { regex: /\breturn\b/, message: 'Use the `return` keyword inside `multiplyEnergy`.' },
          ],
        },
      },
      {
        id: '5-3',
        levelNumber: 5,
        orderInLevel: 3,
        title: 'Method Overloading & Variable Scope',
        estimatedMinutes: 8,
        xpReward: 50,
        coinReward: 15,
        introduction:
          'Java allows two methods in the same class to share the same name as long as their parameter lists differ! This feature is called method overloading.',
        conceptExplanation: [
          'For example, `boost(int base)` can double a single power core, while `boost(int base, int bonus)` adds a bonus on top. Java picks the matching version based on how many arguments you pass.',
          'Scope rule: variables declared inside a method only exist inside that method’s curly braces `{ }` (local scope). Other methods cannot accidentally overwrite them!',
        ],
        visualDemo: {
          kind: 'method_machine',
          title: 'Overloaded Method Dispatcher',
          caption: 'Java routes 1-argument calls vs 2-argument calls to the matching overloaded signature.',
        },
        syntaxExample: `public class Main {
    public static int boost(int base) {
        return base * 2;
    }

    public static int boost(int base, int bonus) {
        return base * 2 + bonus;
    }

    public static void main(String[] args) {
        System.out.println(boost(10));
        System.out.println(boost(10, 5));
    }
}`,
        lineByLine: [
          {
            line: 'public static int boost(int base)',
            explanation: '1-parameter version of `boost`.',
          },
          {
            line: 'public static int boost(int base, int bonus)',
            explanation: '2-parameter overloaded version of `boost`.',
          },
        ],
        guidedPrompt:
          'Add an overloaded 2-parameter method `public static int area(int width, int height)` returning `width * height` alongside the existing 1-parameter square `area(int side)`. Print `area(4)` then `area(4, 7)`.',
        independentPrompt:
          'Expected console lines: `16` on line 1, `28` on line 2.',
        starterCode: `public class Main {
    public static int area(int side) {
        return side * side;
    }

    // Add overloaded area(int width, int height) below:
    

    public static void main(String[] args) {
        System.out.println(area(4));
        System.out.println(area(4, 7));
    }
}`,
        hints: [
          'Write `public static int area(int width, int height) { return width * height; }` above `main`.',
        ],
        solutionCode: `public class Main {
    public static int area(int side) {
        return side * side;
    }

    public static int area(int width, int height) {
        return width * height;
    }

    public static void main(String[] args) {
        System.out.println(area(4));
        System.out.println(area(4, 7));
    }
}`,
        validation: {
          expectedOutputLines: ['16', '28'],
          requiredPatterns: [
            {
              regex: /area\s*\(\s*int\s+\w+\s*,\s*int\s+\w+\s*\)/,
              message: 'Define the 2-parameter overloaded `area(int width, int height)` method.',
            },
          ],
        },
      },
    ],
    assessment: [
      {
        id: 'q5-1',
        question: 'What return type keyword do you use when a method performs an action without returning any value?',
        options: ['null', 'empty', 'void', 'static'],
        correctIndex: 2,
        explanation: '`void` tells Java the method does not return a value.',
      },
      {
        id: 'q5-2',
        question: 'What is method overloading in Java?',
        options: [
          'Calling a method inside an infinite loop',
          'Defining multiple methods with the same name but different parameter lists in the same class',
          'Writing more than 100 lines inside `main`',
          'Returning two values at once',
        ],
        correctIndex: 1,
        explanation: 'Method overloading lets methods share a descriptive name when they accept different numbers or types of parameters.',
      },
      {
        id: 'q5-3',
        question: 'If `int x = 10;` is declared inside `helper()`, can `main()` directly print `x`?',
        options: [
          'Yes, all variables are global in Java',
          'No, `x` has local scope limited to `helper()` unless returned',
          'Only if `x` is negative',
          'Only inside a `for` loop',
        ],
        correctIndex: 1,
        explanation: 'Variables declared inside a method are local to that method’s `{ }` block.',
      },
    ],
  },
  {
    levelNumber: 6,
    id: 'level-6',
    worldId: 'world-6',
    title: 'The Object Kingdom',
    subtitle: 'Level 6 · Classes, Objects, OOP & Arrays',
    themeName: 'Grand Citadel & Central Energy Core',
    accentColor: '#F5C451',
    npcName: 'Aegis',
    npcRole: 'Core Guardian',
    npcAvatarId: 'character-l',
    storyIntro:
      'At the heart of CODELAND floats the Grand Citadel, where crystal spires surround the flickering Central Energy Core. Core Guardian Aegis bows: "You have mastered output, variables, logic, loops, and methods. Now unite them through Object-Oriented Programming to rebuild CODELAND’s core entities!"',
    learningObjective:
      'Model real-world entities with Java classes, fields, constructors (`this`), methods, inheritance (`extends`), and arrays to complete CODELAND.',
    adventureUnlockText: 'Restore the Central Energy Core & Complete CODELAND.',
    topics: [
      'Classes vs Objects (blueprints vs instances)',
      'Fields & Constructors (`this` keyword)',
      'Instance methods & Encapsulation',
      'Inheritance (`extends`)',
      'Arrays (`int[]`, `.length`) & Strings',
      'Debugging mixed Java programs',
    ],
    lessons: [
      {
        id: '6-1',
        levelNumber: 6,
        orderInLevel: 1,
        title: 'Classes, Objects & Constructors',
        estimatedMinutes: 9,
        xpReward: 50,
        coinReward: 15,
        introduction:
          'In a game like CODELAND, every player, chest, and energy core has both data (name, health, charge) and actions. Object-Oriented Programming (OOP) lets you design a `class` blueprint once and stamp out as many `Object` instances as you need using `new`!',
        conceptExplanation: [
          'A `class` defines fields (properties like `String name;` and `int health;`).',
          'A constructor is a special setup block named identically to the class (`Player(String name, int health)`). Inside it, `this.name = name;` stores the incoming parameter into the object’s own field.',
          'Create an object with `new`: `Player hero = new Player("Alex", 100);` and read its fields with a dot `.`: `hero.name`.',
        ],
        visualDemo: {
          kind: 'object_blueprint',
          title: '`class Player` Blueprint -> `new Player(...)` Instances',
          caption: 'Stamp independent `Player` objects from a single class blueprint, each holding its own field values.',
        },
        syntaxExample: `class Player {
    String name;
    int health;

    Player(String name, int health) {
        this.name = name;
        this.health = health;
    }
}

public class Main {
    public static void main(String[] args) {
        Player p1 = new Player("Alex", 100);
        System.out.println(p1.name + ":" + p1.health);
    }
}`,
        lineByLine: [
          {
            line: 'class Player {',
            explanation: 'Defines the blueprint for `Player` objects with `name` and `health` fields.',
          },
          {
            line: 'this.name = name;',
            explanation: '`this.name` refers to the object field, setting it to the `name` parameter passed in.',
          },
          {
            line: 'Player p1 = new Player("Alex", 100);',
            explanation: 'Constructs a brand-new `Player` object stored in `p1`.',
          },
        ],
        guidedPrompt:
          'Complete the `Beacon` constructor so `this.region = region;` and `this.power = power;` are assigned, then create `new Beacon("Citadel", 100)` in `main` and print `b.region + " " + b.power`.',
        independentPrompt:
          'Expected console line: `Citadel 100`.',
        starterCode: `class Beacon {
    String region;
    int power;

    Beacon(String region, int power) {
        this.region = region;
        // Assign this.power below:
        
    }
}

public class Main {
    public static void main(String[] args) {
        Beacon b = new Beacon("Citadel", 100);
        System.out.println(b.region + " " + b.power);
    }
}`,
        hints: [
          'Inside `Beacon(String region, int power)`, add `this.power = power;`.',
        ],
        solutionCode: `class Beacon {
    String region;
    int power;

    Beacon(String region, int power) {
        this.region = region;
        this.power = power;
    }
}

public class Main {
    public static void main(String[] args) {
        Beacon b = new Beacon("Citadel", 100);
        System.out.println(b.region + " " + b.power);
    }
}`,
        validation: {
          expectedOutputLines: ['Citadel 100'],
          requiredPatterns: [
            { regex: /\bnew\s+Beacon\s*\(/, message: 'Instantiate `Beacon` with `new Beacon(...)`.' },
            { regex: /this\.power\s*=\s*power/, message: 'Assign `this.power = power;` inside the constructor.' },
          ],
        },
      },
      {
        id: '6-2',
        levelNumber: 6,
        orderInLevel: 2,
        title: 'Encapsulation, Instance Methods & Inheritance (`extends`)',
        estimatedMinutes: 9,
        xpReward: 50,
        coinReward: 15,
        introduction:
          'Objects don’t just hold data—they also have behaviors (instance methods like `chargeUp()` or `getStatus()`), protect their internal state (encapsulation), and share traits with specialized child classes (`extends` inheritance)!',
        conceptExplanation: [
          'Encapsulation means keeping fields safe (`private int energy;`) and exposing controlled methods like `getEnergy()` and `addEnergy(int amount)` so invalid values aren’t injected.',
          'Inheritance lets a child class reuse a parent class’s fields and methods using `extends`: `class GuardianBot extends Robot { ... }`.',
        ],
        visualDemo: {
          kind: 'object_blueprint',
          title: 'Encapsulated Methods & `extends` Hierarchy',
          caption: 'Interact with an object safely through its methods and see how child classes inherit parent behavior.',
        },
        syntaxExample: `class Machine {
    int energy = 50;
    void boost(int amount) {
        this.energy = this.energy + amount;
    }
}

class CoreReactor extends Machine {
    String label = "CORE-1";
}

public class Main {
    public static void main(String[] args) {
        CoreReactor c = new CoreReactor();
        c.boost(50);
        System.out.println(c.label + ":" + c.energy);
    }
}`,
        lineByLine: [
          {
            line: 'class CoreReactor extends Machine {',
            explanation: '`CoreReactor` inherits `energy` and `boost(...)` automatically from `Machine`.',
          },
          {
            line: 'c.boost(50);',
            explanation: 'Calls the inherited method on `c`, raising `c.energy` from `50` to `100`.',
          },
        ],
        guidedPrompt:
          'Call `core.boost(40);` on the `CoreUnit` instance (which `extends Machine` starting at `60` energy) so `core.getEnergy()` prints `100`.',
        independentPrompt:
          'Verify how `CoreUnit` inherits both `energy` and `boost` from `Machine`.',
        starterCode: `class Machine {
    int energy = 60;

    void boost(int amount) {
        this.energy = this.energy + amount;
    }

    int getEnergy() {
        return this.energy;
    }
}

class CoreUnit extends Machine {
}

public class Main {
    public static void main(String[] args) {
        CoreUnit core = new CoreUnit();
        // Call boost(40) on core, then print core.getEnergy():
        
    }
}`,
        hints: [
          'Write `core.boost(40);` and then `System.out.println(core.getEnergy());`.',
        ],
        solutionCode: `class Machine {
    int energy = 60;

    void boost(int amount) {
        this.energy = this.energy + amount;
    }

    int getEnergy() {
        return this.energy;
    }
}

class CoreUnit extends Machine {
}

public class Main {
    public static void main(String[] args) {
        CoreUnit core = new CoreUnit();
        core.boost(40);
        System.out.println(core.getEnergy());
    }
}`,
        validation: {
          expectedOutputLines: ['100'],
          requiredPatterns: [
            { regex: /\bextends\s+Machine\b/, message: 'Keep `CoreUnit extends Machine`.' },
            { regex: /core\.boost\s*\(\s*40\s*\)/, message: 'Call `core.boost(40);` to charge the inherited energy field.' },
          ],
        },
      },
      {
        id: '6-3',
        levelNumber: 6,
        orderInLevel: 3,
        title: 'Arrays & Final Grand Core Synthesis',
        estimatedMinutes: 10,
        xpReward: 50,
        coinReward: 15,
        introduction:
          'To balance all crystal pylons around the Central Core, storing `pylon1`, `pylon2`, `pylon3` separately is clumsy. A Java Array stores an entire ordered list of values in one variable!',
        conceptExplanation: [
          'Declare and initialize an integer array with curly braces: `int[] pylons = {20, 30, 50};`.',
          'Array indexes start at `0`! `pylons[0]` is `20`, `pylons[1]` is `30`, and `pylons[2]` is `50`.',
          '`pylons.length` tells you how many items are in the array (`3`), making `for (int i = 0; i < pylons.length; i++)` the classic pattern to process every element!',
        ],
        visualDemo: {
          kind: 'object_blueprint',
          title: 'Zero-Indexed Java Array `[0, 1, 2]`',
          caption: 'Walk `i` from `0` to `pylons.length - 1` to sum every crystal cell into the Central Core.',
        },
        syntaxExample: `public class Main {
    public static void main(String[] args) {
        int[] pylons = {25, 35, 40};
        int sum = 0;
        for (int i = 0; i < pylons.length; i++) {
            sum += pylons[i];
        }
        System.out.println("Core Charge: " + sum);
    }
}`,
        lineByLine: [
          {
            line: 'int[] pylons = {25, 35, 40};',
            explanation: 'Creates a 3-element `int` array indexed `0`, `1`, and `2`.',
          },
          {
            line: 'for (int i = 0; i < pylons.length; i++) {',
            explanation: 'Loops safely across valid indexes `0`, `1`, and `2` (`i < 3`).',
          },
        ],
        guidedPrompt:
          'Sum all elements of `int[] cells = {30, 30, 40};` using a `for` loop and `cells.length`, then print `"CORE RESTORED: " + total`.',
        independentPrompt:
          'Expected output: `CORE RESTORED: 100`.',
        starterCode: `public class Main {
    public static void main(String[] args) {
        int[] cells = {30, 30, 40};
        int total = 0;
        // Loop through cells using cells.length and add each element to total:
        
        System.out.println("CORE RESTORED: " + total);
    }
}`,
        hints: [
          'Write `for (int i = 0; i < cells.length; i++) { total += cells[i]; }`',
          'Remember array indexes start at `0` and stop at `i < cells.length`!',
        ],
        solutionCode: `public class Main {
    public static void main(String[] args) {
        int[] cells = {30, 30, 40};
        int total = 0;
        for (int i = 0; i < cells.length; i++) {
            total += cells[i];
        }
        System.out.println("CORE RESTORED: " + total);
    }
}`,
        validation: {
          expectedOutputLines: ['CORE RESTORED: 100'],
          requiredPatterns: [
            { regex: /cells\.length/, message: 'Use `cells.length` in your `for` loop condition.' },
            { regex: /cells\s*\[/, message: 'Access each element with `cells[i]`.' },
          ],
        },
      },
    ],
    assessment: [
      {
        id: 'q6-1',
        question: 'What is the relationship between a `class` and an `object` in Java?',
        options: [
          'An object is a comment; a class is a loop',
          'A class is the blueprint, and an object is a concrete instance created from that blueprint using `new`',
          'Objects can only store `boolean` values',
          'A class is created inside `System.out.println`',
        ],
        correctIndex: 1,
        explanation: 'A class defines fields, constructors, and methods as a blueprint; `new ClassName(...)` creates individual object instances.',
      },
      {
        id: 'q6-2',
        question: 'Given `int[] scores = {10, 20, 30};`, what is `scores[1]`?',
        options: ['10', '20', '30', 'ArrayIndexOutOfBoundsException'],
        correctIndex: 1,
        explanation: 'Java arrays are zero-indexed: `scores[0]` is `10`, `scores[1]` is `20`, and `scores[2]` is `30`.',
      },
      {
        id: 'q6-3',
        question: 'Inside a constructor `Player(String name)`, what does `this.name = name;` accomplish?',
        options: [
          'It deletes the parameter `name`',
          'It assigns the constructor parameter `name` to the current object’s `name` field',
          'It prints `name` to the console',
          'It creates a subclass',
        ],
        correctIndex: 1,
        explanation: '`this.name` disambiguates the object’s own instance field from the constructor parameter of the same name.',
      },
    ],
  },
];

export function getLessonById(lessonId: string) {
  for (const level of JAVA_CURRICULUM) {
    const found = level.lessons.find((l) => l.id === lessonId);
    if (found) return { level, lesson: found };
  }
  return null;
}

export function getLevelByNumber(levelNumber: number) {
  return JAVA_CURRICULUM.find((l) => l.levelNumber === levelNumber) || JAVA_CURRICULUM[0];
}
