import { CampaignLevel, CampaignWorldMeta, WorldSpec } from '../types/codeland';
import { ADVENTURE_WORLDS } from './worldsData';
import { CAMPAIGN_LEVELS_1_TO_40 } from './campaignWorlds1To3';
import { CAMPAIGN_WORLD_4_LEVELS } from './campaignWorld4';
import { CAMPAIGN_WORLD_5_LEVELS } from './campaignWorld5';
import { CAMPAIGN_WORLD_6A_LEVELS } from './campaignWorld6A';
import { CAMPAIGN_WORLD_6B_LEVELS } from './campaignWorld6B';

export const CAMPAIGN_WORLDS: CampaignWorldMeta[] = [
  {
    worldNumber: 1,
    worldId: 'world-1',
    name: 'Starter Forest',
    biomeTitle: 'Enchanted Voxel Woodland & Magical Beacons',
    levelRange: [1, 10],
    mentorName: 'Sprout',
    mentorRole: 'The Forest Guide',
    mentorAvatarId: 'character-g',
    story:
      'Once the thriving heart of CODELAND, Starter Forest now lies unfinished and silent. Guided by Sprout, learn Java fundamentals across 10 levels and physically rebuild all 10 forest landmarks—from the Magical Beacon and Wooden Bridge to the Grand Forest Settlement.',
    rewardBadgeId: 'forest-builder',
    rewardBadgeTitle: 'Forest Builder',
    rewardBonusXp: 150,
    accentColor: '#22D3EE',
  },
  {
    worldNumber: 2,
    worldId: 'world-2',
    name: 'Variable Avenue',
    biomeTitle: 'Crystal Resource Village & Floating Vaults',
    levelRange: [11, 25],
    mentorName: 'Vex',
    mentorRole: 'The Crystal Merchant',
    mentorAvatarId: 'character-h',
    story:
      'Variable Avenue has lost its resources because the crystal storage vaults are damaged. Learn how Java stores, converts, and manages typed data to rebuild Vex’s glowing crystal shops.',
    rewardBadgeId: 'crystal-collector',
    rewardBadgeTitle: 'Crystal Collector',
    rewardBonusXp: 150,
    accentColor: '#22D3EE',
  },
  {
    worldNumber: 3,
    worldId: 'world-3',
    name: 'Logic Kingdom',
    biomeTitle: 'Majestic Crystal Castle & Golden Gates',
    levelRange: [26, 40],
    mentorName: 'Logicus',
    mentorRole: 'The Royal Strategist',
    mentorAvatarId: 'character-i',
    story:
      'The branching pathways, magical gates, and golden defense towers of Logic Kingdom are frozen. Master Boolean logic, if-else chains, switch dials, and String comparisons with Logicus to reclaim the throne room.',
    rewardBadgeId: 'logic-master',
    rewardBadgeTitle: 'Logic Master',
    rewardBonusXp: 200,
    accentColor: '#F59E0B',
  },
  {
    worldNumber: 4,
    worldId: 'world-4',
    name: 'Looping Mountains',
    biomeTitle: 'Snowy Peaks, Waterfalls & Sky Bridges',
    levelRange: [41, 55],
    mentorName: 'Loopa',
    mentorRole: 'The Mountain Engineer',
    mentorAvatarId: 'character-j',
    story:
      'Highland cable cars, sky bridges, and mechanical relays have stalled across the snowy peaks. Team up with Loopa to automate repetitive mountain machinery using while, for, do-while, nested loops, and array traversal.',
    rewardBadgeId: 'loop-engineer',
    rewardBadgeTitle: 'Loop Engineer',
    rewardBonusXp: 200,
    accentColor: '#38BDF8',
  },
  {
    worldNumber: 5,
    worldId: 'world-5',
    name: 'Method Metro',
    biomeTitle: 'Futuristic Voxel Tech City & Neon Transit',
    levelRange: [56, 75],
    mentorName: 'Mech',
    mentorRole: 'The Metro Architect',
    mentorAvatarId: 'character-k',
    story:
      'Method Metro’s futuristic transit grid is tangled in duplicated scripts. Work with Mech to refactor neon-purple machinery and transport lines into clean Java methods with parameters, return values, overloading, and recursion.',
    rewardBadgeId: 'method-architect',
    rewardBadgeTitle: 'Method Architect',
    rewardBonusXp: 250,
    accentColor: '#A855F7',
  },
  {
    worldNumber: 6,
    worldId: 'world-6',
    name: 'Object Kingdom',
    biomeTitle: 'Floating Crystal Citadel & Central Energy Core',
    levelRange: [76, 100],
    mentorName: 'Aegis',
    mentorRole: 'The Core Guardian',
    mentorAvatarId: 'character-l',
    story:
      'High in the twilight sky floats Object Kingdom and its Central Energy Core. Master Classes, Encapsulation, Inheritance, Polymorphism, Abstraction, ArrayList, and Exception Handling to restore all six realms.',
    rewardBadgeId: 'codeland-java-champion',
    rewardBadgeTitle: 'CODELAND Java Champion',
    rewardBonusXp: 350,
    includesCertificate: true,
    accentColor: '#8B5CF6',
    parts: [
      { title: 'Part A — Classes and Objects', range: [76, 85] },
      { title: 'Part B — The Four Pillars of OOP', range: [86, 95] },
      { title: 'Part C — Object Kingdom Final Trials', range: [96, 100] },
    ],
  },
];

export interface DifficultyBandInfo {
  rangeLabel: string;
  title: string;
  summary: string;
}

export const DIFFICULTY_PROGRESSION_BANDS: DifficultyBandInfo[] = [
  {
    rangeLabel: 'Levels 1–10',
    title: 'Guided Foundations',
    summary: 'Single-concept print statements, program structure, syntax checks, and first Scanner input.',
  },
  {
    rangeLabel: 'Levels 11–25',
    title: 'Typed Storage & Expressions',
    summary: 'Variables, primitive types, arithmetic, type casting, String methods, and crystal ledgers.',
  },
  {
    rangeLabel: 'Levels 26–40',
    title: 'Branching & Strategic Logic',
    summary: 'Relational operators, if/else ladders, &&/||/!, switch statements, and String .equals().',
  },
  {
    rangeLabel: 'Levels 41–55',
    title: 'Automated Iteration & Arrays',
    summary: 'while, for, do-while, accumulators, break/continue, nested patterns, and array loops.',
  },
  {
    rangeLabel: 'Levels 56–75',
    title: 'Modular Architecture & Recursion',
    summary: 'Custom methods, parameters, return values, overloading, variable scope, and recursive calls.',
  },
  {
    rangeLabel: 'Levels 76–100',
    title: 'Object-Oriented Mastery & Core Trials',
    summary: 'Classes, constructors, 4 Pillars of OOP, interfaces, ArrayList<T>, try-catch, and Core Restoration.',
  },
];

export const CAMPAIGN_LEVELS_100: CampaignLevel[] = [
  ...CAMPAIGN_LEVELS_1_TO_40,
  ...CAMPAIGN_WORLD_4_LEVELS,
  ...CAMPAIGN_WORLD_5_LEVELS,
  ...CAMPAIGN_WORLD_6A_LEVELS,
  ...CAMPAIGN_WORLD_6B_LEVELS,
].sort((a, b) => a.levelNumber - b.levelNumber);

export function getWorldNumberForCampaignLevel(levelNumber: number): number {
  if (levelNumber <= 10) return 1;
  if (levelNumber <= 25) return 2;
  if (levelNumber <= 40) return 3;
  if (levelNumber <= 55) return 4;
  if (levelNumber <= 75) return 5;
  return 6;
}

export function getCampaignLevel(levelNumber: number): CampaignLevel {
  const clamped = Math.max(1, Math.min(100, Math.round(levelNumber || 1)));
  return (
    CAMPAIGN_LEVELS_100.find((lvl) => lvl.levelNumber === clamped) ||
    CAMPAIGN_LEVELS_100[0]
  );
}

export function getCampaignWorldMeta(worldNumberOrId: number | string): CampaignWorldMeta {
  if (typeof worldNumberOrId === 'number') {
    return (
      CAMPAIGN_WORLDS.find((w) => w.worldNumber === worldNumberOrId) ||
      CAMPAIGN_WORLDS[0]
    );
  }
  return (
    CAMPAIGN_WORLDS.find((w) => w.worldId === worldNumberOrId) ||
    CAMPAIGN_WORLDS[0]
  );
}

export function getLevelsForWorld(worldNumber: number): CampaignLevel[] {
  return CAMPAIGN_LEVELS_100.filter((lvl) => lvl.worldNumber === worldNumber);
}

/**
 * Builds the 3D WorldSpec for any campaign level 1..100 while preserving
 * `world.levelNumber = campaignLevel.worldNumber` (1..6) so VoxelAdventureCanvas
 * renders the exact procedural biome, lighting, water, and regional centerpiece.
 */
export function buildWorldSpecForCampaignLevel(campaignLevelNumber: number): WorldSpec {
  const campaignLevel = getCampaignLevel(campaignLevelNumber);
  const worldMeta = getCampaignWorldMeta(campaignLevel.worldNumber);
  const baseWorld =
    ADVENTURE_WORLDS.find((w) => w.worldId === campaignLevel.worldId) ||
    ADVENTURE_WORLDS[0];

  return {
    ...baseWorld,
    worldId: campaignLevel.worldId,
    levelNumber: campaignLevel.worldNumber, // MUST stay 1..6 for VoxelAdventureCanvas biome generator
    name: worldMeta.name,
    biomeTitle: worldMeta.biomeTitle,
    npcName: worldMeta.mentorName,
    npcRole: worldMeta.mentorRole,
    npcAvatarId: worldMeta.mentorAvatarId,
    npcDialogue: [
      ...campaignLevel.briefing.mentorDialogue,
      `Mission Objective: ${campaignLevel.briefing.missionObjective}`,
    ],
    missionTitle: `Level ${campaignLevel.levelNumber}: ${campaignLevel.mission3d.missionTitle}`,
    missionSummary: campaignLevel.mission3d.missionSummary,
    obstacles: campaignLevel.mission3d.obstacles,
  };
}
