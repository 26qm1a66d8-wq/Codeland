import { World1LevelSpec, World1SiteId } from '../types/codeland';

export const SPROUT_INTRO_QUOTE =
  'Welcome, Explorer! This forest was once the heart of CODELAND. Every structure here was created using instructions. Now the forest needs a new builder. You will learn Java and use your knowledge to rebuild this settlement, one structure at a time.';

export const WORLD1_SITE_ORDER: World1SiteId[] = [
  'beacon',
  'workshop',
  'gatehouse',
  'bridge',
  'staircase',
  'lantern_grove',
  'map_station',
  'repair_district',
  'registration_centre',
  'grand_settlement',
];

export const WORLD1_LEVELS: World1LevelSpec[] = [
  // =========================================================================
  // LEVEL 1 — WELCOME TO JAVA (The Beacon Clearing)
  // =========================================================================
  {
    levelNumber: 1,
    siteId: 'beacon',
    siteName: 'The Beacon Clearing',
    structureTitle: 'Magical Forest Beacon',
    structureType: 'magical_beacon',
    javaTopic: 'System.out.println() & Text Output',
    zoneSubtitle: 'Southwest Sunlit Clearing',
    sitePosition: [-26, 0, 28],
    spawnPosition: [-26, 0, 36.2],
    sproutPosition: [-23.8, 0, 34.0],
    terminalPosition: [-26.0, 0, 31.8],
    cameraLandmarkOffset: [-17, 9.5, 39],
    briefingHeadline: 'Awaken the Silent Forest Beacon',
    sproutDialogue: [
      SPROUT_INTRO_QUOTE,
      'Look ahead at the mossy stone ring in The Beacon Clearing. Its crystal core went dark years ago because its startup instructions were lost.',
      'In Java, we send clear text instructions to machines and screens using System.out.println("Your message");. Walk with me to each of the four beacon stations around the clearing to rebuild and ignite the Magical Beacon!',
    ],
    conceptHeadline: 'How Java Speaks: System.out.println()',
    conceptExplanation: [
      'A Java program is a sequence of exact instructions placed inside a class and a main method.',
      'System.out.println("..."); prints the text inside the double quotes (" ") and moves to a new line.',
      'Java is case-sensitive: System starts with a capital S, text strings must be wrapped in double quotes, and every statement ends with a semicolon (;).',
    ],
    workingExampleCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("Hello, Explorer!");
        System.out.println("Beacon Calibration Ready");
    }
}`,
    workingExampleNotes: [
      {
        line: 'public class Main {',
        explanation: 'Declares the Main class container that holds our Java instructions.',
      },
      {
        line: 'public static void main(String[] args) {',
        explanation: 'The starting point where Java begins running your program.',
      },
      {
        line: 'System.out.println("Hello, Explorer!");',
        explanation: 'Prints exact text inside double quotes to the console output.',
      },
    ],
    tasks: [
      {
        id: 'w1_l1_t1',
        taskNumber: 1,
        title: 'Stage 1: Lay the Stone Foundation',
        sproutInstruction:
          'Every great structure starts with a level base! Print "Welcome to CODELAND" so the builder bots lay the carved stone foundation.',
        sproutDialogueBubble:
          'Walk north to the South Foundation Stake at the edge of the clearing! Write System.out.println("Welcome to CODELAND"); so our builder bots carve the stone foundation!',
        stationPosition: [-26.0, 0, 31.8],
        stationLabel: 'South Foundation Stake',
        stationKind: 'stone_altar',
        sproutWaypoint: [-23.6, 0, 32.2],
        objective: 'Use System.out.println() to print exact text: Welcome to CODELAND',
        constructionStageLabel: 'Stage 1/4 · Stone Foundation',
        starterCode: `public class Main {
    public static void main(String[] args) {
        // Write a println statement that outputs: Welcome to CODELAND
        
    }
}`,
        solutionCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("Welcome to CODELAND");
    }
}`,
        hints: [
          'Write System.out.println("Welcome to CODELAND"); inside main.',
          'Check spelling and uppercase CODELAND, and end the line with a semicolon ;',
        ],
        validation: {
          expectedOutputLines: ['Welcome to CODELAND'],
          requiredPatterns: [
            {
              regex: /System\.out\.println\s*\(/,
              message: 'Use System.out.println(...) to transmit the foundation command.',
            },
          ],
        },
        xpBonus: 15,
        coinBonus: 5,
      },
      {
        id: 'w1_l1_t2',
        taskNumber: 2,
        title: 'Stage 2: Raise the Support Pillars',
        sproutInstruction:
          'The base is set! Now instruct the drones to erect the four carved stone pillars by printing "Building the Beacon".',
        sproutDialogueBubble:
          'The stone base is anchored! Follow me around to the West Pillar Pedestal and print "Building the Beacon" to raise all four carved support pillars!',
        stationPosition: [-29.8, 0, 28.0],
        stationLabel: 'West Pillar Pedestal',
        stationKind: 'pedestal',
        sproutWaypoint: [-29.6, 0, 30.4],
        objective: 'Print exact text: Building the Beacon',
        constructionStageLabel: 'Stage 2/4 · Carved Support Pillars',
        starterCode: `public class Main {
    public static void main(String[] args) {
        // Print: Building the Beacon
        System.out.println( );
    }
}`,
        solutionCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("Building the Beacon");
    }
}`,
        hints: [
          'Wrap Building the Beacon in double quotes: "Building the Beacon".',
          'Full line: System.out.println("Building the Beacon");',
        ],
        validation: {
          expectedOutputLines: ['Building the Beacon'],
          requiredPatterns: [
            {
              regex: /System\.out\.println\s*\(/,
              message: 'Use System.out.println(...) with double quotes.',
            },
          ],
        },
        xpBonus: 15,
        coinBonus: 5,
      },
      {
        id: 'w1_l1_t3',
        taskNumber: 3,
        title: 'Stage 3: Mount the Crystal Chamber',
        sproutInstruction:
          'Now let us hoist the emerald housing onto the pillars. Fix and complete the output instruction so it prints "Energy Core Ready".',
        sproutDialogueBubble:
          'Awesome pillars! Now walk across to the East Housing Winch and repair the broken println quote and semicolon to print "Energy Core Ready" and hoist the crystal chamber!',
        stationPosition: [-22.2, 0, 28.0],
        stationLabel: 'East Housing Winch',
        stationKind: 'pedestal',
        sproutWaypoint: [-22.4, 0, 30.4],
        objective: 'Print exact text: Energy Core Ready',
        constructionStageLabel: 'Stage 3/4 · Emerald Crystal Chamber',
        starterCode: `public class Main {
    public static void main(String[] args) {
        // Complete the string literal and semicolon:
        System.out.println("Energy Core Ready)
    }
}`,
        solutionCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("Energy Core Ready");
    }
}`,
        hints: [
          'Notice the closing double quote " and semicolon ; are missing at the end of the line.',
          'Change it to: System.out.println("Energy Core Ready");',
        ],
        validation: {
          expectedOutputLines: ['Energy Core Ready'],
          requiredPatterns: [
            {
              regex: /System\.out\.println\s*\(/,
              message: 'Use System.out.println("Energy Core Ready");',
            },
          ],
        },
        xpBonus: 15,
        coinBonus: 5,
      },
      {
        id: 'w1_l1_t4',
        taskNumber: 4,
        title: 'Stage 4: Ignite the Sky Beam',
        sproutInstruction:
          'Final step! Send two consecutive println instructions: "Beacon Activated" on line 1 and "Forest Awakens" on line 2 to launch the beam into the sky!',
        sproutDialogueBubble:
          'One last step! Walk behind the beacon to the North Sky-Beam Altar and print "Beacon Activated" then "Forest Awakens" to launch the emerald beam into the sky!',
        stationPosition: [-26.0, 0, 24.2],
        stationLabel: 'North Sky-Beam Altar',
        stationKind: 'stone_altar',
        sproutWaypoint: [-23.6, 0, 24.6],
        objective: 'Print two lines: "Beacon Activated" followed by "Forest Awakens"',
        constructionStageLabel: 'Stage 4/4 · Levitating Crystal & Sky Beam',
        starterCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("Beacon Activated");
        // Add a second println statement for: Forest Awakens
        
    }
}`,
        solutionCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("Beacon Activated");
        System.out.println("Forest Awakens");
    }
}`,
        hints: [
          'Add System.out.println("Forest Awakens"); right below the first println.',
          'Make sure both lines are inside main and end with semicolons.',
        ],
        validation: {
          expectedOutputLines: ['Beacon Activated', 'Forest Awakens'],
          requireExactPrintCount: 2,
        },
        xpBonus: 20,
        coinBonus: 10,
      },
    ],
    completionCelebration:
      'Brilliant work, Builder! The Magical Beacon shines high above the trees, guiding us eastward along the trail to the Hillside Compiler Workshop!',
  },

  // =========================================================================
  // LEVEL 2 — HOW JAVA WORKS: JDK, JRE AND JVM (Compiler Workshop Site)
  // =========================================================================
  {
    levelNumber: 2,
    siteId: 'workshop',
    siteName: 'The Compiler Workshop Site',
    structureTitle: 'Hillside Compiler Workshop',
    structureType: 'compiler_workshop',
    javaTopic: 'JDK, JRE, JVM & Compilation Pipeline',
    zoneSubtitle: 'Terraced Southern Hillside',
    sitePosition: [-6, 0, 26],
    spawnPosition: [-16.8, 0, 28.4],
    sproutPosition: [-15.0, 0, 27.1],
    terminalPosition: [-13.9, 0, 28.4],
    cameraLandmarkOffset: [3, 9.5, 37],
    briefingHeadline: 'Cross Workshop Creek & Activate the Compiler Workshop',
    sproutDialogue: [
      'The Compiler Workshop sits just across rushing Workshop Creek! Before forest machines can execute your Java code, your .java source file must be compiled into .class bytecode and run by the JVM.',
      'First we will use javac from the JDK to build a timber bridge across the creek, then compile the door lock bytecode to swing open the workshop doors.',
      'Inside the workshop, order & physically collect Brass Compiler Gears and a JVM Core Crystal from the Supply Merchant, carry them to the Execution Chamber, and launch the JVM with java Main!',
    ],
    conceptHeadline: 'From Source Code to Running Program: JDK → javac → Bytecode → JVM',
    conceptExplanation: [
      '1. Source Code (.java): You write human-readable Java instructions in Main.java using tools from the JDK (Java Development Kit).',
      '2. Compiler (javac Main.java): The JDK compiler checks syntax and translates Main.java into platform-independent bytecode stored in Main.class.',
      '3. Execution (java Main): The JRE supplies core libraries while the JVM executes the Main class (note: pass Main without .class or .java!).',
    ],
    workingExampleCode: `// 1. Compile source code in terminal:  javac Main.java
// 2. Run compiled class on the JVM:    java Main
public class Main {
    public static void main(String[] args) {
        System.out.println("1. Source: Main.java");
        System.out.println("2. Bytecode: Main.class");
        System.out.println("3. JVM Executing Main");
    }
}`,
    workingExampleNotes: [
      {
        line: 'javac Main.java',
        explanation: 'JDK compiler command—requires the .java file extension and produces Main.class.',
      },
      {
        line: 'java Main',
        explanation: 'JVM launcher command—takes the class name Main WITHOUT .class or .java!',
      },
      {
        line: 'System.out.println("2. Bytecode: Main.class");',
        explanation: 'Platform-independent bytecode generated by javac that runs on any JVM.',
      },
    ],
    tasks: [
      {
        id: 'w1_l2_t1',
        taskNumber: 1,
        title: 'Stage 1: Build the Creek Bridge with javac',
        sproutInstruction:
          'The compiler workshop is on the other side of this river. We need a bridge to reach it. Inspect Main.java at the Riverbank JDK Compiler Post and enter the exact JDK compile command in the terminal bar below!',
        sproutDialogueBubble:
          'The compiler workshop is on the other side of this river. We need a bridge to reach it. Walk to the Riverbank JDK Compiler Post and enter javac Main.java to compile the bridge blueprint!',
        stationPosition: [-13.9, 0, 28.4],
        stationLabel: 'Riverbank JDK Compiler Post',
        stationKind: 'riverbank_post',
        sproutWaypoint: [-14.8, 0, 27.2],
        objective: 'Enter the JDK compiler command javac Main.java to construct the Creek Bridge',
        constructionStageLabel: 'Stage 1/4 · Walkable Creek Timber Bridge',
        starterCode: `public class Main {
    public static void main(String[] args) {
        // Bridge blueprint ready — compile this file using the JDK terminal below!
        System.out.println("Bridge Span Aligned");
    }
}`,
        solutionCode: `public class Main {
    public static void main(String[] args) {
        // Bridge blueprint ready — compile this file using the JDK terminal below!
        System.out.println("Bridge Span Aligned");
    }
}`,
        hints: [
          'The JDK compiler tool is named javac, and you pass the full source filename Main.java.',
          'Type javac Main.java in the terminal command input at the bottom of the editor.',
        ],
        validation: {
          expectedOutputLines: ['Bridge Span Aligned'],
          cliCommandSpec: {
            promptLabel: 'JDK Terminal — Compile Main.java to build the Creek Bridge',
            placeholder: 'Type the JDK compile command for Main.java...',
            expectedCommand: 'javac Main.java',
            commandOnly: true,
            wrongCommandHints: [
              {
                pattern: /^java\s+Main(\.java|\.class)?$/i,
                message:
                  'java Main runs already-compiled bytecode on the JVM! First compile the source file with: javac Main.java',
              },
              {
                pattern: /^javac\s+Main$/i,
                message: 'Almost! javac needs the .java source extension: javac Main.java',
              },
              {
                pattern: /^javac\s+Main\.class$/i,
                message:
                  'Main.class is the output bytecode! Pass the .java source file to javac: javac Main.java',
              },
            ],
          },
        },
        xpBonus: 15,
        coinBonus: 5,
      },
      {
        id: 'w1_l2_t2',
        taskNumber: 2,
        title: 'Stage 2: Unlock the Compiler Workshop Doors',
        sproutInstruction:
          'Excellent! We crossed the bridge to the workshop, but the main entrance is locked. Complete Main.java so it prints "Bytecode: Main.class" and "Door Lock: Released", AND compile it with javac Main.java!',
        sproutDialogueBubble:
          "Excellent! Walk across our new bridge to the Workshop Entrance Bytecode Lock. Complete Main.java and compile it with javac Main.java so the wooden workshop doors swing open!",
        stationPosition: [-4.3, 0, 30.5],
        stationLabel: 'Workshop Entrance Bytecode Lock',
        stationKind: 'door_lock',
        sproutWaypoint: [-8.0, 0, 30.5],
        objective:
          'Print "Bytecode: Main.class" and "Door Lock: Released", then compile with javac Main.java',
        constructionStageLabel: 'Stage 2/4 · Unlocked Workshop Doors & Interior',
        starterCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("Bytecode: Main.class");
        // Complete line 2 so it prints: Door Lock: Released
        System.out.println("");
    }
}`,
        solutionCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("Bytecode: Main.class");
        System.out.println("Door Lock: Released");
    }
}`,
        hints: [
          'Put Door Lock: Released inside the second System.out.println("Door Lock: Released");',
          'Also enter javac Main.java in the terminal prompt below to generate the door bytecode!',
        ],
        validation: {
          expectedOutputLines: ['Bytecode: Main.class', 'Door Lock: Released'],
          cliCommandSpec: {
            promptLabel: 'JDK Door Compiler — Generate Main.class bytecode to unlock entrance',
            placeholder: 'Enter the JDK compile command...',
            expectedCommand: 'javac Main.java',
            wrongCommandHints: [
              {
                pattern: /^java\s+/i,
                message:
                  'Compile the source file into bytecode first using: javac Main.java',
              },
              {
                pattern: /^javac\s+Main$/i,
                message: 'Remember the .java extension when compiling: javac Main.java',
              },
            ],
          },
        },
        xpBonus: 15,
        coinBonus: 5,
      },
      {
        id: 'w1_l2_t3',
        taskNumber: 3,
        title: 'Stage 3: Order Workshop Materials Inside',
        sproutInstruction:
          'Now we are inside the workshop! Visit the Supply Merchant Counter on the left and write Java output statements ordering "Order: Brass Compiler Gears" and "Order: JVM Core Crystal" to spawn the supply crates!',
        sproutDialogueBubble:
          'The doors are open—walk right inside to the Supply Merchant Counter on the left! Write println orders for "Order: Brass Compiler Gears" and "Order: JVM Core Crystal", then pick up the crates!',
        stationPosition: [-8.2, 0.24, 25.6],
        stationLabel: 'Supply Merchant Counter',
        stationKind: 'merchant_counter',
        sproutWaypoint: [-7.6, 0.24, 27.8],
        spawnsCollectibleSupplyId: 'workshop_supplies',
        supplySpawnPosition: [-7.5, 0.24, 26.8],
        supplyLabel: 'Brass Compiler Gears & JVM Core Crates',
        objective:
          'Print "Order: Brass Compiler Gears" on line 1 and "Order: JVM Core Crystal" on line 2',
        constructionStageLabel: 'Stage 3/4 · Ordered Brass Gears & JVM Core Crates',
        starterCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("Order: Brass Compiler Gears");
        // Add a second println to order: Order: JVM Core Crystal
        
    }
}`,
        solutionCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("Order: Brass Compiler Gears");
        System.out.println("Order: JVM Core Crystal");
    }
}`,
        hints: [
          'Write System.out.println("Order: JVM Core Crystal"); below the first order line.',
          'Once your order succeeds, walk over to the glowing crates on the floor and press [E] or click them to pick them up!',
        ],
        validation: {
          expectedOutputLines: ['Order: Brass Compiler Gears', 'Order: JVM Core Crystal'],
        },
        xpBonus: 15,
        coinBonus: 5,
      },
      {
        id: 'w1_l2_t4',
        taskNumber: 4,
        title: 'Stage 4: Power Up the JVM Execution Chamber',
        sproutInstruction:
          'We have the materials! Complete all 4 steps of the Java execution pipeline in Main.java ("4. Execute: JVM Running") AND enter the JVM launch command java Main in the terminal bar to activate the entire workshop!',
        sproutDialogueBubble:
          'Collect the glowing Supply Crates on the workshop pallet first, then carry them to the JVM Main Execution Chamber on the right! Complete step 4 and run java Main to ignite the workshop!',
        stationPosition: [-3.9, 0.24, 25.4],
        stationLabel: 'JVM Main Execution Chamber',
        stationKind: 'execution_core',
        sproutWaypoint: [-4.7, 0.24, 27.6],
        requiresCollectedSupplyId: 'workshop_supplies',
        objective:
          'Complete the 4-line Java pipeline output and run the JVM command: java Main',
        constructionStageLabel: 'Stage 4/4 · Spinning Brass Gears, JVM Core & Roof',
        starterCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("1. Source: Main.java");
        System.out.println("2. Compile: javac Main.java");
        System.out.println("3. Bytecode: Main.class");
        // Add line 4 -> 4. Execute: JVM Running
        
    }
}`,
        solutionCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("1. Source: Main.java");
        System.out.println("2. Compile: javac Main.java");
        System.out.println("3. Bytecode: Main.class");
        System.out.println("4. Execute: JVM Running");
    }
}`,
        hints: [
          'Add System.out.println("4. Execute: JVM Running"); as the fourth line inside main.',
          'In the terminal bar, launch the compiled class on the JVM using java Main (never include .class!).',
        ],
        validation: {
          expectedOutputLines: [
            '1. Source: Main.java',
            '2. Compile: javac Main.java',
            '3. Bytecode: Main.class',
            '4. Execute: JVM Running',
          ],
          cliCommandSpec: {
            promptLabel: 'JVM Launcher — Execute compiled Main class on the Java Virtual Machine',
            placeholder: 'Type the JVM command to run Main...',
            expectedCommand: 'java Main',
            wrongCommandHints: [
              {
                pattern: /^javac\b/i,
                message:
                  'javac is the compiler! To EXECUTE compiled bytecode on the JVM, run: java Main',
              },
              {
                pattern: /^java\s+Main\.class$/i,
                message:
                  'Almost! Never include .class when launching on the JVM—use the class name only: java Main',
              },
              {
                pattern: /^java\s+Main\.java$/i,
                message: 'Run the compiled class by name without .java: java Main',
              },
            ],
          },
        },
        xpBonus: 20,
        coinBonus: 10,
      },
    ],
    completionCelebration:
      'The Hillside Compiler Workshop is alive—spinning brass compiler gears, glowing JVM core, and an open bridge across Workshop Creek! Follow the stone trail northeast to the Ancient Gatehouse!',
  },

  // =========================================================================
  // LEVEL 3 — JAVA PROGRAM STRUCTURE (The Ancient Gatehouse)
  // =========================================================================
  {
    levelNumber: 3,
    siteId: 'gatehouse',
    siteName: 'The Ancient Gatehouse',
    structureTitle: 'Ancient Stone Gatehouse',
    structureType: 'ancient_gatehouse',
    javaTopic: 'Program Structure: class & main()',
    zoneSubtitle: 'South-East Fortress Approach',
    sitePosition: [14, 0, 15],
    spawnPosition: [14, 0, 23.0],
    sproutPosition: [11.6, 0, 21.0],
    terminalPosition: [14.0, 0, 19.2],
    cameraLandmarkOffset: [22.5, 9.5, 26],
    briefingHeadline: 'Reconstruct the Ancient Stone Gatehouse',
    sproutDialogue: [
      'This collapsed stone archway once guarded the road toward the river crossing.',
      'Just like a gatehouse needs outer walls and a main entrance arch, every Java program needs a class declaration and a public static void main(String[] args) entry method.',
      'Walk with me to all four gatehouse stations to repair its Java program structure and raise the iron portcullis!',
    ],
    conceptHeadline: 'Anatomy of a Complete Java Program',
    conceptExplanation: [
      'Outer Blueprint — public class Main { ... }: Every line of Java code lives inside a class.',
      'Entry Point — public static void main(String[] args) { ... }: When the JVM starts your program, it looks specifically for this exact method signature.',
      'Execution Order: Statements inside main(...) run from top to bottom, one instruction after another.',
    ],
    workingExampleCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("Outer class loaded");
        System.out.println("Main method running");
    }
}`,
    workingExampleNotes: [
      {
        line: 'public class Main {',
        explanation: 'Defines the class named Main.',
      },
      {
        line: 'public static void main(String[] args) {',
        explanation: 'Required entry method signature with String[] args parameter.',
      },
      {
        line: '    }',
        explanation: 'Closes main first, then the final } closes class Main.',
      },
    ],
    tasks: [
      {
        id: 'w1_l3_t1',
        taskNumber: 1,
        title: 'Stage 1: Anchor the Class Foundation',
        sproutInstruction:
          'Line 1 is missing its class declaration! Repair the outer class header so the program compiles and prints "Gate Foundation Set".',
        sproutDialogueBubble:
          'Walk up to the South Gate Threshold Stone! Add the missing class keyword in public class Main { so the foundation stones lock into place!',
        stationPosition: [14.0, 0, 19.2],
        stationLabel: 'South Gate Threshold Stone',
        stationKind: 'stone_altar',
        sproutWaypoint: [11.6, 0, 19.6],
        objective: 'Fix the public class Main header and print "Gate Foundation Set"',
        constructionStageLabel: 'Stage 1/4 · Stone Gate Foundation',
        starterCode: `// Fix line 2 so Main is declared as a public class:
public Main {
    public static void main(String[] args) {
        System.out.println("Gate Foundation Set");
    }
}`,
        solutionCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("Gate Foundation Set");
    }
}`,
        hints: [
          'Every Java class header needs the keyword class before the class name.',
          'Update line 2 to: public class Main {',
        ],
        validation: {
          expectedOutputLines: ['Gate Foundation Set'],
          requiredPatterns: [
            {
              regex: /public\s+class\s+Main/,
              message: 'Include public class Main { at the top of the program.',
            },
          ],
        },
        xpBonus: 15,
        coinBonus: 5,
      },
      {
        id: 'w1_l3_t2',
        taskNumber: 2,
        title: 'Stage 2: Build the main() Entry Arch',
        sproutInstruction:
          'Now write the missing main method header inside Main so the JVM knows where to enter! Have it print "Main Archway Built".',
        sproutDialogueBubble:
          'Great start! Walk over to the West Archway Pillar Pedestal and wrap the statement inside public static void main(String[] args) { ... } to raise the gatehouse walls!',
        stationPosition: [10.0, 0, 15.8],
        stationLabel: 'West Archway Pillar Pedestal',
        stationKind: 'pedestal',
        sproutWaypoint: [9.8, 0, 18.2],
        objective: 'Add public static void main(String[] args) and print "Main Archway Built"',
        constructionStageLabel: 'Stage 2/4 · Crenellated Gate Walls',
        starterCode: `public class Main {
    // Add the public static void main(String[] args) method below:
    
        System.out.println("Main Archway Built");
    
}`,
        solutionCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("Main Archway Built");
    }
}`,
        hints: [
          'Wrap the println inside: public static void main(String[] args) { ... }',
          'Remember both the opening { after (String[] args) and closing } after println.',
        ],
        validation: {
          expectedOutputLines: ['Main Archway Built'],
          requiredPatterns: [
            {
              regex: /public\s+static\s+void\s+main\s*\(\s*String\s*\[\s*\]\s*\w+\s*\)/,
              message: 'Write the full signature: public static void main(String[] args)',
            },
          ],
        },
        xpBonus: 15,
        coinBonus: 5,
      },
      {
        id: 'w1_l3_t3',
        taskNumber: 3,
        title: 'Stage 3: Align the Twin Watchtowers',
        sproutInstruction:
          'Uh-oh! A windstorm scrambled the order of these lines—main is sitting outside class Main! Reorder them properly so it prints "West Tower Up" then "East Tower Up".',
        sproutDialogueBubble:
          'Head across to the East Watchtower Control Post! Place main(String[] args) properly inside public class Main { ... } to erect both watchtowers!',
        stationPosition: [18.0, 0, 15.8],
        stationLabel: 'East Watchtower Control Post',
        stationKind: 'pedestal',
        sproutWaypoint: [18.2, 0, 18.2],
        objective: 'Place main() inside class Main and print "West Tower Up" then "East Tower Up"',
        constructionStageLabel: 'Stage 3/4 · Twin Stone Watchtowers',
        starterCode: `// Rearrange these scrambled parts into a valid Java program:
public static void main(String[] args) {
    System.out.println("West Tower Up");
    System.out.println("East Tower Up");
}
public class Main {
}`,
        solutionCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("West Tower Up");
        System.out.println("East Tower Up");
    }
}`,
        hints: [
          'public class Main { must wrap around public static void main(String[] args) { ... }.',
          'Move the main method inside the curly braces of public class Main.',
        ],
        validation: {
          expectedOutputLines: ['West Tower Up', 'East Tower Up'],
          requiredPatterns: [
            {
              regex: /public\s+class\s+Main\s*\{[\s\S]*public\s+static\s+void\s+main/,
              message: 'Ensure public static void main(...) is nested inside public class Main { ... }.',
            },
          ],
        },
        xpBonus: 15,
        coinBonus: 5,
      },
      {
        id: 'w1_l3_t4',
        taskNumber: 4,
        title: 'Stage 4: Open the Ancient Portcullis',
        sproutInstruction:
          'Now write a complete Java program from scratch! Declare public class Main, add public static void main(String[] args), and print "Ancient Gate Open".',
        sproutDialogueBubble:
          'Walk through the archway to the North Portcullis Winch! Write a full Java class and main() method from scratch printing "Ancient Gate Open" to raise the iron gate!',
        stationPosition: [14.0, 0, 11.2],
        stationLabel: 'North Portcullis Winch',
        stationKind: 'door_lock',
        sproutWaypoint: [11.8, 0, 11.4],
        objective: 'Write a full Java program from scratch that prints "Ancient Gate Open"',
        constructionStageLabel: 'Stage 4/4 · Raised Portcullis & Gate Banners',
        starterCode: `// Write the complete Java class and main method from scratch:
`,
        solutionCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("Ancient Gate Open");
    }
}`,
        hints: [
          'Start with public class Main { and inside it write public static void main(String[] args) {',
          'Inside main, write System.out.println("Ancient Gate Open"); and close both braces } }.',
        ],
        validation: {
          expectedOutputLines: ['Ancient Gate Open'],
          requiredPatterns: [
            {
              regex: /public\s+class\s+Main/,
              message: 'Declare public class Main.',
            },
            {
              regex: /public\s+static\s+void\s+main\s*\(\s*String\s*\[\s*\]\s*\w+\s*\)/,
              message: 'Include public static void main(String[] args).',
            },
          ],
        },
        xpBonus: 20,
        coinBonus: 10,
      },
    ],
    completionCelebration:
      'The iron portcullis rises with a triumphant clank! Head north along the stone path to the rushing river at The Wooden Bridge Site!',
  },

  // =========================================================================
  // LEVEL 4 — STATEMENTS AND SEMICOLONS (The Wooden Bridge Site)
  // =========================================================================
  {
    levelNumber: 4,
    siteId: 'bridge',
    siteName: 'The Wooden Bridge Site',
    structureTitle: 'Timber River Bridge',
    structureType: 'wooden_bridge',
    javaTopic: 'Java Statements & Semicolons (;)',
    zoneSubtitle: 'Silverstream River Crossing',
    sitePosition: [14, 0, 0],
    spawnPosition: [14, 0, 9.0],
    sproutPosition: [11.6, 0, 7.2],
    terminalPosition: [11.2, 0, 5.4],
    cameraLandmarkOffset: [23.5, 8.8, 9.5],
    briefingHeadline: 'Span the Silverstream River',
    sproutDialogue: [
      'The Silverstream River cuts right across the forest! The old bridge washed away, blocking access to the northern hills and village.',
      'In Java, each complete action is called a statement, and every statement must end with a semicolon (;), just like a period ends a sentence.',
      'Work along the south riverbank stations to lay the timber deck—then walk right across your new bridge to the north bank for the final stage!',
    ],
    conceptHeadline: 'Statements & Semicolons (;)',
    conceptExplanation: [
      'A statement is a single executable instruction, such as System.out.println("Lay plank");',
      'The semicolon (;) tells the Java compiler exactly where one statement finishes and the next begins.',
      'Forgetting even a single semicolon causes a compilation error: ";" expected.',
    ],
    workingExampleCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("Anchor South Bank");
        System.out.println("Anchor North Bank");
        System.out.println("Bridge Ready");
    }
}`,
    workingExampleNotes: [
      {
        line: 'System.out.println("Anchor South Bank");',
        explanation: 'First statement, cleanly terminated with ;',
      },
      {
        line: 'System.out.println("Anchor North Bank");',
        explanation: 'Second statement runs immediately after the first.',
      },
    ],
    tasks: [
      {
        id: 'w1_l4_t1',
        taskNumber: 1,
        title: 'Stage 1: Anchor the Stone Abutments',
        sproutInstruction:
          'This instruction to anchor both riverbanks is missing its semicolon! Fix it so it outputs "Abutments Anchored".',
        sproutDialogueBubble:
          'Walk to the West Bank Abutment Post beside the river! Add the missing semicolon (;) at the end of println so the stone abutments anchor into both banks!',
        stationPosition: [11.2, 0, 5.4],
        stationLabel: 'West Bank Abutment Post',
        stationKind: 'riverbank_post',
        sproutWaypoint: [9.4, 0, 6.2],
        objective: 'Fix the missing semicolon to print "Abutments Anchored"',
        constructionStageLabel: 'Stage 1/4 · Riverbank Stone Abutments',
        starterCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("Abutments Anchored")
    }
}`,
        solutionCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("Abutments Anchored");
    }
}`,
        hints: [
          'Look at the end of line 3: Java expects a ; right after the closing parenthesis ).',
        ],
        validation: {
          expectedOutputLines: ['Abutments Anchored'],
        },
        xpBonus: 15,
        coinBonus: 5,
      },
      {
        id: 'w1_l4_t2',
        taskNumber: 2,
        title: 'Stage 2: Drive the River Support Pilings',
        sproutInstruction:
          'Both piling instructions are missing their semicolons! Terminate both statements properly to drive the oak beams into the riverbed.',
        sproutDialogueBubble:
          'Now walk east along the bank to the East Bank Piling Winch! Add semicolons to both statements to drive sturdy oak pilings into the riverbed!',
        stationPosition: [16.8, 0, 5.2],
        stationLabel: 'East Bank Piling Winch',
        stationKind: 'riverbank_post',
        sproutWaypoint: [18.4, 0, 6.0],
        objective: 'Fix both statements to print "South Piling Set" and "North Piling Set"',
        constructionStageLabel: 'Stage 2/4 · Oak Riverbed Support Pilings',
        starterCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("South Piling Set")
        System.out.println("North Piling Set")
    }
}`,
        solutionCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("South Piling Set");
        System.out.println("North Piling Set");
    }
}`,
        hints: ['Add a semicolon ; at the end of line 3 and line 4.'],
        validation: {
          expectedOutputLines: ['South Piling Set', 'North Piling Set'],
        },
        xpBonus: 15,
        coinBonus: 5,
      },
      {
        id: 'w1_l4_t3',
        taskNumber: 3,
        title: 'Stage 3: Lay the Walkable Bridge Planks',
        sproutInstruction:
          'Three plank instructions were jammed onto lines without semicolons! Fix them so Java prints "Plank Section 1", "Plank Section 2", and "Bridge Deck Ready" to unlock river crossing!',
        sproutDialogueBubble:
          'Step to the South Bridgehead Plank Bench right at the water’s edge! Add semicolons to all three plank statements so we can walk across the river!',
        stationPosition: [14.0, 0, 4.6],
        stationLabel: 'South Bridgehead Plank Bench',
        stationKind: 'anvil_bench',
        sproutWaypoint: [11.8, 0, 4.8],
        objective:
          'Repair all three statements to print "Plank Section 1", "Plank Section 2", and "Bridge Deck Ready"',
        constructionStageLabel: 'Stage 3/4 · Walkable Timber Plank Deck',
        starterCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("Plank Section 1")
        System.out.println("Plank Section 2")
        System.out.println("Bridge Deck Ready")
    }
}`,
        solutionCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("Plank Section 1");
        System.out.println("Plank Section 2");
        System.out.println("Bridge Deck Ready");
    }
}`,
        hints: [
          'Every System.out.println(...) line must end with ;',
          'Check all three lines inside main.',
        ],
        validation: {
          expectedOutputLines: ['Plank Section 1', 'Plank Section 2', 'Bridge Deck Ready'],
        },
        xpBonus: 15,
        coinBonus: 5,
      },
      {
        id: 'w1_l4_t4',
        taskNumber: 4,
        title: 'Stage 4: Install Bridge Railings & Lanterns',
        sproutInstruction:
          'Write three clean, semicolon-terminated statements to install the bridge railings and warm lanterns: "West Railing", "East Railing", and "Bridge Complete"!',
        sproutDialogueBubble:
          'The planks are down! Walk right across our new bridge to the North Bank Lantern Post and write 3 semicolon-ended println statements for the railings and river lanterns!',
        stationPosition: [14.0, 0, -5.4],
        stationLabel: 'North Bank Lantern Post',
        stationKind: 'lantern_pedestal',
        sproutWaypoint: [11.6, 0, -5.6],
        objective: 'Write 3 statements printing "West Railing", "East Railing", and "Bridge Complete"',
        constructionStageLabel: 'Stage 4/4 · Rope Railings & River Lanterns',
        starterCode: `public class Main {
    public static void main(String[] args) {
        // Write 3 println statements with semicolons:
        // 1. West Railing
        // 2. East Railing
        // 3. Bridge Complete
        
    }
}`,
        solutionCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("West Railing");
        System.out.println("East Railing");
        System.out.println("Bridge Complete");
    }
}`,
        hints: [
          'Use three System.out.println("..."); lines, each ending with ;',
          'Exact lines: West Railing, East Railing, Bridge Complete.',
        ],
        validation: {
          expectedOutputLines: ['West Railing', 'East Railing', 'Bridge Complete'],
          requireExactPrintCount: 3,
        },
        xpBonus: 20,
        coinBonus: 10,
      },
    ],
    completionCelebration:
      'The Timber River Bridge is solid underfoot! Walk straight across the Silverstream River and follow the trail northwest to The Forest Staircase Hill!',
  },

  // =========================================================================
  // LEVEL 5 — CODE BLOCKS AND INDENTATION (The Forest Staircase Hill)
  // =========================================================================
  {
    levelNumber: 5,
    siteId: 'staircase',
    siteName: 'The Forest Staircase Hill',
    structureTitle: 'Grand Cliffside Staircase',
    structureType: 'forest_staircase',
    javaTopic: 'Curly Braces { }, Code Blocks & Indentation',
    zoneSubtitle: 'Northern Highland Escarpment',
    sitePosition: [-10, 0, -13],
    spawnPosition: [-5.2, 0, -6.5],
    sproutPosition: [-7.2, 0, -7.2],
    terminalPosition: [-10.0, 0, -7.4],
    cameraLandmarkOffset: [-1, 10.5, -2],
    briefingHeadline: 'Build the Staircase Up the Highland Cliff',
    sproutDialogue: [
      'You crossed the river! Above us rises the Highland Escarpment where the Signal Lantern Grove and Ranger’s Map Station sit.',
      'In Java, curly braces { and } group statements together into neat, sturdy code blocks—just like stone risers lock together to form a staircase.',
      'Climb step by step as each stage builds higher up the cliffside until you reach the Highland Summit Overlook!',
    ],
    conceptHeadline: 'Curly Braces { } and Clean Indentation',
    conceptExplanation: [
      'Every opening curly brace { must have a matching closing curly brace }.',
      'Code blocks nest inside one another: main’s { } block sits inside class Main’s { } block.',
      'Indentation (4 spaces per level) visually shows which block each statement belongs to, making bugs easy to spot.',
    ],
    workingExampleCode: `public class Main {
    public static void main(String[] args) {
        {
            System.out.println("Step 1: Inner block");
        }
        System.out.println("Step 2: Main block");
    }
}`,
    workingExampleNotes: [
      {
        line: 'public class Main {',
        explanation: 'Level 0: Opens class block.',
      },
      {
        line: '    public static void main(String[] args) {',
        explanation: 'Indented 4 spaces: Opens main method block.',
      },
      {
        line: '        System.out.println(...);',
        explanation: 'Indented 8 spaces: Statements inside main.',
      },
    ],
    tasks: [
      {
        id: 'w1_l5_t1',
        taskNumber: 1,
        title: 'Stage 1: Carve the Lower Cliff Steps',
        sproutInstruction:
          'This program has two opening braces { but only one closing brace }! Add the missing brace so it prints "Lower Steps Carved".',
        sproutDialogueBubble:
          'Meet me at the Cliff Base Mason Altar! Add the missing closing curly brace } at the bottom so our first flight of stone steps is carved into the slope!',
        stationPosition: [-10.0, 0, -7.4],
        stationLabel: 'Cliff Base Mason Altar',
        stationKind: 'stone_altar',
        sproutWaypoint: [-7.6, 0, -7.4],
        objective: 'Balance the curly braces and print "Lower Steps Carved"',
        constructionStageLabel: 'Stage 1/4 · Lower Stone Steps',
        starterCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("Lower Steps Carved");
    }
// Add the missing closing brace below:
`,
        solutionCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("Lower Steps Carved");
    }
}`,
        hints: ['Count your { and }: two { means you need two } at the end!'],
        validation: {
          expectedOutputLines: ['Lower Steps Carved'],
        },
        xpBonus: 15,
        coinBonus: 5,
      },
      {
        id: 'w1_l5_t2',
        taskNumber: 2,
        title: 'Stage 2: Construct the Middle Landing',
        sproutInstruction:
          'Here main(String[] args) is missing its opening brace {! Add the opening brace and keep clean indentation to print "Middle Landing Ready".',
        sproutDialogueBubble:
          'Walk up the lower steps to the Lower Flight Riser Marker! Add the missing opening { after main(String[] args) to build the mid-cliff stone landing!',
        stationPosition: [-10.0, 0.97, -10.6],
        stationLabel: 'Lower Flight Riser Marker',
        stationKind: 'pedestal',
        sproutWaypoint: [-11.6, 0.97, -10.4],
        objective: 'Add the missing opening brace { on main() and print "Middle Landing Ready"',
        constructionStageLabel: 'Stage 2/4 · Mid-Cliff Stone Landing',
        starterCode: `public class Main {
    public static void main(String[] args)
        System.out.println("Middle Landing Ready");
    }
}`,
        solutionCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("Middle Landing Ready");
    }
}`,
        hints: ['Place an opening { right after public static void main(String[] args)'],
        validation: {
          expectedOutputLines: ['Middle Landing Ready'],
        },
        xpBonus: 15,
        coinBonus: 5,
      },
      {
        id: 'w1_l5_t3',
        taskNumber: 3,
        title: 'Stage 3: Raise the Upper Stair Flight',
        sproutInstruction:
          'An inner code block inside main lost its closing brace }! Fix the nested block so it prints "Upper Flight Built" and "Cliff Path Open".',
        sproutDialogueBubble:
          'Climb onto the Mid-Cliff Landing Pedestal! Close the nested { ... } block cleanly so the upper highland steps unlock all the way to the ridge!',
        stationPosition: [-10.0, 2.17, -13.8],
        stationLabel: 'Mid-Cliff Landing Pedestal',
        stationKind: 'pedestal',
        sproutWaypoint: [-8.4, 2.17, -13.6],
        objective: 'Fix the nested block braces to print "Upper Flight Built" then "Cliff Path Open"',
        constructionStageLabel: 'Stage 3/4 · Upper Highland Steps',
        starterCode: `public class Main {
    public static void main(String[] args) {
        {
            System.out.println("Upper Flight Built");
        // Close the inner block cleanly before printing Cliff Path Open:
        System.out.println("Cliff Path Open");
    }
}`,
        solutionCode: `public class Main {
    public static void main(String[] args) {
        {
            System.out.println("Upper Flight Built");
        }
        System.out.println("Cliff Path Open");
    }
}`,
        hints: [
          'Add a closing } right after System.out.println("Upper Flight Built"); to close the inner { block.',
        ],
        validation: {
          expectedOutputLines: ['Upper Flight Built', 'Cliff Path Open'],
        },
        xpBonus: 15,
        coinBonus: 5,
      },
      {
        id: 'w1_l5_t4',
        taskNumber: 4,
        title: 'Stage 4: Complete the Summit Overlook Deck',
        sproutInstruction:
          'Untangle this program into a cleanly braced, valid Java class that prints "Summit Reached" and "Staircase Complete"!',
        sproutDialogueBubble:
          'Climb all the way to the Highland Summit Overlook Altar at the top of the stairs! Fix both missing braces on main() to finish the overlook deck and railings!',
        stationPosition: [-10.0, 3.6, -18.6],
        stationLabel: 'Highland Summit Overlook Altar',
        stationKind: 'stone_altar',
        sproutWaypoint: [-12.2, 3.6, -18.8],
        objective: 'Fix missing braces in the squished code to print "Summit Reached" and "Staircase Complete"',
        constructionStageLabel: 'Stage 4/4 · Summit Overlook Deck & Timber Railings',
        starterCode: `// Fix the missing braces and format cleanly:
public class Main {
    public static void main(String[] args)
        System.out.println("Summit Reached");
        System.out.println("Staircase Complete");
}`,
        solutionCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("Summit Reached");
        System.out.println("Staircase Complete");
    }
}`,
        hints: [
          'main(String[] args) needs BOTH an opening { and its own closing } before class Main’s closing }.',
        ],
        validation: {
          expectedOutputLines: ['Summit Reached', 'Staircase Complete'],
        },
        xpBonus: 20,
        coinBonus: 10,
      },
    ],
    completionCelebration:
      'Magnificent! You can now climb the Grand Cliffside Staircase right up to the Highland Plateau! Head west along the upper ridge to The Signal Lantern Grove!',
  },

  // =========================================================================
  // LEVEL 6 — PRINT VS PRINTLN (The Signal Lantern Grove)
  // =========================================================================
  {
    levelNumber: 6,
    siteId: 'lantern_grove',
    siteName: 'The Signal Lantern Grove',
    structureTitle: 'Enchanted Signal Lantern Tower',
    structureType: 'signal_lantern_grove',
    javaTopic: 'System.out.print() vs System.out.println()',
    zoneSubtitle: 'Western Highland Grove',
    sitePosition: [-28, 3.6, -24],
    spawnPosition: [-20.5, 3.6, -20.0],
    sproutPosition: [-23.4, 3.6, -20.2],
    terminalPosition: [-31.8, 3.6, -22.2],
    cameraLandmarkOffset: [-18, 12.5, -13],
    briefingHeadline: 'Illuminate the Signal Lantern Grove',
    sproutDialogue: [
      'Up here in the Highland Grove, rangers used enchanted signal lanterns to send coded light patterns across the canopy.',
      'Java gives you exact control over line breaks: System.out.print() keeps the cursor on the SAME line, while System.out.println() prints and jumps to the NEXT line!',
      'Visit all four signal pedestals across the grove to ignite the lanterns and raise the Central Signal Tower!',
    ],
    conceptHeadline: 'Same Line vs New Line: print() and println()',
    conceptExplanation: [
      'System.out.print("A"); prints A and leaves the cursor right beside A on the same line.',
      'System.out.println("B"); prints B on the current line and then moves the cursor down to the start of the next line.',
      'Combining print() and println() lets you build horizontal rows, grids, and multi-line status boards.',
    ],
    workingExampleCode: `public class Main {
    public static void main(String[] args) {
        System.out.print("CODE");
        System.out.println("LAND");
        System.out.println("ONLINE");
    }
}`,
    workingExampleNotes: [
      {
        line: 'System.out.print("CODE");',
        explanation: 'Outputs CODE without starting a new line.',
      },
      {
        line: 'System.out.println("LAND");',
        explanation: 'Appends LAND onto the same line -> CODELAND, then moves to line 2.',
      },
      {
        line: 'System.out.println("ONLINE");',
        explanation: 'Prints ONLINE on line 2.',
      },
    ],
    tasks: [
      {
        id: 'w1_l6_t1',
        taskNumber: 1,
        title: 'Stage 1: Ignite the First Inline Lantern',
        sproutInstruction:
          'Use two separate print calls so "STAR" and "LIGHT" appear side-by-side on one single line as "STARLIGHT"!',
        sproutDialogueBubble:
          'Walk west across the grove to the West Inline Lantern Post! Combine System.out.print("STAR"); with "LIGHT" on the same line to ignite the western crystal lantern!',
        stationPosition: [-31.8, 3.6, -22.2],
        stationLabel: 'West Inline Lantern Post',
        stationKind: 'lantern_pedestal',
        sproutWaypoint: [-30.0, 3.6, -20.2],
        objective: 'Use System.out.print() to combine "STAR" and "LIGHT" into "STARLIGHT" using 2 print calls',
        constructionStageLabel: 'Stage 1/4 · Western Crystal Lantern Post',
        starterCode: `public class Main {
    public static void main(String[] args) {
        // Use System.out.print for the first word so both join on one line:
        System.out.print("STAR");
        // Add the second print statement for "LIGHT":
        
    }
}`,
        solutionCode: `public class Main {
    public static void main(String[] args) {
        System.out.print("STAR");
        System.out.println("LIGHT");
    }
}`,
        hints: [
          'Add System.out.print("LIGHT"); or System.out.println("LIGHT"); on the next line.',
          'Together with System.out.print("STAR"); it outputs STARLIGHT on line 1!',
        ],
        validation: {
          expectedOutputLines: ['STARLIGHT'],
          requireExactPrintCount: 2,
          requiredPatterns: [
            {
              regex: /System\.out\.print\s*\(\s*"STAR"\s*\)/,
              message: 'Keep System.out.print("STAR") as the first call.',
            },
          ],
        },
        xpBonus: 15,
        coinBonus: 5,
      },
      {
        id: 'w1_l6_t2',
        taskNumber: 2,
        title: 'Stage 2: Stack the Vertical Beacon Signal',
        sproutInstruction:
          'Right now "NORTH" and "RIDGE" are squished onto one line! Switch to println() so "NORTH" appears on line 1 and "RIDGE" appears on line 2.',
        sproutDialogueBubble:
          'Now head east across the clearing to the East Vertical Lantern Post! Switch print() to println() so "NORTH" and "RIDGE" shine on separate lines!',
        stationPosition: [-24.2, 3.6, -22.2],
        stationLabel: 'East Vertical Lantern Post',
        stationKind: 'lantern_pedestal',
        sproutWaypoint: [-22.6, 3.6, -20.2],
        objective: 'Print "NORTH" on line 1 and "RIDGE" on line 2',
        constructionStageLabel: 'Stage 2/4 · Eastern Crystal Lantern Post',
        starterCode: `public class Main {
    public static void main(String[] args) {
        // Fix this so NORTH and RIDGE print on separate lines:
        System.out.print("NORTH");
        System.out.print("RIDGE");
    }
}`,
        solutionCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("NORTH");
        System.out.println("RIDGE");
    }
}`,
        hints: ['Change System.out.print("NORTH"); to System.out.println("NORTH");'],
        validation: {
          expectedOutputLines: ['NORTH', 'RIDGE'],
        },
        xpBonus: 15,
        coinBonus: 5,
      },
      {
        id: 'w1_l6_t3',
        taskNumber: 3,
        title: 'Stage 3: Wire the 2x2 Signal Matrix Board',
        sproutInstruction:
          'Combine print() and println() using 4 calls to build a 2-row lantern matrix: "[ON][ON]" on line 1 and "[OK][OK]" on line 2!',
        sproutDialogueBubble:
          'Walk to the South Signal Matrix Console! Pair print("[OK]") and println("[OK]") to complete the 2x2 illuminated signal grid!',
        stationPosition: [-28.0, 3.6, -20.4],
        stationLabel: 'South Signal Matrix Console',
        stationKind: 'pedestal',
        sproutWaypoint: [-25.8, 3.6, -19.8],
        objective: 'Use 4 print/println calls to output "[ON][ON]" on line 1 and "[OK][OK]" on line 2',
        constructionStageLabel: 'Stage 3/4 · Illuminated Signal Matrix Board',
        starterCode: `public class Main {
    public static void main(String[] args) {
        System.out.print("[ON]");
        System.out.println("[ON]");
        // Now use print + println to output [OK][OK] on line 2:
        
    }
}`,
        solutionCode: `public class Main {
    public static void main(String[] args) {
        System.out.print("[ON]");
        System.out.println("[ON]");
        System.out.print("[OK]");
        System.out.println("[OK]");
    }
}`,
        hints: [
          'Write System.out.print("[OK]"); followed by System.out.println("[OK]");',
        ],
        validation: {
          expectedOutputLines: ['[ON][ON]', '[OK][OK]'],
          requireExactPrintCount: 4,
        },
        xpBonus: 15,
        coinBonus: 5,
      },
      {
        id: 'w1_l6_t4',
        taskNumber: 4,
        title: 'Stage 4: Activate the Central Signal Tower',
        sproutInstruction:
          'Raise the tall Signal Communication Tower! Use print() for the label and println() for the value to output "SIGNAL: CLEAR" on line 1 and "TOWER: ACTIVE" on line 2.',
        sproutDialogueBubble:
          'Circle behind the grove to the North Tower Relay Pedestal! Use print("TOWER: ") and println("ACTIVE") to raise and light the Central Signal Tower!',
        stationPosition: [-28.0, 3.6, -28.0],
        stationLabel: 'North Tower Relay Pedestal',
        stationKind: 'lantern_pedestal',
        sproutWaypoint: [-25.6, 3.6, -27.8],
        objective: 'Output "SIGNAL: CLEAR" on line 1 and "TOWER: ACTIVE" on line 2 using print() + println()',
        constructionStageLabel: 'Stage 4/4 · Central Signal Communication Tower',
        starterCode: `public class Main {
    public static void main(String[] args) {
        System.out.print("SIGNAL: ");
        System.out.println("CLEAR");
        // Now print "TOWER: " with print() and "ACTIVE" with println():
        
    }
}`,
        solutionCode: `public class Main {
    public static void main(String[] args) {
        System.out.print("SIGNAL: ");
        System.out.println("CLEAR");
        System.out.print("TOWER: ");
        System.out.println("ACTIVE");
    }
}`,
        hints: [
          'Add System.out.print("TOWER: "); (note the space after the colon) and System.out.println("ACTIVE");',
        ],
        validation: {
          expectedOutputLines: ['SIGNAL: CLEAR', 'TOWER: ACTIVE'],
          requiredPatterns: [
            {
              regex: /System\.out\.print\s*\(\s*"TOWER: "\s*\)/,
              message: 'Use System.out.print("TOWER: "); for the label on line 2.',
            },
          ],
        },
        xpBonus: 20,
        coinBonus: 10,
      },
    ],
    completionCelebration:
      'Golden lantern beams now dance across the highland canopy! Follow the cliffside ridge northeast to The Ranger’s Map Station!',
  },

  // =========================================================================
  // LEVEL 7 — COMMENTS AND CODE READABILITY (The Ranger's Map Station)
  // =========================================================================
  {
    levelNumber: 7,
    siteId: 'map_station',
    siteName: "The Ranger's Map Station",
    structureTitle: "Ranger's Overlook Map Station",
    structureType: 'rangers_map_station',
    javaTopic: 'Comments (// and /* */) & Readability',
    zoneSubtitle: 'Northern Cliff Overlook',
    sitePosition: [-12, 3.6, -34],
    spawnPosition: [-15.5, 3.6, -27.5],
    sproutPosition: [-11.8, 3.6, -28.2],
    terminalPosition: [-12.0, 3.6, -29.8],
    cameraLandmarkOffset: [-3, 12.5, -23],
    briefingHeadline: "Restore the Ranger's Overlook Map Station",
    sproutDialogue: [
      'From this cliff overlook you can see the entire Beginner’s Forest! Rangers once left annotated Java trail guides here so future builders could understand every route.',
      'Java comments let you write human notes right inside your code: // for single-line comments and /* ... */ for multi-line notes. The compiler completely ignores comments!',
      'Explore all four surveyor desks around the overlook to annotate the ranger scripts and construct the Map Station!',
    ],
    conceptHeadline: 'Documenting Code with // and /* ... */',
    conceptExplanation: [
      'Single-Line Comment (//): Everything after // to the end of that line is ignored by Java.',
      'Multi-Line Comment (/* ... */): Everything between /* and */ across one or many lines is ignored by Java.',
      'Builders use comments to explain WHY code exists and to temporarily disable broken or unwanted lines during testing.',
    ],
    workingExampleCode: `/*
 * Forest Trail Map Script
 * Author: Ranger Sprout
 */
public class Main {
    public static void main(String[] args) {
        // Print the active northern landmark
        System.out.println("Overlook Map Ready");
    }
}`,
    workingExampleNotes: [
      {
        line: '/* ... */',
        explanation: 'Multi-line header comment describing the file.',
      },
      {
        line: '// Print the active northern landmark',
        explanation: 'Single-line comment explaining the next instruction.',
      },
    ],
    tasks: [
      {
        id: 'w1_l7_t1',
        taskNumber: 1,
        title: 'Stage 1: Document the Timber Platform',
        sproutInstruction:
          'Add a descriptive single-line // comment above the instruction, then print "Platform Levelled" to lay the overlook timber deck!',
        sproutDialogueBubble:
          'Walk to the South Surveyor Stake! Keep a // single-line comment and print "Platform Levelled" to lay the overlook timber deck!',
        stationPosition: [-12.0, 3.6, -29.8],
        stationLabel: 'South Surveyor Stake',
        stationKind: 'map_desk',
        sproutWaypoint: [-9.8, 3.6, -29.6],
        objective: 'Write a // comment and print "Platform Levelled"',
        constructionStageLabel: 'Stage 1/4 · Overlook Timber Platform',
        starterCode: `public class Main {
    public static void main(String[] args) {
        // Write a // comment and print "Platform Levelled":
        System.out.println("");
    }
}`,
        solutionCode: `public class Main {
    public static void main(String[] args) {
        // Lay the timber deck at the cliff overlook
        System.out.println("Platform Levelled");
    }
}`,
        hints: [
          'Keep a // comment line and put Platform Levelled inside System.out.println("Platform Levelled");',
        ],
        validation: {
          expectedOutputLines: ['Platform Levelled'],
          requiredRawPatterns: [
            {
              regex: /\/\/\s*\w+/,
              message: 'Include a single-line comment using //.',
            },
          ],
        },
        xpBonus: 15,
        coinBonus: 5,
      },
      {
        id: 'w1_l7_t2',
        taskNumber: 2,
        title: 'Stage 2: Disable the Corrupted Map Line',
        sproutInstruction:
          'A stray test instruction is printing "ERROR: LOST IN FOG"! Comment out that unwanted line using // (do not delete it!) so ONLY "Log Walls Framed" prints.',
        sproutDialogueBubble:
          'Head to the West Cabin Drafting Desk! Comment out the rogue ERROR line using // (without deleting it) so only "Log Walls Framed" prints and raises the cabin walls!',
        stationPosition: [-15.8, 3.6, -34.0],
        stationLabel: 'West Cabin Drafting Desk',
        stationKind: 'map_desk',
        sproutWaypoint: [-16.0, 3.6, -31.6],
        objective: 'Comment out the rogue line with // so only "Log Walls Framed" is printed',
        constructionStageLabel: 'Stage 2/4 · Pine Log Cabin Walls',
        starterCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("ERROR: LOST IN FOG");
        System.out.println("Log Walls Framed");
    }
}`,
        solutionCode: `public class Main {
    public static void main(String[] args) {
        // System.out.println("ERROR: LOST IN FOG");
        System.out.println("Log Walls Framed");
    }
}`,
        hints: [
          'Place // at the start of System.out.println("ERROR: LOST IN FOG"); rather than deleting the line.',
        ],
        validation: {
          expectedOutputLines: ['Log Walls Framed'],
          requiredRawPatterns: [
            {
              regex: /\/\/\s*System\.out\.println\s*\(\s*"ERROR: LOST IN FOG"\s*\)/,
              message: 'Comment out the ERROR: LOST IN FOG line with // instead of deleting it.',
            },
          ],
        },
        xpBonus: 15,
        coinBonus: 5,
      },
      {
        id: 'w1_l7_t3',
        taskNumber: 3,
        title: 'Stage 3: Add a Multi-Line Ranger Header',
        sproutInstruction:
          'Write a multi-line /* ... */ header comment at the top of the program documenting the station, and print "Notice Boards Mounted"!',
        sproutDialogueBubble:
          'Walk across to the East Trail Notice Stand! Add a /* ... */ block comment above class Main and print "Notice Boards Mounted" to erect the trail boards!',
        stationPosition: [-8.2, 3.6, -34.0],
        stationLabel: 'East Trail Notice Stand',
        stationKind: 'map_desk',
        sproutWaypoint: [-8.0, 3.6, -31.6],
        objective: 'Include a /* ... */ multi-line comment and print "Notice Boards Mounted"',
        constructionStageLabel: 'Stage 3/4 · Carved Trail Notice Boards',
        starterCode: `// Write a multi-line block comment above public class Main:

public class Main {
    public static void main(String[] args) {
        System.out.println("");
    }
}`,
        solutionCode: `/*
 * Station: Ranger Overlook Map Post
 * Region: Beginner's Forest North Ridge
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("Notice Boards Mounted");
    }
}`,
        hints: [
          'Write /* Ranger Map Station */ (across one or multiple lines) above public class Main.',
        ],
        validation: {
          expectedOutputLines: ['Notice Boards Mounted'],
          requiredRawPatterns: [
            {
              regex: /\/\*[\s\S]+?\*\//,
              message: 'Include a multi-line comment wrapped in /* and */.',
            },
          ],
        },
        xpBonus: 15,
        coinBonus: 5,
      },
      {
        id: 'w1_l7_t4',
        taskNumber: 4,
        title: 'Stage 4: Complete the 3D Miniature Map Table',
        sproutInstruction:
          'Combine a /* ... */ block comment AND a // line comment while printing the two cardinal trail markers: "West: Lantern Grove" and "East: Repair District"!',
        sproutDialogueBubble:
          'Step north to the Cliff Overlook Map Table! Keep both /* */ and // comments while printing "West: Lantern Grove" and "East: Repair District" to reveal the 3D miniature forest map!',
        stationPosition: [-12.0, 3.6, -37.8],
        stationLabel: 'Cliff Overlook Map Table',
        stationKind: 'map_desk',
        sproutWaypoint: [-9.8, 3.6, -37.6],
        objective:
          'Include both /* */ and // comments and print "West: Lantern Grove" then "East: Repair District"',
        constructionStageLabel: 'Stage 4/4 · Shingled Roof & 3D Miniature Forest Map',
        starterCode: `/*
 * Complete the Ranger Trail Legend
 */
public class Main {
    public static void main(String[] args) {
        // Add your trail legend output statements below:
        System.out.println("West: Lantern Grove");
        
    }
}`,
        solutionCode: `/*
 * Complete the Ranger Trail Legend
 */
public class Main {
    public static void main(String[] args) {
        // Print western and eastern landmarks
        System.out.println("West: Lantern Grove");
        System.out.println("East: Repair District");
    }
}`,
        hints: [
          'Keep both the /* ... */ header and the // comment, and add System.out.println("East: Repair District");',
        ],
        validation: {
          expectedOutputLines: ['West: Lantern Grove', 'East: Repair District'],
          requiredRawPatterns: [
            {
              regex: /\/\*[\s\S]+?\*\//,
              message: 'Keep the /* ... */ multi-line header comment.',
            },
            {
              regex: /\/\/\s*\S+/,
              message: 'Keep a // single-line comment explaining the code.',
            },
          ],
        },
        xpBonus: 20,
        coinBonus: 10,
      },
    ],
    completionCelebration:
      'The Ranger’s Map Station is complete, complete with a 3D miniature map of the forest! Follow the descending northeastern path to The Forest Repair District!',
  },

  // =========================================================================
  // LEVEL 8 — ERRORS AND DEBUGGING (The Forest Repair District)
  // =========================================================================
  {
    levelNumber: 8,
    siteId: 'repair_district',
    siteName: 'The Forest Repair District',
    structureTitle: 'Artisan Watermill & Forge District',
    structureType: 'repair_district',
    javaTopic: 'Syntax, Compilation & Runtime Errors',
    zoneSubtitle: 'Northeast Artisan Valley',
    sitePosition: [12, 0, -30],
    spawnPosition: [8.8, 0, -23.0],
    sproutPosition: [10.4, 0, -24.8],
    terminalPosition: [12.0, 0, -25.6],
    cameraLandmarkOffset: [21, 9.5, -19],
    briefingHeadline: 'Debug & Restore the Artisan Repair District',
    sproutDialogue: [
      'Every builder encounters bugs! Here in the Forest Repair District, the watermill and timber forge keep stalling because their control scripts have three kinds of errors.',
      'Syntax & Compilation errors stop javac from compiling (like missing quotes or misspelled methods). Runtime errors crash while the program is running (like dividing a number by zero!).',
      'Inspect all four broken machine consoles around the mill and forge to debug every error!',
    ],
    conceptHeadline: 'Three Bug Families: Syntax, Compilation & Runtime',
    conceptExplanation: [
      'Syntax Error: Breaking Java grammar rules—missing ;, unclosed "quote, or missing }.',
      'Compilation Error: Misspelling identifiers or types—like writing system.out.printline(...) instead of System.out.println(...).',
      'Runtime Error (Exception): Valid grammar that fails during execution—such as 100 / 0 throwing ArithmeticException: / by zero.',
    ],
    workingExampleCode: `public class Main {
    public static void main(String[] args) {
        // Safe division: 100 / 4 evaluates to 25
        System.out.println("Mill Speed: " + (100 / 4));
    }
}`,
    workingExampleNotes: [
      {
        line: 'System.out.println("Mill Speed: " + (100 / 4));',
        explanation: 'Evaluates 100 / 4 = 25 and joins it onto "Mill Speed: " -> Mill Speed: 25.',
      },
    ],
    tasks: [
      {
        id: 'w1_l8_t1',
        taskNumber: 1,
        title: 'Stage 1: Fix the Syntax Error',
        sproutInstruction:
          'This foundation script has an unclosed string quote and a missing semicolon! Repair the syntax so it prints "Mill Foundation Repaired".',
        sproutDialogueBubble:
          'Walk to the South Mill Foundation Console! Close the missing quote " and semicolon ; so the stone mill base is repaired!',
        stationPosition: [12.0, 0, -25.6],
        stationLabel: 'South Mill Foundation Console',
        stationKind: 'anvil_bench',
        sproutWaypoint: [9.8, 0, -25.4],
        objective: 'Fix the unclosed string literal and missing semicolon',
        constructionStageLabel: 'Stage 1/4 · Repaired Stone Mill Foundation',
        starterCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("Mill Foundation Repaired)
    }
}`,
        solutionCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("Mill Foundation Repaired");
    }
}`,
        hints: [
          'Add the closing double quote " after Repaired and a semicolon ; after ).',
        ],
        validation: {
          expectedOutputLines: ['Mill Foundation Repaired'],
        },
        xpBonus: 15,
        coinBonus: 5,
      },
      {
        id: 'w1_l8_t2',
        taskNumber: 2,
        title: 'Stage 2: Fix the Compilation Error',
        sproutInstruction:
          'The compiler rejected two misspelled identifiers here: `system` and `printline`! Fix both so it prints "Timber Walls Restored".',
        sproutDialogueBubble:
          'Head east to the Timber Carpentry Bench! Fix system.out.printline to System.out.println so the half-timber walls rise!',
        stationPosition: [16.0, 0, -29.8],
        stationLabel: 'Timber Carpentry Bench',
        stationKind: 'anvil_bench',
        sproutWaypoint: [16.2, 0, -27.4],
        objective: 'Correct system.out.printline(...) to System.out.println(...)',
        constructionStageLabel: 'Stage 2/4 · Half-Timber Artisan Walls',
        starterCode: `public class Main {
    public static void main(String[] args) {
        system.out.printline("Timber Walls Restored");
    }
}`,
        solutionCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("Timber Walls Restored");
    }
}`,
        hints: [
          'Capitalize System and change printline to println.',
        ],
        validation: {
          expectedOutputLines: ['Timber Walls Restored'],
        },
        xpBonus: 15,
        coinBonus: 5,
      },
      {
        id: 'w1_l8_t3',
        taskNumber: 3,
        title: 'Stage 3: Prevent a Runtime Crash (/ by zero)',
        sproutInstruction:
          'This script compiles, then crashes at runtime with ArithmeticException: / by zero! Change the divisor from 0 to 4 so the waterwheel spins at 30 RPM ("Waterwheel RPM: 30").',
        sproutDialogueBubble:
          'Walk over beside the Millstream to the Waterwheel Gear Lever! Replace / 0 with / 4 so the waterwheel spins smoothly at 30 RPM without crashing!',
        stationPosition: [9.0, 0, -30.2],
        stationLabel: 'Waterwheel Gear Lever',
        stationKind: 'riverbank_post',
        sproutWaypoint: [9.2, 0, -27.8],
        objective: 'Fix the / 0 division-by-zero bug to divide 120 by 4 ("Waterwheel RPM: 30")',
        constructionStageLabel: 'Stage 3/4 · Spinning Mill Waterwheel & Forge',
        starterCode: `public class Main {
    public static void main(String[] args) {
        // Dividing 120 by 0 crashes at runtime! Divide 120 by 4 instead:
        System.out.println("Waterwheel RPM: " + (120 / 0));
    }
}`,
        solutionCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("Waterwheel RPM: " + (120 / 4));
    }
}`,
        hints: [
          'Replace (120 / 0) with (120 / 4) so 120 / 4 evaluates to 30.',
        ],
        validation: {
          expectedOutputLines: ['Waterwheel RPM: 30'],
          forbiddenPatterns: [
            {
              regex: /\/\s*0\b/,
              message: 'Remove division by 0 so ArithmeticException cannot occur.',
            },
          ],
        },
        xpBonus: 15,
        coinBonus: 5,
      },
      {
        id: 'w1_l8_t4',
        taskNumber: 4,
        title: 'Stage 4: Multi-Bug District Diagnostics',
        sproutInstruction:
          'Final inspection! Fix all 3 bugs in this script (a missing opening brace {, a typo `Pintln`, and a `/ 0` divisor that should be `/ 2` for 50 kW) so it prints "District Status: OK" and "Forge Output: 50".',
        sproutDialogueBubble:
          'Step north to the Blacksmith Forge Anvil! Fix all three bugs—missing {, Pintln typo, and / 0—to ignite the glowing artisan forge!',
        stationPosition: [12.4, 0, -34.2],
        stationLabel: 'Blacksmith Forge Anvil',
        stationKind: 'anvil_bench',
        sproutWaypoint: [14.6, 0, -34.0],
        objective: 'Fix all 3 bugs to output "District Status: OK" and "Forge Output: 50"',
        constructionStageLabel: 'Stage 4/4 · Restored Artisan Hall & Glowing Hearth',
        starterCode: `public class Main {
    public static void main(String[] args)
        System.out.Pintln("District Status: OK");
        System.out.println("Forge Output: " + (100 / 0));
    }
}`,
        solutionCode: `public class Main {
    public static void main(String[] args) {
        System.out.println("District Status: OK");
        System.out.println("Forge Output: " + (100 / 2));
    }
}`,
        hints: [
          '1. Add { after main(String[] args)',
          '2. Change Pintln to println',
          '3. Change (100 / 0) to (100 / 2) so Forge Output is 50.',
        ],
        validation: {
          expectedOutputLines: ['District Status: OK', 'Forge Output: 50'],
        },
        xpBonus: 20,
        coinBonus: 10,
      },
    ],
    completionCelebration:
      'The waterwheel turns smoothly and warm forge light spills across the lane! Continue southeast to The Village Registration Centre to meet Elder Rowan!',
  },

  // =========================================================================
  // LEVEL 9 — USER INPUT WITH SCANNER (The Village Registration Centre)
  // =========================================================================
  {
    levelNumber: 9,
    siteId: 'registration_centre',
    siteName: 'The Village Registration Centre',
    structureTitle: 'Civic Registration Hall',
    structureType: 'registration_centre',
    javaTopic: 'Interactive Input with java.util.Scanner',
    zoneSubtitle: 'Eastern Village Civic Lot',
    sitePosition: [30, 0, -24],
    spawnPosition: [23.5, 0, -19.0],
    sproutPosition: [25.6, 0, -19.8],
    terminalPosition: [28.4, 0, -19.8],
    cameraLandmarkOffset: [20, 9.5, -13],
    briefingHeadline: 'Build the Civic Registration Hall with Scanner',
    sproutDialogue: [
      'Villagers are returning to the forest! Elder Rowan needs a Civic Registration Hall that can read each explorer’s name and crystal count interactively.',
      'In Java, we import java.util.Scanner; and create Scanner sc = new Scanner(System.in); to read text with sc.nextLine() and whole numbers with sc.nextInt()!',
      'Visit all four civic booths around the Registration Hall—and engrave your own name on Elder Rowan’s 3D Registry!',
    ],
    conceptHeadline: 'Reading User Input with Scanner',
    conceptExplanation: [
      '1. Import at the very top (above class Main): import java.util.Scanner;',
      '2. Create the Scanner inside main: Scanner sc = new Scanner(System.in);',
      '3. Read values: String name = sc.nextLine(); reads a full line of text, and int count = sc.nextInt(); reads an integer.',
    ],
    workingExampleCode: `import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String explorer = sc.nextLine();
        System.out.println("Hello, " + explorer + "!");
    }
}`,
    workingExampleNotes: [
      {
        line: 'import java.util.Scanner;',
        explanation: 'Brings Java’s built-in Scanner tool into your file.',
      },
      {
        line: 'Scanner sc = new Scanner(System.in);',
        explanation: 'Connects Scanner sc to standard keyboard/console input (System.in).',
      },
      {
        line: 'String explorer = sc.nextLine();',
        explanation: 'Reads a line of text typed by the user.',
      },
    ],
    tasks: [
      {
        id: 'w1_l9_t1',
        taskNumber: 1,
        title: 'Stage 1: Set Up the Scanner Desk',
        sproutInstruction:
          'Import java.util.Scanner, create `Scanner sc = new Scanner(System.in);` inside main, and print "Registry Desk Ready" to build the oak counter!',
        sproutDialogueBubble:
          'Walk to the Front Registry Reception Desk! Import java.util.Scanner and create new Scanner(System.in) to build the carved oak counter!',
        stationPosition: [28.4, 0, -19.8],
        stationLabel: 'Front Registry Reception Desk',
        stationKind: 'registry_booth',
        sproutWaypoint: [26.2, 0, -19.8],
        objective: 'Import Scanner, instantiate new Scanner(System.in), and print "Registry Desk Ready"',
        constructionStageLabel: 'Stage 1/4 · Carved Oak Registration Counter',
        starterCode: `// 1. Import java.util.Scanner here:


public class Main {
    public static void main(String[] args) {
        // 2. Create Scanner sc = new Scanner(System.in);
        
        System.out.println("Registry Desk Ready");
    }
}`,
        solutionCode: `import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Registry Desk Ready");
    }
}`,
        hints: [
          'Put import java.util.Scanner; above public class Main.',
          'Put Scanner sc = new Scanner(System.in); inside main.',
        ],
        validation: {
          expectedOutputLines: ['Registry Desk Ready'],
          requiredPatterns: [
            {
              regex: /import\s+java\.util\.Scanner\s*;/,
              message: 'Include import java.util.Scanner; at the top.',
            },
            {
              regex: /new\s+Scanner\s*\(\s*System\.in\s*\)/,
              message: 'Create a Scanner connected to System.in.',
            },
          ],
        },
        xpBonus: 15,
        coinBonus: 5,
      },
      {
        id: 'w1_l9_t2',
        taskNumber: 2,
        title: 'Stage 2: Read the Explorer Name',
        sproutInstruction:
          'Use `String name = sc.nextLine();` to read the arriving explorer’s name and print `"Welcome, " + name`!',
        sproutDialogueBubble:
          'Head to the West Villager Greeting Booth! Read String name = sc.nextLine(); and print "Welcome, " + name to frame the information booth!',
        stationPosition: [26.0, 0, -23.8],
        stationLabel: 'West Villager Greeting Booth',
        stationKind: 'registry_booth',
        sproutWaypoint: [25.8, 0, -21.4],
        objective: 'Read a String with sc.nextLine() and print "Welcome, " + name',
        constructionStageLabel: 'Stage 2/4 · Timber Information Booth',
        starterCode: `import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // Read name using sc.nextLine() and print "Welcome, " + name
        
    }
}`,
        solutionCode: `import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String name = sc.nextLine();
        System.out.println("Welcome, " + name);
    }
}`,
        hints: [
          'Write String name = sc.nextLine();',
          'Then write System.out.println("Welcome, " + name); (with a comma and space after Welcome).',
        ],
        validation: {
          simulatedStdin: ['Aria'],
          expectedOutputLines: ['Welcome, Aria'],
          requiredPatterns: [
            {
              regex: /\.nextLine\s*\(\s*\)/,
              message: 'Use sc.nextLine() to read the explorer name.',
            },
          ],
        },
        xpBonus: 15,
        coinBonus: 5,
      },
      {
        id: 'w1_l9_t3',
        taskNumber: 3,
        title: 'Stage 3: Count Stored Forest Crystals',
        sproutInstruction:
          'Now read a whole number of crystals using `int crystals = sc.nextInt();` and print `"Crystals Logged: " + crystals` to raise the wooden hall!',
        sproutDialogueBubble:
          'Walk across to the East Crystal Ledger Scale! Use int crystals = sc.nextInt(); and print "Crystals Logged: " + crystals to raise the civic hall!',
        stationPosition: [34.0, 0, -23.8],
        stationLabel: 'East Crystal Ledger Scale',
        stationKind: 'registry_booth',
        sproutWaypoint: [34.2, 0, -21.4],
        objective: 'Read an integer with sc.nextInt() and print "Crystals Logged: " + crystals',
        constructionStageLabel: 'Stage 3/4 · Wooden Civic Registration Hall',
        starterCode: `import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // Read an int using sc.nextInt() and print "Crystals Logged: " + crystals
        
    }
}`,
        solutionCode: `import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int crystals = sc.nextInt();
        System.out.println("Crystals Logged: " + crystals);
    }
}`,
        hints: [
          'Write int crystals = sc.nextInt();',
          'Then write System.out.println("Crystals Logged: " + crystals);',
        ],
        validation: {
          simulatedStdin: ['24'],
          expectedOutputLines: ['Crystals Logged: 24'],
          requiredPatterns: [
            {
              regex: /\.nextInt\s*\(\s*\)/,
              message: 'Use sc.nextInt() to read the integer crystal count.',
            },
          ],
        },
        xpBonus: 15,
        coinBonus: 5,
      },
      {
        id: 'w1_l9_t4',
        taskNumber: 4,
        title: 'Stage 4: Issue the Official Villager Pass',
        sproutInstruction:
          'Combine both! Read `String name = sc.nextLine();` and `int crystals = sc.nextInt();`, then print `"Builder: " + name` on line 1 and `"Crystals: " + crystals` on line 2. Customize the test inputs below to engrave YOUR name on Elder Rowan’s 3D Registry!',
        sproutDialogueBubble:
          'Meet Elder Rowan at the Official Registry Seal Lectern! Read both name and crystals with Scanner to engrave your Villager Pass in the 3D world!',
        stationPosition: [31.6, 0, -19.8],
        stationLabel: 'Elder Rowan Registry Lectern',
        stationKind: 'registry_booth',
        sproutWaypoint: [33.6, 0, -19.8],
        objective:
          'Read name (nextLine) and crystals (nextInt) and print "Builder: " + name and "Crystals: " + crystals',
        constructionStageLabel: 'Stage 4/4 · Decorated Hall & Elder Rowan Live Registry',
        allowsCustomScannerInput: true,
        starterCode: `import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String name = sc.nextLine();
        // Read int crystals = sc.nextInt(); and print both summary lines:
        
    }
}`,
        solutionCode: `import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String name = sc.nextLine();
        int crystals = sc.nextInt();
        System.out.println("Builder: " + name);
        System.out.println("Crystals: " + crystals);
    }
}`,
        hints: [
          'Add int crystals = sc.nextInt();',
          'Print System.out.println("Builder: " + name); and System.out.println("Crystals: " + crystals);',
        ],
        validation: {
          simulatedStdin: ['Explorer', '35'],
          expectedOutputLines: ['Builder: Explorer', 'Crystals: 35'],
          requiredPatterns: [
            {
              regex: /\.nextLine\s*\(\s*\)/,
              message: 'Use nextLine() to read the builder name.',
            },
            {
              regex: /\.nextInt\s*\(\s*\)/,
              message: 'Use nextInt() to read the crystal count.',
            },
          ],
        },
        xpBonus: 20,
        coinBonus: 10,
      },
    ],
    completionCelebration:
      'Elder Rowan waves proudly beside your engraved Villager Registry! Walk south into the heart of the valley for Level 10: The Grand Forest Settlement!',
  },

  // =========================================================================
  // LEVEL 10 — GRAND FOREST RESTORATION (Capstone Boss Level)
  // =========================================================================
  {
    levelNumber: 10,
    siteId: 'grand_settlement',
    siteName: 'The Grand Forest Settlement',
    structureTitle: 'Central Village Square & Monument',
    structureType: 'grand_settlement',
    javaTopic: 'World 1 Mastery: Structure, Output, Comments, Debugging & Scanner',
    zoneSubtitle: 'Heart of the Beginner’s Forest',
    sitePosition: [28, 0, -9],
    spawnPosition: [20.0, 0, -9.0],
    sproutPosition: [21.8, 0, -7.2],
    terminalPosition: [23.4, 0, -9.0],
    cameraLandmarkOffset: [14.5, 11.5, 2.5],
    briefingHeadline: 'Capstone Finale: Restore the Grand Forest Settlement',
    sproutDialogue: [
      'Look around you, Explorer—from the shining Beacon in the southwest to the Compiler Workshop, Gatehouse, Bridge, Cliffside Staircase, Lantern Tower, Map Station, Watermill, and Registration Hall!',
      'Only the central heart of the village remains unfinished: The Grand Forest Settlement Square.',
      'Walk with me to all four cardinal monuments around the Village Square to combine everything you learned in World 1 and awaken the entire forest!',
    ],
    conceptHeadline: 'World 1 Java Builder Toolkit Summary',
    conceptExplanation: [
      'Program Structure & Comments: Document code with // or /* */, and house instructions inside public class Main and public static void main(String[] args).',
      'Precision Output: Control single-line vs multi-line output using System.out.print() and System.out.println(), ending every statement with ;.',
      'Debugging & Interactive Scanner: Eliminate syntax/compile/runtime bugs and read dynamic user input via Scanner(System.in).',
    ],
    workingExampleCode: `import java.util.Scanner;

// World 1 Restoration Verification
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String town = sc.nextLine();
        System.out.print("Settlement: ");
        System.out.println(town);
    }
}`,
    workingExampleNotes: [
      {
        line: '// World 1 Restoration Verification',
        explanation: 'Clear comment documenting the capstone script.',
      },
      {
        line: 'System.out.print("Settlement: ");',
        explanation: 'Combines inline label with println(town) on the same line.',
      },
    ],
    tasks: [
      {
        id: 'w1_l10_t1',
        taskNumber: 1,
        title: 'Stage 1: Pave the Village Cobblestone Square',
        sproutInstruction:
          'Write a complete, commented Java program (`//` comment + `public class Main` + `main`) that prints `"Village Square Paved"` to lay the central cobblestone plaza!',
        sproutDialogueBubble:
          'Step up to the West Plaza Cornerstone Altar! Write a commented Java class from scratch printing "Village Square Paved" to pave the grand cobblestone plaza!',
        stationPosition: [23.4, 0, -9.0],
        stationLabel: 'West Plaza Cornerstone Altar',
        stationKind: 'stone_altar',
        sproutWaypoint: [22.8, 0, -6.8],
        objective: 'Write a commented Java class from scratch that prints "Village Square Paved"',
        constructionStageLabel: 'Stage 1/4 · Grand Cobblestone Plaza',
        starterCode: `// Write a complete Java program with a comment that prints: Village Square Paved
`,
        solutionCode: `// Pave the central village plaza
public class Main {
    public static void main(String[] args) {
        System.out.println("Village Square Paved");
    }
}`,
        hints: [
          'Keep the // comment on line 1, then add public class Main { public static void main(String[] args) { System.out.println("Village Square Paved"); } }',
        ],
        validation: {
          expectedOutputLines: ['Village Square Paved'],
          requiredRawPatterns: [
            {
              regex: /\/\/\s*\S+/,
              message: 'Include a // comment in your program.',
            },
          ],
          requiredPatterns: [
            {
              regex: /public\s+class\s+Main/,
              message: 'Declare public class Main.',
            },
          ],
        },
        xpBonus: 20,
        coinBonus: 5,
      },
      {
        id: 'w1_l10_t2',
        taskNumber: 2,
        title: 'Stage 2: Connect the Lantern-Lined Stone Roads',
        sproutInstruction:
          'Use `System.out.print()` and `System.out.println()` together to output `"Roads: Connected"` on line 1 and `"Lanterns: Glowing"` on line 2!',
        sproutDialogueBubble:
          'Walk south to the Roadway Lantern Pedestal! Combine print("Lanterns: ") and println("Glowing") to light every village street lantern!',
        stationPosition: [28.0, 0, -4.4],
        stationLabel: 'South Roadway Lantern Pedestal',
        stationKind: 'lantern_pedestal',
        sproutWaypoint: [25.8, 0, -4.4],
        objective: 'Combine print() and println() to output "Roads: Connected" and "Lanterns: Glowing"',
        constructionStageLabel: 'Stage 2/4 · Stone Roads & Warm Street Lanterns',
        starterCode: `public class Main {
    public static void main(String[] args) {
        System.out.print("Roads: ");
        System.out.println("Connected");
        // Use print() + println() for line 2 -> Lanterns: Glowing
        
    }
}`,
        solutionCode: `public class Main {
    public static void main(String[] args) {
        System.out.print("Roads: ");
        System.out.println("Connected");
        System.out.print("Lanterns: ");
        System.out.println("Glowing");
    }
}`,
        hints: [
          'Add System.out.print("Lanterns: "); followed by System.out.println("Glowing");',
        ],
        validation: {
          expectedOutputLines: ['Roads: Connected', 'Lanterns: Glowing'],
          requiredPatterns: [
            {
              regex: /System\.out\.print\s*\(\s*"Lanterns: "\s*\)/,
              message: 'Use System.out.print("Lanterns: "); for the inline label.',
            },
          ],
        },
        xpBonus: 20,
        coinBonus: 5,
      },
      {
        id: 'w1_l10_t3',
        taskNumber: 3,
        title: 'Stage 3: Debug & Raise the Central Monument',
        sproutInstruction:
          'Fix all 3 bugs in the monument controller (missing `import java.util.Scanner;`, misspelled `system`, and `/ 0` division that should be `/ 1` for 10 landmarks) so it prints `"Landmarks Restored: 10"` and `"Monument: Active"`!',
        sproutDialogueBubble:
          'Head across the plaza to the North Monument Diagnostic Console! Fix the missing Scanner import, system typo, and / 0 bug to raise the Central Monument!',
        stationPosition: [28.0, 0, -13.6],
        stationLabel: 'North Monument Diagnostic Console',
        stationKind: 'execution_core',
        sproutWaypoint: [25.8, 0, -13.6],
        objective:
          'Debug the Scanner & arithmetic script to print "Landmarks Restored: 10" and "Monument: Active"',
        constructionStageLabel: 'Stage 3/4 · Central Forest Builder Monument',
        starterCode: `// Fix the missing Scanner import, lowercase system, and / 0 bug:

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int count = sc.nextInt();
        system.out.println("Landmarks Restored: " + (count / 0));
        System.out.println("Monument: Active");
    }
}`,
        solutionCode: `import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int count = sc.nextInt();
        System.out.println("Landmarks Restored: " + (count / 1));
        System.out.println("Monument: Active");
    }
}`,
        hints: [
          '1. Add import java.util.Scanner; at the top.',
          '2. Capitalize System.out.println on the Landmarks line.',
          '3. Change (count / 0) to (count / 1) or count.',
        ],
        validation: {
          simulatedStdin: ['10'],
          expectedOutputLines: ['Landmarks Restored: 10', 'Monument: Active'],
        },
        xpBonus: 20,
        coinBonus: 10,
      },
      {
        id: 'w1_l10_t4',
        taskNumber: 4,
        title: 'Stage 4: Grand Awakening of the Beginner’s Forest',
        sproutInstruction:
          'The final ceremony! Write a complete Java program with `Scanner` that reads `String builder = sc.nextLine();` and prints `"Forest Restored by " + builder` on line 1 and `"Welcome Home to CODELAND"` on line 2!',
        sproutDialogueBubble:
          'Walk to the East Awakening Bell Shrine! Read your builder name with Scanner and print "Forest Restored by " + builder and "Welcome Home to CODELAND" to awaken the entire settlement!',
        stationPosition: [32.6, 0, -9.0],
        stationLabel: 'East Awakening Bell Shrine',
        stationKind: 'execution_core',
        sproutWaypoint: [32.4, 0, -6.6],
        objective:
          'Read builder name with Scanner and print "Forest Restored by " + builder and "Welcome Home to CODELAND"',
        constructionStageLabel: 'Stage 4/4 · Banners, Festival Lights & Living Settlement',
        allowsCustomScannerInput: true,
        starterCode: `import java.util.Scanner;

// Final World 1 Ceremony
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // 1. Read String builder = sc.nextLine();
        // 2. Print "Forest Restored by " + builder
        // 3. Print "Welcome Home to CODELAND"
        
    }
}`,
        solutionCode: `import java.util.Scanner;

// Final World 1 Ceremony
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String builder = sc.nextLine();
        System.out.println("Forest Restored by " + builder);
        System.out.println("Welcome Home to CODELAND");
    }
}`,
        hints: [
          'Read String builder = sc.nextLine();',
          'Print System.out.println("Forest Restored by " + builder);',
          'Print System.out.println("Welcome Home to CODELAND");',
        ],
        validation: {
          simulatedStdin: ['Explorer'],
          expectedOutputLines: ['Forest Restored by Explorer', 'Welcome Home to CODELAND'],
          requiredPatterns: [
            {
              regex: /\.nextLine\s*\(\s*\)/,
              message: 'Read the builder name dynamically using sc.nextLine().',
            },
          ],
        },
        xpBonus: 30,
        coinBonus: 15,
      },
    ],
    completionCelebration:
      'YOU DID IT, FOREST BUILDER! All 10 landmarks across The Beginner’s Forest shine with life, lanterns glow along every stone lane, and World 2: The Variable Village now awaits!',
  },
];

export function getWorld1LevelSpec(levelNumber: number): World1LevelSpec {
  const clamped = Math.max(1, Math.min(10, Math.round(levelNumber || 1)));
  return WORLD1_LEVELS[clamped - 1];
}
