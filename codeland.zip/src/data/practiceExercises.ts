import { PracticeExercise } from '../types/codeland';

export const PRACTICE_EXERCISES: PracticeExercise[] = [
  // ================= LEVEL 1: BEGINNER'S FOREST =================
  {
    id: 'ex-1-1',
    levelNumber: 1,
    topic: 'Java Output',
    difficulty: 'Beginner',
    type: 'mcq',
    title: 'Identify the Valid Print Statement',
    prompt: 'Which Java line prints `Beacon Ready` to the console with zero syntax errors?',
    options: [
      'System.out.println("Beacon Ready");',
      'system.out.println("Beacon Ready");',
      'System.out.println(Beacon Ready);',
      'print("Beacon Ready");',
    ],
    correctOptionIndex: 0,
    hint: 'Check capitalization of `System`, double quotes around text, and the ending semicolon `;`.',
    explanation: 'Java requires `System.out.println(...)` with a capital `S`, double quotes for String literals, and a trailing `;`.',
    xpReward: 10,
    coinReward: 5,
  },
  {
    id: 'ex-1-2',
    levelNumber: 1,
    topic: 'Output Prediction',
    difficulty: 'Beginner',
    type: 'predict_output',
    title: 'Predict Math Inside println',
    prompt: 'What exact single line will this Java snippet print to the console?',
    codeContext: `public class Main {
    public static void main(String[] args) {
        System.out.println(12 + 8);
    }
}`,
    expectedTextAnswer: '20',
    hint: 'Notice `12 + 8` is NOT wrapped in double quotes, so Java evaluates the addition.',
    explanation: 'Without quotes around `12 + 8`, Java adds the two integers first and prints `20`.',
    xpReward: 10,
    coinReward: 5,
  },
  {
    id: 'ex-1-3',
    levelNumber: 1,
    topic: 'Program Structure',
    difficulty: 'Intermediate',
    type: 'arrange_code',
    title: 'Assemble a Complete Java Program',
    prompt: 'Arrange these four lines in the exact top-to-bottom order to form a valid Java program.',
    jumbledLines: [
      '        System.out.println("Forest Clear");',
      'public class Main {',
      '    }',
      '    public static void main(String[] args) {',
      '}',
    ],
    correctOrderIndices: [1, 3, 0, 2, 4],
    hint: 'Start with `public class Main {`, then open `main`, run `System.out.println`, close `main`, and close `Main`.',
    explanation: 'Every Java statement runs inside `main`, which itself sits inside the outer `class Main` block.',
    xpReward: 10,
    coinReward: 5,
  },
  {
    id: 'ex-1-4',
    levelNumber: 1,
    topic: 'Syntax Debugging',
    difficulty: 'Advanced',
    type: 'debug_code',
    title: 'Debug the Broken Forest Relay',
    prompt: 'Fix all syntax errors in the broken program below so it compiles cleanly and prints `SIGNAL SENT`.',
    starterCode: `public class Main {
    public static void main(String[] args) {
        system.out.println("SIGNAL SENT)
    }
}`,
    validation: {
      expectedOutputLines: ['SIGNAL SENT'],
    },
    hint: 'There are 3 tiny bugs on line 3: lowercase `s`, a missing closing quote `"`, and a missing semicolon `;`.',
    explanation: 'Changing `system` to `System`, closing `"SIGNAL SENT"`, and adding `;` makes the statement valid Java.',
    xpReward: 10,
    coinReward: 5,
  },

  // ================= LEVEL 2: VARIABLE VILLAGE =================
  {
    id: 'ex-2-1',
    levelNumber: 2,
    topic: 'Data Types',
    difficulty: 'Beginner',
    type: 'mcq',
    title: 'Choose the Right Data Type',
    prompt: 'Tinker wants to store the price of a potion (`12.75`) in a Java variable. Which declaration is best?',
    options: [
      'int potionPrice = 12.75;',
      'double potionPrice = 12.75;',
      'boolean potionPrice = 12.75;',
      'char potionPrice = 12.75;',
    ],
    correctOptionIndex: 1,
    hint: '`int` only holds whole numbers without decimals.',
    explanation: '`double` is Java’s standard data type for decimal (floating-point) numbers like `12.75`.',
    xpReward: 10,
    coinReward: 5,
  },
  {
    id: 'ex-2-2',
    levelNumber: 2,
    topic: 'Variable Updates',
    difficulty: 'Beginner',
    type: 'predict_output',
    title: 'Track the Coin Ledger',
    prompt: 'What number is printed on the screen when this program finishes?',
    codeContext: `int coins = 40;
coins = coins + 30;
coins = coins - 15;
System.out.println(coins);`,
    expectedTextAnswer: '55',
    hint: 'Start at 40, add 30 to get 70, then subtract 15.',
    explanation: '`coins` updates step-by-step: `40 -> 70 -> 55`.',
    xpReward: 10,
    coinReward: 5,
  },
  {
    id: 'ex-2-3',
    levelNumber: 2,
    topic: 'Declarations',
    difficulty: 'Intermediate',
    type: 'find_error',
    title: 'Spot the Invalid Variable Declaration',
    prompt: 'Which of these four variable lines contains a Java compilation error?',
    options: [
      'String villageName = "Oakvale";',
      'char grade = \'A\';',
      'int crates = "25";',
      'boolean isLocked = false;',
    ],
    correctOptionIndex: 2,
    hint: 'Look closely at the quotes around `"25"` vs the declared type `int`.',
    explanation: '`"25"` in double quotes is a `String`, so assigning it to an `int` causes an incompatible types error.',
    xpReward: 10,
    coinReward: 5,
  },
  {
    id: 'ex-2-4',
    levelNumber: 2,
    topic: 'String Concatenation & Casting',
    difficulty: 'Advanced',
    type: 'write_code',
    title: 'Build the Village Supply Report',
    prompt: 'Declare `String item = "Timber";`, `double rawStacks = 7.9;`, cast `rawStacks` to an `int` variable `wholeStacks`, and print `Timber: 7`.',
    starterCode: `public class Main {
    public static void main(String[] args) {
        // Declare item, rawStacks, cast to wholeStacks, and print "Timber: 7"
        
    }
}`,
    validation: {
      expectedOutputLines: ['Timber: 7'],
      requiredPatterns: [
        { regex: /\(\s*int\s*\)/, message: 'Use `(int)` type casting on `rawStacks`.' },
        { regex: /\bString\s+item\b/, message: 'Declare `String item = "Timber";`.' },
      ],
    },
    hint: 'Use `int wholeStacks = (int) rawStacks;` and `System.out.println(item + ": " + wholeStacks);`.',
    explanation: 'Casting `7.9` with `(int)` truncates `.9` to `7`, and `+` joins the `String` with the `int`.',
    xpReward: 10,
    coinReward: 5,
  },

  // ================= LEVEL 3: LOGIC CASTLE =================
  {
    id: 'ex-3-1',
    levelNumber: 3,
    topic: 'Modulo & Comparisons',
    difficulty: 'Beginner',
    type: 'predict_output',
    title: 'Even or Odd Gate Check',
    prompt: 'What exact word does this `if-else` block print?',
    codeContext: `int code = 14;
if (code % 2 == 0) {
    System.out.println("EVEN");
} else {
    System.out.println("ODD");
}`,
    expectedTextAnswer: 'EVEN',
    hint: '`14 % 2` computes the remainder when 14 is divided by 2.',
    explanation: '14 divided by 2 leaves a remainder of `0`, so `code % 2 == 0` is `true` and prints `EVEN`.',
    xpReward: 10,
    coinReward: 5,
  },
  {
    id: 'ex-3-2',
    levelNumber: 3,
    topic: 'Logical Operators',
    difficulty: 'Intermediate',
    type: 'fill_blank',
    title: 'Complete the Dual Castle Condition',
    prompt: 'Type the exact 2-character Java logical operator that requires BOTH `hasShield` AND `level >= 3` to be true:',
    codeContext: `if (hasShield ___ level >= 3) {
    System.out.println("Enter Keep");
}`,
    expectedTextAnswer: '&&',
    hint: 'Java uses two ampersands side by side for logical AND.',
    explanation: '`&&` is Java’s logical AND operator; both sides must be `true` for the condition to pass.',
    xpReward: 10,
    coinReward: 5,
  },
  {
    id: 'ex-3-3',
    levelNumber: 3,
    topic: 'Conditional Logic',
    difficulty: 'Intermediate',
    type: 'debug_code',
    title: 'Fix the Broken Gate Comparison',
    prompt: 'Sir Gareth’s gate code accidentally uses `=` instead of `==` inside `if`. Fix it so when `keys` is `3`, it prints `Castle Unlocked`.',
    starterCode: `public class Main {
    public static void main(String[] args) {
        int keys = 3;
        if (keys = 3) {
            System.out.println("Castle Unlocked");
        } else {
            System.out.println("Locked");
        }
    }
}`,
    validation: {
      expectedOutputLines: ['Castle Unlocked'],
    },
    hint: 'Change `if (keys = 3)` to `if (keys == 3)`.',
    explanation: 'In Java, `=` is assignment while `==` tests equality.',
    xpReward: 10,
    coinReward: 5,
  },
  {
    id: 'ex-3-4',
    levelNumber: 3,
    topic: 'else-if Chains',
    difficulty: 'Advanced',
    type: 'write_code',
    title: 'Classify Guardian Rank',
    prompt: 'Given `int score = 85;`, write an `if / else if / else` chain: `>= 90` prints `GOLD`, `>= 75` prints `SILVER`, otherwise `BRONZE`.',
    starterCode: `public class Main {
    public static void main(String[] args) {
        int score = 85;
        // Write your if / else if / else chain:
        
    }
}`,
    validation: {
      expectedOutputLines: ['SILVER'],
      requiredPatterns: [
        { regex: /\belse\s+if\b/, message: 'Include an `else if` branch for the middle tier.' },
      ],
    },
    hint: 'Check `score >= 90` first, then `else if (score >= 75)`, then `else`.',
    explanation: 'Since `85 >= 90` is false, Java checks `else if (85 >= 75)` which is true, printing `SILVER`.',
    xpReward: 10,
    coinReward: 5,
  },

  // ================= LEVEL 4: LOOPING MOUNTAINS =================
  {
    id: 'ex-4-1',
    levelNumber: 4,
    topic: 'for Loops',
    difficulty: 'Beginner',
    type: 'predict_output',
    title: 'Predict the Loop Sum',
    prompt: 'What final number does this loop print?',
    codeContext: `int sum = 0;
for (int i = 1; i <= 4; i++) {
    sum += i;
}
System.out.println(sum);`,
    expectedTextAnswer: '10',
    hint: 'Add `1 + 2 + 3 + 4`.',
    explanation: '`sum` accumulates `1 + 2 + 3 + 4 = 10`.',
    xpReward: 10,
    coinReward: 5,
  },
  {
    id: 'ex-4-2',
    levelNumber: 4,
    topic: 'Infinite Loops',
    difficulty: 'Intermediate',
    type: 'find_error',
    title: 'Identify the Infinite Loop Bug',
    prompt: 'Why will the `while` loop `int n = 5; while (n > 0) { System.out.println(n); n++; }` run forever?',
    options: [
      '`while` cannot use `>`',
      '`n++` increases `n` (`6, 7, 8...`) so `n > 0` never becomes false; it should be `n--`',
      '`n` must start at `0`',
      '`System.out.println` resets `n`',
    ],
    correctOptionIndex: 1,
    hint: 'Watch which direction `n` moves when `n++` runs!',
    explanation: 'Starting at `5` and incrementing `n++` moves `n` away from `0` instead of counting down with `n--`.',
    xpReward: 10,
    coinReward: 5,
  },
  {
    id: 'ex-4-3',
    levelNumber: 4,
    topic: 'Loop Structure',
    difficulty: 'Intermediate',
    type: 'arrange_code',
    title: 'Order the Countdown Loop',
    prompt: 'Arrange these lines to count down from `3` to `1` using a `while` loop.',
    jumbledLines: [
      '    n--;',
      'int n = 3;',
      '}',
      'while (n >= 1) {',
      '    System.out.println(n);',
    ],
    correctOrderIndices: [1, 3, 4, 0, 2],
    hint: 'Initialize `n = 3` before `while`, print `n`, decrement `n--`, then close `}`.',
    explanation: 'Initializing before the loop and decrementing after printing outputs `3`, `2`, `1` cleanly.',
    xpReward: 10,
    coinReward: 5,
  },
  {
    id: 'ex-4-4',
    levelNumber: 4,
    topic: 'for Loops & Filtering',
    difficulty: 'Advanced',
    type: 'write_code',
    title: 'Print Even Railway Pistons',
    prompt: 'Write a `for` loop from `2` to `8` that prints only the even numbers: `2`, `4`, `6`, `8` (one per line).',
    starterCode: `public class Main {
    public static void main(String[] args) {
        // Print 2, 4, 6, 8 using a for loop:
        
    }
}`,
    validation: {
      expectedOutputLines: ['2', '4', '6', '8'],
      requiredPatterns: [{ regex: /\bfor\s*\(/, message: 'Use a `for` loop.' }],
      requireExactPrintCount: 1,
    },
    hint: 'Either step by 2 (`for (int i = 2; i <= 8; i += 2)`) or check `if (i % 2 == 0)` inside the loop!',
    explanation: 'Stepping `i += 2` from `2` up to `8` visits `2, 4, 6, 8` directly in 4 clean iterations.',
    xpReward: 10,
    coinReward: 5,
  },

  // ================= LEVEL 5: METHOD KINGDOM =================
  {
    id: 'ex-5-1',
    levelNumber: 5,
    topic: 'Return Values',
    difficulty: 'Beginner',
    type: 'predict_output',
    title: 'Trace the Method Call',
    prompt: 'What number does `main` print to the console?',
    codeContext: `public class Main {
    public static int triple(int x) {
        return x * 3;
    }
    public static void main(String[] args) {
        System.out.println(triple(4) + 2);
    }
}`,
    expectedTextAnswer: '14',
    hint: '`triple(4)` returns `12`, then `+ 2` is added.',
    explanation: '`triple(4)` evaluates `4 * 3 = 12`, and `12 + 2` prints `14`.',
    xpReward: 10,
    coinReward: 5,
  },
  {
    id: 'ex-5-2',
    levelNumber: 5,
    topic: 'Method Signatures',
    difficulty: 'Intermediate',
    type: 'fill_blank',
    title: 'Complete the Return Keyword',
    prompt: 'Fill in the missing Java keyword that sends `a * b` back from `computeLoad`:',
    codeContext: `public static int computeLoad(int a, int b) {
    ______ a * b;
}`,
    expectedTextAnswer: 'return',
    hint: '6-letter Java keyword used to send a result out of a non-void method.',
    explanation: '`return` exits the method and hands the evaluated value back to the caller.',
    xpReward: 10,
    coinReward: 5,
  },
  {
    id: 'ex-5-3',
    levelNumber: 5,
    topic: 'Method Debugging',
    difficulty: 'Intermediate',
    type: 'debug_code',
    title: 'Fix the Mismatched Return Type',
    prompt: '`square(int n)` tries to return `n * n`, but its signature mistakenly says `void`. Fix the method so `main` prints `49`.',
    starterCode: `public class Main {
    public static void square(int n) {
        return n * n;
    }

    public static void main(String[] args) {
        System.out.println(square(7));
    }
}`,
    validation: {
      expectedOutputLines: ['49'],
      requiredPatterns: [{ regex: /public\s+static\s+int\s+square/, message: 'Change `void` to `int` on `square(int n)`.' }],
    },
    hint: 'Replace `void` in `public static void square(int n)` with `int`.',
    explanation: 'A method returning an integer calculation must declare `int` as its return type rather than `void`.',
    xpReward: 10,
    coinReward: 5,
  },
  {
    id: 'ex-5-4',
    levelNumber: 5,
    topic: 'Reusable Methods',
    difficulty: 'Advanced',
    type: 'write_code',
    title: 'Write `maxPower(int a, int b)`',
    prompt: 'Write `public static int maxPower(int a, int b)` that returns whichever number is larger using `if-else`. Call `maxPower(42, 78)` in `main` and print it.',
    starterCode: `public class Main {
    // Define public static int maxPower(int a, int b):
    

    public static void main(String[] args) {
        System.out.println(maxPower(42, 78));
    }
}`,
    validation: {
      expectedOutputLines: ['78'],
      requiredPatterns: [
        { regex: /maxPower\s*\(\s*int\s+\w+\s*,\s*int\s+\w+\s*\)/, message: 'Define `maxPower(int a, int b)`.' },
        { regex: /\breturn\b/, message: 'Use `return` inside `maxPower`.' },
      ],
    },
    hint: 'Inside `maxPower`: `if (a > b) { return a; } else { return b; }`.',
    explanation: 'Comparing `a > b` and returning the greater parameter makes `maxPower` work for any pair of integers.',
    xpReward: 10,
    coinReward: 5,
  },

  // ================= LEVEL 6: OBJECT KINGDOM =================
  {
    id: 'ex-6-1',
    levelNumber: 6,
    topic: 'OOP Concepts',
    difficulty: 'Beginner',
    type: 'mcq',
    title: 'Keyword to Instantiate an Object',
    prompt: 'Which Java keyword allocates and constructs a new object instance from a class?',
    options: ['class', 'new', 'void', 'extends'],
    correctOptionIndex: 1,
    hint: 'Think of `Player p = ___ Player("Alex", 100);`.',
    explanation: 'The `new` keyword invokes a class constructor to create a fresh object instance.',
    xpReward: 10,
    coinReward: 5,
  },
  {
    id: 'ex-6-2',
    levelNumber: 6,
    topic: 'Arrays',
    difficulty: 'Intermediate',
    type: 'predict_output',
    title: 'Array Index & Length Math',
    prompt: 'What single number will this array code print?',
    codeContext: `int[] shards = {5, 15, 25, 35};
System.out.println(shards[0] + shards[shards.length - 1]);`,
    expectedTextAnswer: '40',
    hint: '`shards[0]` is the first item (`5`), and `shards[shards.length - 1]` is the last item (`35`).',
    explanation: '`5 + 35 = 40`. `shards.length` is `4`, so index `3` holds `35`.',
    xpReward: 10,
    coinReward: 5,
  },
  {
    id: 'ex-6-3',
    levelNumber: 6,
    topic: 'Constructors',
    difficulty: 'Intermediate',
    type: 'arrange_code',
    title: 'Assemble a Java Class & Constructor',
    prompt: 'Arrange these lines to build a valid `Crystal` class with a constructor.',
    jumbledLines: [
      '    Crystal(int energy) {',
      'class Crystal {',
      '        this.energy = energy;',
      '    int energy;',
      '    }',
      '}',
    ],
    correctOrderIndices: [1, 3, 0, 2, 4, 5],
    hint: 'Open `class Crystal {`, declare `int energy;`, open `Crystal(int energy) {`, assign `this.energy = energy;`, then close both blocks.',
    explanation: 'Fields are declared inside the class, initialized inside the constructor using `this.`, and closed cleanly.',
    xpReward: 10,
    coinReward: 5,
  },
  {
    id: 'ex-6-4',
    levelNumber: 6,
    topic: 'Classes & Methods',
    difficulty: 'Advanced',
    type: 'write_code',
    title: 'Design the `Robot` Class',
    prompt: 'Create a `class Robot` with fields `String model` and `int battery`, a constructor `Robot(String model, int battery)`, and in `main` create `new Robot("BYTE-X", 100)` and print `BYTE-X:100`.',
    starterCode: `// Define class Robot above Main:


public class Main {
    public static void main(String[] args) {
        Robot r = new Robot("BYTE-X", 100);
        System.out.println(r.model + ":" + r.battery);
    }
}`,
    validation: {
      expectedOutputLines: ['BYTE-X:100'],
      requiredPatterns: [
        { regex: /\bclass\s+Robot\b/, message: 'Define `class Robot`.' },
        { regex: /\bnew\s+Robot\s*\(/, message: 'Instantiate `new Robot("BYTE-X", 100)`.' },
      ],
    },
    hint: 'Define `class Robot { String model; int battery; Robot(String model, int battery) { this.model = model; this.battery = battery; } }`.',
    explanation: 'Combining fields, a parameterized constructor using `this`, and `new` instantiation brings OOP together.',
    xpReward: 10,
    coinReward: 5,
  },
];
