import { WorldSpec } from '../types/codeland';

export const ADVENTURE_WORLDS: WorldSpec[] = [
  {
    worldId: 'world-1',
    levelNumber: 1,
    name: "The Beginner's Forest",
    biomeTitle: 'Emerald Voxel Woodland',
    tagline: 'Awaken the silent woodland relays with your first Java output statements.',
    skyHex: '#87CEEB',
    fogHex: '#9BD4EC',
    groundPrimaryHex: '#3A8E4B',
    groundSecondaryHex: '#2D6E3B',
    accentHex: '#F5C451',
    npcName: 'Sprout',
    npcRole: 'Forest Guide',
    npcAvatarId: 'character-g',
    npcDialogue: [
      'Welcome to The Beginner’s Forest! The river crossing and the Ancient Communication Tower both lost their startup instructions.',
      'Walk up to Terminal 1 by the river (`WASD` or Arrow keys) and press `E` to extend the timber bridge with `System.out.println`!',
      'Once across, activate Terminal 2 at the Communication Tower to ignite the golden beacon and open the World Portal!',
    ],
    missionTitle: 'Activate the Forest Communication Tower',
    missionSummary: 'Repair the River Bridge Relay and broadcast "Hello CODELAND!" from the Communication Tower.',
    obstacles: [
      {
        id: 'w1-obs-1',
        title: 'River Bridge Relay',
        npcPrompt: 'Byte: "Send the text signal `BRIDGE_ON` using `System.out.println` to extend the wooden river planks!"',
        objectiveLabel: 'Print "BRIDGE_ON" to extend the voxel river bridge',
        starterCode: `public class Main {
    public static void main(String[] args) {
        // Print BRIDGE_ON to deploy the wooden bridge:
        System.out.println("");
    }
}`,
        hints: [
          'Type `BRIDGE_ON` inside the double quotes: `System.out.println("BRIDGE_ON");`',
          'Check capitalization—all uppercase with an underscore `_`.',
        ],
        validation: {
          expectedOutputLines: ['BRIDGE_ON'],
          requiredPatterns: [{ regex: /System\.out\.println/, message: 'Use `System.out.println("BRIDGE_ON");`.' }],
        },
        successActionText: 'Wooden Voxel Bridge Extended Across the River!',
        position: [-2, 0, 3],
      },
      {
        id: 'w1-obs-2',
        title: 'Forest Communication Tower',
        npcPrompt: 'Byte: "Now broadcast `Hello CODELAND!` from the main tower console to awaken the forest network!"',
        objectiveLabel: 'Broadcast "Hello CODELAND!" at the Tower Console',
        starterCode: `public class Main {
    public static void main(String[] args) {
        // Broadcast Hello CODELAND! to power the tower:
        
    }
}`,
        hints: [
          'Write `System.out.println("Hello CODELAND!");` inside `main`.',
        ],
        validation: {
          expectedOutputLines: ['Hello CODELAND!'],
        },
        successActionText: 'Communication Beacon Ignited — Victory Portal Open!',
        position: [2, 0, -9],
      },
    ],
    portalPosition: [0, 0, -16],
    coinPositions: [
      [-5, 0.8, 7],
      [5, 0.8, 6],
      [0, 0.8, 0],
      [-4, 0.8, -6],
      [5, 0.8, -11],
    ],
  },
  {
    worldId: 'world-2',
    levelNumber: 2,
    name: 'The Variable Village',
    biomeTitle: 'Cobblestone & Timber Plaza',
    tagline: 'Restore the damaged village storage ledgers and unlock the golden resource vault.',
    skyHex: '#7EC8E3',
    fogHex: '#A8D8EA',
    groundPrimaryHex: '#5A9A49',
    groundSecondaryHex: '#8B7355',
    accentHex: '#F5C451',
    npcName: 'Vex',
    npcRole: 'The Crystal Merchant',
    npcAvatarId: 'character-h',
    npcDialogue: [
      'Thank goodness you arrived! Our Market Balance Gate and Resource Vault forgot all their typed variables.',
      'Head to the Market Gate console and initialize `int crates = 4;` and `boolean balanced = true;` to lower the barrier.',
      'Then calibrate the Resource Vault with `int coins = 250;` and `String code = "OAK";`!',
    ],
    missionTitle: 'Repair the Storage System & Open the Vault',
    missionSummary: 'Calibrate the Market Scale Gate and initialize the Resource Vault variables.',
    obstacles: [
      {
        id: 'w2-obs-1',
        title: 'Market Balance Gate',
        npcPrompt: 'Tinker: "Declare `int crates = 4;` and `boolean balanced = true;`, then print `crates + ":" + balanced`!"',
        objectiveLabel: 'Calibrate the Market Gate with int & boolean variables',
        starterCode: `public class Main {
    public static void main(String[] args) {
        int crates = 4;
        // Declare boolean balanced = true and print crates + ":" + balanced
        
    }
}`,
        hints: [
          'Add `boolean balanced = true;`',
          'Then `System.out.println(crates + ":" + balanced);` so it outputs `4:true`.',
        ],
        validation: {
          expectedOutputLines: ['4:true'],
          requiredPatterns: [
            { regex: /\bint\s+crates\b/, message: 'Declare `int crates = 4;`.' },
            { regex: /\bboolean\s+balanced\b/, message: 'Declare `boolean balanced = true;`.' },
          ],
        },
        successActionText: 'Market Balance Gate Lowered!',
        position: [-2, 0, 3],
      },
      {
        id: 'w2-obs-2',
        title: 'Village Resource Vault',
        npcPrompt: 'Tinker: "Set `int coins = 250;` and `String vaultCode = "OAK";`, then print `vaultCode + "-" + coins`!"',
        objectiveLabel: 'Unlock the Resource Vault Doors (`OAK-250`)',
        starterCode: `public class Main {
    public static void main(String[] args) {
        // Declare int coins = 250 and String vaultCode = "OAK"
        // Print vaultCode + "-" + coins
        
    }
}`,
        hints: [
          'Write `int coins = 250;` and `String vaultCode = "OAK";`',
          'Print `System.out.println(vaultCode + "-" + coins);` to output `OAK-250`.',
        ],
        validation: {
          expectedOutputLines: ['OAK-250'],
          requiredPatterns: [
            { regex: /\bint\s+coins\b/, message: 'Declare `int coins = 250;`.' },
            { regex: /\bString\s+vaultCode\b/, message: 'Declare `String vaultCode = "OAK";`.' },
          ],
        },
        successActionText: 'Golden Resource Vault Unsealed — Portal Open!',
        position: [2, 0, -9],
      },
    ],
    portalPosition: [0, 0, -16],
    coinPositions: [
      [-6, 0.8, 7],
      [4, 0.8, 5],
      [0, 0.8, -1],
      [-5, 0.8, -7],
      [5, 0.8, -12],
    ],
  },
  {
    worldId: 'world-3',
    levelNumber: 3,
    name: 'The Logic Kingdom',
    biomeTitle: 'Royal Stone Bastion & Moat',
    tagline: 'Command conditional drawbridges and dual-key iron gates with Java `if-else` logic.',
    skyHex: '#4B6584',
    fogHex: '#637D9A',
    groundPrimaryHex: '#576574',
    groundSecondaryHex: '#3B4652',
    accentHex: '#F28C45',
    npcName: 'Logicus',
    npcRole: 'The Royal Strategist',
    npcAvatarId: 'character-i',
    npcDialogue: [
      'Halt, friend! The moat drawbridge and the inner Sanctuary Portcullis are locked behind broken decision circuits.',
      'Program an `if-else` check at the Drawbridge Winch so `power >= 50` prints `LOWER`.',
      'Then combine `hasSeal && keys >= 2` at the Inner Portcullis to free the castle keep!',
    ],
    missionTitle: 'Open the Castle Gates & Rescue the Villagers',
    missionSummary: 'Write `if-else` and `&&` conditional logic to drop the drawbridge and raise the portcullis.',
    obstacles: [
      {
        id: 'w3-obs-1',
        title: 'Moat Drawbridge Winch',
        npcPrompt: 'Sir Gareth: "Write an `if-else` checking `power >= 50` to print `LOWER` (otherwise `HOLD`)!"',
        objectiveLabel: 'Program the Drawbridge Winch condition',
        starterCode: `public class Main {
    public static void main(String[] args) {
        int power = 70;
        // Write if (power >= 50) print "LOWER", else print "HOLD":
        
    }
}`,
        hints: [
          'Write `if (power >= 50) { System.out.println("LOWER"); } else { System.out.println("HOLD"); }`',
        ],
        validation: {
          expectedOutputLines: ['LOWER'],
          requiredPatterns: [
            { regex: /\bif\s*\(/, message: 'Use an `if` statement.' },
            { regex: /\belse\b/, message: 'Include an `else` clause.' },
          ],
        },
        successActionText: 'Heavy Oak Drawbridge Lowered Over the Moat!',
        position: [-2, 0, 3],
      },
      {
        id: 'w3-obs-2',
        title: 'Sanctuary Iron Portcullis',
        npcPrompt: 'Sir Gareth: "Use `&&` to verify `hasRoyalSeal && keys >= 2` and print `OPEN_KEEP`!"',
        objectiveLabel: 'Satisfy the dual-lock Sanctuary Gate (`OPEN_KEEP`)',
        starterCode: `public class Main {
    public static void main(String[] args) {
        boolean hasRoyalSeal = true;
        int keys = 3;
        // Check both with && and print "OPEN_KEEP":
        
    }
}`,
        hints: [
          'Write `if (hasRoyalSeal && keys >= 2) { System.out.println("OPEN_KEEP"); }`',
        ],
        validation: {
          expectedOutputLines: ['OPEN_KEEP'],
          requiredPatterns: [{ regex: /&&/, message: 'Combine both checks with `&&`.' }],
        },
        successActionText: 'Iron Portcullis Raised — Keep Rescued!',
        position: [2, 0, -9],
      },
    ],
    portalPosition: [0, 0, -16],
    coinPositions: [
      [-4, 0.8, 8],
      [5, 0.8, 5],
      [0, 0.8, 0],
      [-5, 0.8, -6],
      [4, 0.8, -12],
    ],
  },
  {
    worldId: 'world-4',
    levelNumber: 4,
    name: 'The Looping Mountains',
    biomeTitle: 'Highland Chasm & Sky Rail',
    tagline: 'Raise sequential chasm platforms and spin up railway turbines using Java loops.',
    skyHex: '#63B3ED',
    fogHex: '#90CDF4',
    groundPrimaryHex: '#68788C',
    groundSecondaryHex: '#E2E8F0',
    accentHex: '#69B9E7',
    npcName: 'Loopa',
    npcRole: 'The Mountain Engineer',
    npcAvatarId: 'character-j',
    npcDialogue: [
      'Mind the drop! Five floating sky-rail platforms retracted into the canyon below.',
      'Use a single `for` loop at the Chasm Controller to pulse platforms `1` through `5` upward!',
      'Across the gorge, run a `while` loop on the Locomotive Turbine to restore full mountain power!',
    ],
    missionTitle: 'Restart the Mountain Railway & Cross the Chasm',
    missionSummary: 'Automate the 5-platform sky bridge with a `for` loop and charge the railway turbine with `while`.',
    obstacles: [
      {
        id: 'w4-obs-1',
        title: '5-Platform Chasm Controller',
        npcPrompt: 'Kael: "Write a `for` loop from `1` to `5` printing `1`, `2`, `3`, `4`, `5` using only ONE `println`!"',
        objectiveLabel: 'Raise all 5 chasm platforms with a `for` loop',
        starterCode: `public class Main {
    public static void main(String[] args) {
        // Use a single for loop to print 1 through 5:
        
    }
}`,
        hints: [
          'Write `for (int i = 1; i <= 5; i++) { System.out.println(i); }`',
        ],
        validation: {
          expectedOutputLines: ['1', '2', '3', '4', '5'],
          requiredPatterns: [{ regex: /\bfor\s*\(/, message: 'Use a `for` loop.' }],
          requireExactPrintCount: 1,
        },
        successActionText: 'All 5 Sky-Bridge Platforms Risen in Sequence!',
        position: [-2, 0, 3],
      },
      {
        id: 'w4-obs-2',
        title: 'Mountain Railway Turbine',
        npcPrompt: 'Kael: "Use a `while` loop starting at `int rpm = 100;` while `rpm <= 300`, printing `rpm` and adding `100` each step!"',
        objectiveLabel: 'Spin up the Railway Turbine (`100`, `200`, `300`)',
        starterCode: `public class Main {
    public static void main(String[] args) {
        int rpm = 100;
        // Loop while rpm <= 300, print rpm, then add 100:
        
    }
}`,
        hints: [
          'Write `while (rpm <= 300) { System.out.println(rpm); rpm += 100; }`',
        ],
        validation: {
          expectedOutputLines: ['100', '200', '300'],
          requiredPatterns: [{ regex: /\bwhile\s*\(/, message: 'Use a `while` loop.' }],
          requireExactPrintCount: 1,
        },
        successActionText: 'Mountain Railway Turbine Online — Summit Portal Active!',
        position: [2, 0, -9],
      },
    ],
    portalPosition: [0, 0, -16],
    coinPositions: [
      [-5, 0.8, 7],
      [4, 0.8, 6],
      [0, 0.8, -1],
      [-4, 0.8, -7],
      [5, 0.8, -11],
    ],
  },
  {
    worldId: 'world-5',
    levelNumber: 5,
    name: 'Method Metro',
    biomeTitle: 'Automated Brass & Transit Grid',
    tagline: 'Organize city transit machines into modular, reusable Java methods with parameters and returns.',
    skyHex: '#1E3A5F',
    fogHex: '#2A4A73',
    groundPrimaryHex: '#2C3E50',
    groundSecondaryHex: '#34495E',
    accentHex: '#818CF8',
    npcName: 'Mech',
    npcRole: 'The Metro Architect',
    npcAvatarId: 'character-k',
    npcDialogue: [
      'Welcome to Method Kingdom! Our skywalk conduit and twin factory towers need clean, modular methods.',
      'At the Conduit Router, write `public static int routePower(int a, int b)` returning `a + b` and print `routePower(40, 60)`.',
      'Then write a reusable `syncTower(String id)` method and call it for `"ALPHA"` and `"BETA"`!',
    ],
    missionTitle: 'Restore the Automated City Systems',
    missionSummary: 'Create a value-returning `routePower` method and a parameterized `syncTower` method.',
    obstacles: [
      {
        id: 'w5-obs-1',
        title: 'Skywalk Conduit Router',
        npcPrompt: 'Nova: "Define `public static int routePower(int a, int b)` returning `a + b`, then print `routePower(40, 60)` (`100`)!"',
        objectiveLabel: 'Power the Skywalk via `routePower(40, 60)`',
        starterCode: `public class Main {
    // Define public static int routePower(int a, int b) here:
    

    public static void main(String[] args) {
        System.out.println(routePower(40, 60));
    }
}`,
        hints: [
          'Write `public static int routePower(int a, int b) { return a + b; }` above `main`.',
        ],
        validation: {
          expectedOutputLines: ['100'],
          requiredPatterns: [
            { regex: /routePower\s*\(\s*int\s+\w+\s*,\s*int\s+\w+\s*\)/, message: 'Define `routePower(int a, int b)`.' },
            { regex: /\breturn\b/, message: 'Use `return a + b;`.' },
          ],
        },
        successActionText: 'Energy Skywalk Powered Across the Sector!',
        position: [-2, 0, 3],
      },
      {
        id: 'w5-obs-2',
        title: 'Twin Factory Mainframe',
        npcPrompt: 'Nova: "Call `syncTower("ALPHA");` and `syncTower("BETA");` from `main` using the reusable method!"',
        objectiveLabel: 'Synchronize ALPHA & BETA Towers via method calls',
        starterCode: `public class Main {
    public static void syncTower(String unit) {
        System.out.println("SYNC:" + unit);
    }

    public static void main(String[] args) {
        // Call syncTower for "ALPHA" and "BETA":
        
    }
}`,
        hints: [
          'Inside `main`, call `syncTower("ALPHA");` and `syncTower("BETA");`.',
        ],
        validation: {
          expectedOutputLines: ['SYNC:ALPHA', 'SYNC:BETA'],
          requiredPatterns: [
            { regex: /syncTower\s*\(\s*"ALPHA"\s*\)/, message: 'Call `syncTower("ALPHA")`.' },
            { regex: /syncTower\s*\(\s*"BETA"\s*\)/, message: 'Call `syncTower("BETA")`.' },
          ],
          requireExactPrintCount: 1,
        },
        successActionText: 'Automated Twin Towers Synchronized — Portal Unlocked!',
        position: [2, 0, -9],
      },
    ],
    portalPosition: [0, 0, -16],
    coinPositions: [
      [-5, 0.8, 7],
      [5, 0.8, 5],
      [0, 0.8, 0],
      [-5, 0.8, -7],
      [4, 0.8, -12],
    ],
  },
  {
    worldId: 'world-6',
    levelNumber: 6,
    name: 'The Grand Citadel',
    biomeTitle: 'Grand Crystal Citadel & Core',
    tagline: 'Combine classes, OOP pillars, ArrayList, and try-catch to restore CODELAND’s Central Energy Core.',
    skyHex: '#1A2433',
    fogHex: '#243447',
    groundPrimaryHex: '#283845',
    groundSecondaryHex: '#1D2D3A',
    accentHex: '#F5C451',
    npcName: 'Aegis',
    npcRole: 'The Core Guardian',
    npcAvatarId: 'character-l',
    npcDialogue: [
      'This is it, Explorer—the Central Energy Core of CODELAND! Everything you learned leads to this moment.',
      'First, construct a `Stabilizer` object at the Crystal Causeway to materialize the bridge.',
      'Then instantiate an active `EnergyCore("ONLINE", 100)` object at the Central Core Console to restore all six realms!',
    ],
    missionTitle: 'Restore the Central Energy Core',
    missionSummary: 'Construct `Stabilizer` and `EnergyCore` Java objects to bring CODELAND back to full harmony.',
    obstacles: [
      {
        id: 'w6-obs-1',
        title: 'Crystal Causeway Stabilizer',
        npcPrompt: 'Aegis: "Complete `Stabilizer(int charge)` using `this.charge = charge;` and print `s.charge` (`100`)!"',
        objectiveLabel: 'Instantiate `new Stabilizer(100)` to form the Crystal Causeway',
        starterCode: `class Stabilizer {
    int charge;

    Stabilizer(int charge) {
        // Assign this.charge below:
        
    }
}

public class Main {
    public static void main(String[] args) {
        Stabilizer s = new Stabilizer(100);
        System.out.println(s.charge);
    }
}`,
        hints: [
          'Write `this.charge = charge;` inside `Stabilizer(int charge)`.',
        ],
        validation: {
          expectedOutputLines: ['100'],
          requiredPatterns: [
            { regex: /this\.charge\s*=\s*charge/, message: 'Assign `this.charge = charge;` inside the constructor.' },
            { regex: /\bnew\s+Stabilizer\b/, message: 'Instantiate `new Stabilizer(100)`.' },
          ],
        },
        successActionText: 'Prismatic Crystal Causeway Materialized!',
        position: [-2, 0, 3],
      },
      {
        id: 'w6-obs-2',
        title: 'Central Energy Core Console',
        npcPrompt: 'Aegis: "Construct `new EnergyCore("ONLINE", 100)` and print `core.status + ":" + core.level` (`ONLINE:100`)!"',
        objectiveLabel: 'Restore the Central Energy Core (`ONLINE:100`)',
        starterCode: `class EnergyCore {
    String status;
    int level;

    EnergyCore(String status, int level) {
        this.status = status;
        this.level = level;
    }
}

public class Main {
    public static void main(String[] args) {
        // Create EnergyCore("ONLINE", 100) and print status + ":" + level:
        
    }
}`,
        hints: [
          'Write `EnergyCore core = new EnergyCore("ONLINE", 100);`',
          'Then `System.out.println(core.status + ":" + core.level);`.',
        ],
        validation: {
          expectedOutputLines: ['ONLINE:100'],
          requiredPatterns: [
            { regex: /\bnew\s+EnergyCore\s*\(/, message: 'Create an `EnergyCore` object with `new EnergyCore("ONLINE", 100)`.' },
          ],
        },
        successActionText: 'CENTRAL ENERGY CORE RESTORED — CODELAND SAVED!',
        position: [2, 0, -9],
      },
    ],
    portalPosition: [0, 0, -16],
    coinPositions: [
      [-5, 0.8, 7],
      [5, 0.8, 6],
      [0, 0.8, -1],
      [-5, 0.8, -7],
      [5, 0.8, -12],
    ],
  },
];

export function getWorldById(worldId: string): WorldSpec {
  return ADVENTURE_WORLDS.find((w) => w.worldId === worldId) || ADVENTURE_WORLDS[0];
}
